<?php

class AgencyBlock extends AppModel{
    public $useTable = 'agencies_blocks';
