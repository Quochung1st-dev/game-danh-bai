<?php

class AgencyBlocks extends AppModel
{
    public $useTable = 'agencies_blocks';
}
