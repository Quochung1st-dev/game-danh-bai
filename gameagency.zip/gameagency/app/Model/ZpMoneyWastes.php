<?php
App::uses('AppModel', 'Model');
/**
 * Agency Model
 *
 */
class ZpMoneyWastes extends AppModel {
    public $useDbConfig = 'casinoLog';
    public $useTable = false;
}
