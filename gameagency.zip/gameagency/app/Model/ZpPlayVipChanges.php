<?php
App::uses('AppModel', 'Model');
/**
 * Agency Model
 *
 */
class ZpPlayVipChanges extends AppModel {
    public $useDbConfig = 'casinoLog';
    public $useTable = false;
}
