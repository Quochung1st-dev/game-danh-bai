<?php
/**
 * Trade Fixture
 */
class TradeFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false, 'key' => 'primary'),
		'user' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'user_target' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'gold' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'mess' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 200, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'created' => array('type' => 'datetime', 'null' => false, 'default' => null),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id', 'unique' => 1)
		),
		'tableParameters' => array('charset' => 'utf8', 'collate' => 'utf8_general_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'user' => 1,
			'user_target' => 1,
			'gold' => 1,
			'mess' => 'Lorem ipsum dolor sit amet',
			'created' => '2018-06-15 10:34:28'
		),
	);

}
