<?php
/**
 * EventCode Fixture
 */
class EventCodeFixture extends CakeTestFixture {

/**
 * Fields
 *
 * @var array
 */
	public $fields = array(
		'id' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false, 'key' => 'primary'),
		'name' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 120, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'description' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 500, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'create_date' => array('type' => 'datetime', 'null' => false, 'default' => null),
		'expired_date' => array('type' => 'datetime', 'null' => false, 'default' => null),
		'number_code' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'start_date' => array('type' => 'datetime', 'null' => false, 'default' => null),
		'type_code' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'gold' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'vpoint' => array('type' => 'integer', 'null' => false, 'default' => null, 'unsigned' => false),
		'gameid' => array('type' => 'string', 'null' => false, 'default' => null, 'length' => 50, 'collate' => 'utf8_general_ci', 'charset' => 'utf8'),
		'indexes' => array(
			'PRIMARY' => array('column' => 'id', 'unique' => 1)
		),
		'tableParameters' => array('charset' => 'utf8', 'collate' => 'utf8_general_ci', 'engine' => 'InnoDB')
	);

/**
 * Records
 *
 * @var array
 */
	public $records = array(
		array(
			'id' => 1,
			'name' => 'Lorem ipsum dolor sit amet',
			'description' => 'Lorem ipsum dolor sit amet',
			'create_date' => '2018-07-02 11:38:22',
			'expired_date' => '2018-07-02 11:38:22',
			'number_code' => 1,
			'start_date' => '2018-07-02 11:38:22',
			'type_code' => 1,
			'gold' => 1,
			'vpoint' => 1,
			'gameid' => 'Lorem ipsum dolor sit amet'
		),
	);

}
