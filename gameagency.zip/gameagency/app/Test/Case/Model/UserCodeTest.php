<?php
App::uses('UserCode', 'Model');

/**
 * UserCode Test Case
 */
class UserCodeTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.user_code'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->UserCode = ClassRegistry::init('UserCode');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->UserCode);

		parent::tearDown();
	}

}
