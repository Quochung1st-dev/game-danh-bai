<?php
App::uses('EventCode', 'Model');

/**
 * EventCode Test Case
 */
class EventCodeTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.event_code'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->EventCode = ClassRegistry::init('EventCode');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->EventCode);

		parent::tearDown();
	}

}
