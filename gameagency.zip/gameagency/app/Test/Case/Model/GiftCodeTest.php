<?php
App::uses('GiftCode', 'Model');

/**
 * GiftCode Test Case
 */
class GiftCodeTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.gift_code'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->GiftCode = ClassRegistry::init('GiftCode');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->GiftCode);

		parent::tearDown();
	}

}
