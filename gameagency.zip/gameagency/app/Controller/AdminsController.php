<?php

//97c48003dd343bcbb1869237541ac764
/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */

App::uses( 'HttpSocket', 'Network/Http' );
include("Component/geoip/geoip.inc");
class AdminsController extends AppController {

    private $STATUS_VERIFY_OK = 1;
    private $STATUS_VERIFY_NOT_OK = 2;

    public $uses = [ 'Admin', 'Agency', 'UserVerifiled', 'AgencyBlocks'];

    function getData(){
        if($this->gi == null) {
            $this->gi = geoip_open(APP . "webroot/data/GeoIP.dat", GEOIP_STANDARD);
        }
    }


    function getRealIpAddr()
    {
        if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
        {
            $ip=$_SERVER['HTTP_CLIENT_IP'];
        }
        elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
        {
            $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
        }
        else
        {
            $ip=$_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }
    function getLocation(){
        try{
            $ip = $this->getRealIpAddr();

//            echo $ip;
//            $this->getData();
            CakeLog::write('GameManagerController',$ip);
        }catch (Exception $e){
            CakeLog::write('GameManagerController', "getLocation ".json_encode($e));
            return "";
        }
    }

    public function login() {
      $this->getLocation();
       $this->layout = 'empty';
       //TEST LOCAL
   // $admin    = $this->Agency->find( 'first', [
   // 	'conditions' => [
   // 		'Agency.id'     => 2
   // 	]
   // ] );
   // $this->Session->write('USER_LOGIN', $admin);
   // $this->redirect(['controller' => 'home']);
       // END --- TEST LOCAL
       if ( $this->request->is( 'ajax' ) ) {
           $dataPost = $this->request->data;
           CakeLog::write('GameManagerController',$dataPost['username']);
           $admin    = $this->Agency->find( 'first', [
               'conditions' => [
                   'Agency.username'     => $dataPost['username'],
                   'Agency.password' => md5( $dataPost['password'] )
               ]
           ] );

            if ($admin) {
                $agencyblock = $this->AgencyBlocks->find('first', [
                    'conditions' => [
                        "AgencyBlocks.agencies_id" => $admin['Agency']['id']
                    ],
                ]);
                
                if($agencyblock) {
                    $datebanneds = $agencyblock['AgencyBlocks']['block_date'];

                    // echo $datebanneds;
                    $datenow = date("Y-m-d H:i:s");
                    //kiểm tra tài khoản khóa và xét thời gian
                    if ($agencyblock['AgencyBlocks']['block_date'] < date("Y-m-d H:i:s")) {
                        $this->Agency->save(array(
                            'id' => $admin['Agency']['id'],
                            'status' => 0,
                        ));
                        $this->AgencyBlocks->id = $agencyblock['AgencyBlocks']['id'];
                        $this->AgencyBlocks->delete();
                    }
                }
                //sau khi mở khóa query lấy lại dữ liệu mới
                $checkbanned = $this->Agency->find('first', [
                    'conditions' => [
                        "Agency.id" => $admin['Agency']['id']
                    ],
                ]);
            }
           $dataReturn = [
               "status" => false,
               "msg"    => "",
               "data"   => null
           ];
           if ( DEBUG ||$admin) {
               $rs1 = $this->UserVerifiled->find( "first", [
                   'conditions' => [
                       'UserVerifiled.user_id' => $admin['Agency']['userid'],
                       'UserVerifiled.status'  => $this->STATUS_VERIFY_OK,
                   ]
               ] );


              if ($checkbanned['Agency']['status'] == 1){
                  $dataReturn["msg"] = "Tài khoản của bạn bị khóa, mở khóa lúc ".$agencyblock['AgencyBlocks']['block_date'];
              } elseif ( count( $rs1 ) == 0) {
                   $dataReturn["msg"] = "Bạn chưa xác thực tài khoản.";
               } else {
                    CakeLog::write('GameManagerController', 'login otp : ' . USE_OTP);
                    if (USE_OTP) {
                        $response = $this->sendOTPCode($admin['Agency']['id']);
                        $this->Session->write('TMP_USER_LOGIN', $admin);
                        $dataReturn["status"] = true;
                        $dataReturn["msg"] = 'da send OTP';
                    } else {
                        // login success
                        $gold                    = 1000;//$this->getGoldByID($tmp_user['Agency']['userid']);
                        $admin['Agency']['gold'] = $gold;
                        $this->Agency->query( 'UPDATE `agencies` SET `gold`=' . $gold . ' WHERE id = ' . $admin['Agency']['id'] );
                        $this->Session->write( 'USER_LOGIN', $admin );

                        $this->Session->delete( "TMP_USER_LOGIN" );
                        $dataReturn["status"] = true;
                        $dataReturn["msg"] = 'login success no otp';
                    }
               }

           } else {
               $dataReturn["msg"] = "Tài khoản hoặc mật khẩu không đúng.";
           }
//            CakeLog::write('GameManagerController', 'dataReturn' . json_encode($dataReturn));
           header( "Content-type: application/json" );
           echo json_encode( $dataReturn );die;
       }

    }

    public function checkOTP() {
        if ( !$this->request->is( 'ajax' ) ) {
            throw new NotFoundException();
        }
        $dataPost = $this->request->data;
        $dataReturn = [
            "status" => false,
            "msg"    => "",
            "data"   => null
        ];
        if ($this->Session->read("TMP_USER_LOGIN")) {
            $tmp_user = $this->Session->read("TMP_USER_LOGIN");
            if (isset($dataPost["otp"])) {
                $rs1 = $this->UserVerifiled->find( "first", [
                    'conditions' => [
                        'UserVerifiled.user_id' => $tmp_user['Agency']['userid'],
                        'UserVerifiled.status'  => $this->STATUS_VERIFY_OK,
                    ]
                ] );
                if (DEBUG || $rs1['UserVerifiled']['code'] == $dataPost["otp"] && !empty($dataPost["otp"])) {
                    // $gold                    = 1000;//$this->getGoldByID($tmp_user['Agency']['userid']);
                    // $admin['Agency']['gold'] = $gold;
                    // $this->Agency->query( 'UPDATE `agencies` SET `gold`=' . $gold . ' WHERE id = ' . $tmp_user['Agency']['id'] );
                    $this->Session->write( 'USER_LOGIN', $tmp_user );

                    $this->Session->delete( "TMP_USER_LOGIN" );
                    $dataReturn["status"] = true;
                } else {
                    $dataReturn["msg"] = "Sai mã OTP";
                }
            } else {
                $dataReturn["msg"] = "Bạn chưa nhập OTP";
            }
        } else {
            $dataReturn["msg"] = "Bạn chưa đăng nhập";
        }

        header( "Content-type: application/json" );
        echo json_encode( $dataReturn );die;
    }

    private function sendOTPCode( $agency_id ) {
        $httpSocket = new HttpSocket();
        $response   = $httpSocket->get( url_user_getDLotp, [ 'id' => $agency_id ] );

        CakeLog::write('GameManagerController','otp response: ' . $response);
        return $response;
    }
    public function getOTPCode1() {
        if ( !$this->request->is( 'ajax' ) ) {
            throw new NotFoundException();
        }
        $dataReturn = [
            "status" => false,
            "msg"    => "",
            "data"   => null
        ];
        if ($this->Session->read("TMP_USER_LOGIN")) {
            $tmp_user = $this->Session->read("TMP_USER_LOGIN");
            $this->sendOTPCode($tmp_user['Agency']['id']);
            $dataReturn["status"] = true;
            $dataReturn["msg"] = "Đã gửi mã OTP";
        } else {
            $dataReturn["msg"] = "Bạn chưa đăng nhập";
        }
        header( "Content-type: application/json" );
        echo json_encode( $dataReturn );
        die;
    }

    public function getOTPCode() {
        $admin      = $this->Session->read( 'USER_LOGIN' );
        $dataReturn = [
            "status" => false,
            "data"   => null
        ];
        if ( isset( $admin ) && $admin ) {
            $httpSocket = new HttpSocket();
            $url        = url_user_getDLotp . 'id=' . $admin['Agency']['id'];
            $response   = $httpSocket->get( $url );
            $dataReturn = [
                "status" => true,
                "data"   => $response
            ];
        }
        header( "Content-type: application/json" );
        echo json_encode( $dataReturn );
        die;
    }

    public function getGoldByID( $id ) {
        try {
            $bucketName = "kimvip";

// Establish username and password for bucket-access
            $authenticator = new \Couchbase\PasswordAuthenticator();

            $authenticator->username( '' )->password( '' );

// Connect to Couchbase Server
            $cluster = new CouchbaseCluster( "couchbase://127.0.0.1" );

// Authenticate, then open bucket
//$cluster->authenticate($authenticator);
            $bucket = $cluster->openBucket( $bucketName );

// Query with parameters
            $query = CouchbaseN1qlQuery::fromString( 'SELECT * FROM kimvip USE KEYS ["casino_data4_s_1_UProfileModel.' . $id . '"];' );

            $rows = $bucket->query( $query );
//            pr($rows);
            if ( isset( $rows->rows[0]->kimvip ) ) {
                return $rows->rows[0]->kimvip->gold;
            }

            return 0;
        } catch ( Exception $exception ) {
            return 0;
        }
    }

    public function logout() {
        $this->Session->destroy();

        return $this->redirect( [ 'action' => '/../dangnhap' ] );
    }

    public function doimk() {
        $this->set( 'title_for_layout', "Đổi mật khẩu" );
        $this->set( 'activeMenu', "doimk" );
        $admin = $this->Session->read('USER_LOGIN');
        if(!isset($admin)){
            $this->Session->destroy();
            return $this->redirect(['action' => 'login']);
        }
        if ( $this->request->is( 'post' ) ) {

            $dataPost = $this->request->data;

            $dl  = $this->Agency->find( "first", [
                'conditions' => [
                    'Agency.id' => $this->authUser['Agency']["id"]
                ]

            ] );
            $rs1 = $this->UserVerifiled->find( "first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $dl['Agency']['userid'],
                    'UserVerifiled.status'  => 1,
                ]
            ] );

            if ( count( $rs1 ) == 0 ) {
                $this->Flash->success( "Chưa xác thực tài khoản" );
                return;
            }

            if ( $this->authUser['Agency']['password'] != md5( $dataPost['Agency']['passold'] ) ) {
                $this->Flash->error( __( 'Mật khẩu cũ không đúng' ) );
            } else if ( md5( $dataPost['Agency']['passnew'] ) != md5( $dataPost['Agency']['repassnew'] ) ) {
                $this->Flash->error( __( 'Nhập lại mật khẩu không đúng' ) );
            } else if ( strlen( $dataPost['Agency']['passnew'] ) < 8 ) {
                $this->Flash->error( __( 'Mật khẩu phải hơn 8 ký tự' ) );
            } else if ( $this->authUser['Agency']['password'] == md5( $dataPost['Agency']['passnew'] ) ) {
                $this->Flash->error( __( 'Mật khẩu mới phải khác mật khẩu cũ' ) );
            } else {
                $code = $this->request->data['otpcode'];
                if ( $rs1['UserVerifiled']['code'] == $code && ! empty( $code ) ) {
                    $this->Agency->save( array(
                        'id'       => $this->authUser['Agency']['id'],
                        'password' => md5( $dataPost['Agency']['passnew'] ),

                    ) );
                    $this->Session->write( 'USER_LOGIN', null );
                    $this->Session->destroy();

                    return $this->redirect( [ 'action' => '/../dangnhap' ] );
                } else {
                    $this->Flash->error( __( 'Mã otp code không đúng' ) );
                }
            }

        }
    }


    public function maintains() {
        if ( $this->request->is( 'post' ) ) {
            $dataPost = $this->request->data;
            if ( ! empty( $dataPost['Admin']['time'] ) && ! empty( $dataPost['Admin']['content'] ) ) {
                $httpSocket = new HttpSocket();
                $d          = Security::hash( $dataPost['Admin']['time'] . "+" . $dataPost['Admin']['content'] . "+" . KEY_ENCODE, "sha256" );
                $url        = url_admin_maintain . 'token=' . $d . '&time=' . $dataPost['Admin']['time']
                    . '&content=' . $dataPost['Admin']['content'];
                echo $url;
                $response = $httpSocket->get( $url );
//                echo $response;
                $this->Flash->success( $response );
            } else {
                $this->Flash->success( "Nhập dữ liệu thiếu" );
            }
        }

        $maintain = $this->paginate( 'SendMaintain' );
        $this->set( compact( 'maintain' ) );
    }

    public function kickUsers() {
        if ( $this->request->is( 'post' ) ) {
            $dataPost = $this->request->data;
            if ( ! empty( $dataPost['Admin']['type'] ) ) {
                if ( $dataPost['Admin']['type'] == 1 ) {//Kick User
                    if ( ! empty( $dataPost['Admin']['content'] ) && ! empty( $dataPost['Admin']['userID'] ) ) {
                        $httpSocket = new HttpSocket();
                        $d          = Security::hash( $dataPost['Admin']['userID'] + '+' + $dataPost['Admin']['content'] . "+" . KEY_ENCODE, "sha256" );
                        $url        = url_admin_kick_user . 'token=' . $d
                            . '&content=' . $dataPost['Admin']['content'] . '&userID=' . $dataPost['Admin']['userID'];
                        echo $url;
                        $response = $httpSocket->get( $url );
                        $this->Flash->success( $response );
                    } else {
                        $this->Flash->success( "Nhập dữ liệu thiếu" );
                    }
                } else if ( ! empty( $dataPost['Admin']['content'] ) ) {
                    $httpSocket = new HttpSocket();
                    $d          = Security::hash( $dataPost['Admin']['content'] . "+" . KEY_ENCODE, "sha256" );
                    $url        = url_admin_kick_all_user
                        . '&content=' . $dataPost['Admin']['content'];
                    echo $url;
                    $response = $httpSocket->get( $url );
//                echo $response;
                    $this->Flash->success( $response );
                } else {
                    $this->Flash->success( "Nhập dữ liệu thiếu" );
                }
            } else {
                $this->Flash->success( "Nhập dữ liệu thiếu" );
            }
        }
        $options = [
            1 => 'Kick User',
            2 => 'Kick All User',
        ];
        $this->set( [
            'options' => $options
        ] );
        $mails = $this->paginate( 'SendMail' );
        $this->set( compact( 'mails' ) );
    }

    public function pushservers() {
        if ( $this->request->is( 'post' ) ) {
            $dataPost = $this->request->data;
            if ( ! empty( $dataPost['Admin']['content'] ) ) {
                $httpSocket = new HttpSocket();
                $d          = Security::hash( $dataPost['Admin']['title'] . "+" . $dataPost['Admin']['content'] . "+" . KEY_ENCODE, "sha256" );
                $url        = url_admin_send_push . 'token=' . $d
                    . '&title=' . $dataPost['Admin']['title']
                    . '&content=' . $dataPost['Admin']['content'];
                echo $url;
                $response = $httpSocket->get( $url );
                $this->Flash->success( $response );
            } else {
                $this->Flash->success( "Nhập dữ liệu thiếu" );
            }
        }

        $pushs = $this->paginate( 'SendPushServer' );
        $this->set( compact( 'pushs' ) );
    }

    public function pushnotifications() {
        if ( $this->request->is( 'post' ) ) {
            $dataPost = $this->request->data;
            if ( ! empty( $dataPost['Admin']['content'] ) ) {
                $httpSocket = new HttpSocket();
                $d          = Security::hash( $dataPost['Admin']['time'] . "+" . $dataPost['Admin']['title'] . "+" . $dataPost['Admin']['content'] . "+" . KEY_ENCODE, "sha256" );
                $url        = url_admin_send_notification . 'token=' . $d
                    . '&time=' . $dataPost['Admin']['time']
                    . '&title=' . $dataPost['Admin']['title']
                    . '&content=' . $dataPost['Admin']['content'];
                echo $url;
                $response = $httpSocket->get( $url );
                $this->Flash->success( $response );
            } else {
                $this->Flash->success( "Nhập dữ liệu thiếu" );
            }
        }

        $pushs = $this->paginate( 'SendPush' );
        $this->set( compact( 'pushs' ) );
    }


    public function sendMails() {
        if ( $this->request->is( 'post' ) ) {
            $dataPost = $this->request->data;

            if ( ! empty( $dataPost['Admin']['type'] ) ) {
                if ( $dataPost['Admin']['type'] == 1 ) {//Send User
                    if ( ! empty( $dataPost['Admin']['userid'] ) && ! empty( $dataPost['Admin']['title'] ) && ! empty( $dataPost['Admin']['content'] ) ) {
                        $httpSocket = new HttpSocket();
                        $d          = Security::hash( $dataPost['Admin']['userid'] . "+" . $dataPost['Admin']['title'] . "+" . $dataPost['Admin']['content'] . "+" . KEY_ENCODE, "sha256" );
                        $url        = url_admin_send_mail . 'token=' . $d . '&userid=' . $dataPost['Admin']['userid']
                            . '&title=' . $dataPost['Admin']['title']
                            . '&content=' . $dataPost['Admin']['content'];
                        echo $url;
                        $response = $httpSocket->get( $url );
//                echo $response;
                        $this->Flash->success( $response );
                    } else {
                        $this->Flash->success( "Nhập dữ liệu thiếu" );
                    }
                } else if ( ! empty( ! empty( $dataPost['Admin']['title'] ) && ! empty( $dataPost['Admin']['content'] ) ) ) {
                    $httpSocket = new HttpSocket();
                    $d          = Security::hash( "+" . $dataPost['Admin']['title'] . "+" . $dataPost['Admin']['content'] . "+" . KEY_ENCODE, "sha256" );
                    $url        = url_admin_send_mail_all_user . 'token=' . $d
                        . '&title=' . $dataPost['Admin']['title']
                        . '&content=' . $dataPost['Admin']['content'];
                    echo $url;
                    $response = $httpSocket->get( $url );
//                echo $response;
                    $this->Flash->success( $response );
                } else {
                    $this->Flash->success( "Nhập dữ liệu thiếu" );
                }
            } else {
                $this->Flash->success( "Nhập dữ liệu thiếu" );
            }


        }
        $options = [
            1 => 'Send User',
            2 => 'Send All User',
        ];

        $this->set( [
            'options' => $options
        ] );

        $mails = $this->paginate( 'SendMail' );
        $this->set( compact( 'mails' ) );
    }

    public function sendGolds() {
        if ( $this->request->is( 'post' ) ) {
            $dataPost = $this->request->data;

            if ( ! empty( $dataPost['Admin']['userid'] ) && ! empty( $dataPost['Admin']['gold'] ) && ! empty( $dataPost['Admin']['content'] ) && ! empty( $dataPost['Admin']['type'] ) ) {
                $httpSocket = new HttpSocket();
                $d          = Security::hash( $dataPost['Admin']['userid'] . "+" . $dataPost['Admin']['title'] . "+" . $dataPost['Admin']['gold'] . "+" . $dataPost['Admin']['content'] . "+" . KEY_ENCODE, "sha256" );
                $url        = url_admin_send_gold . 'token=' . $d . '&userid=' . $dataPost['Admin']['userid']
                    . '&title=' . $dataPost['Admin']['title']
                    . '&gold=' . $dataPost['Admin']['gold']
                    . '&type=' . $dataPost['Admin']['type']
                    . '&content=' . $dataPost['Admin']['content'];
                echo $url;
                $response = $httpSocket->get( $url );
//                echo $response;
                $this->Flash->success( $response );
            } else {
                $this->Flash->success( "Nhập dữ liệu thiếu" );
            }

        }
        $options = [
            1 => 'Send Gold',
            2 => 'Set Gold',
        ];
        $this->set( [
            'options' => $options
        ] );

        $golds = $this->paginate( 'SendGold' );
        $this->set( compact( 'golds' ) );
    }

    public function banUsers() {

        if ( $this->request->is( 'post' ) ) {
            $dataPost = $this->request->data;
            if ( ! empty( $dataPost['Admin']['userid'] ) && ! empty( $dataPost['Admin']['time'] ) && ! empty( $dataPost['Admin']['content'] ) && ! empty( $dataPost['Admin']['type'] ) ) {
                $httpSocket = new HttpSocket();
                $d          = Security::hash( $dataPost['Admin']['userid'] . "+" . $dataPost['Admin']['time'] . "+" . $dataPost['Admin']['content'] . "+" . $dataPost['Admin']['type'] . "+" . KEY_ENCODE, "sha256" );
                $url        = url_admin_ban_user . 'token=' . $d . '&userid=' . $dataPost['Admin']['userid']
                    . '&time=' . $dataPost['Admin']['time']
                    . '&content=' . $dataPost['Admin']['content']
                    . '&type=' . $dataPost['Admin']['type'];
                echo $url;
                $response = $httpSocket->get( $url );
//                echo $response;
                $this->Flash->success( $response );
            } else {
                $this->Flash->success( "Nhập dữ liệu thiếu" );
            }

        }
        $options = [
            1 => 'Ban User',
            2 => 'Ban Ip',
            3 => 'UnBan User',
            4 => 'UnBan Ip',
        ];
        $this->set( [
            'options' => $options
        ] );

        $banuser = $this->paginate( 'SendBan' );
        $this->set( compact( 'banuser' ) );
    }
}
