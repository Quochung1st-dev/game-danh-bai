<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */


class HomeController extends AppController
{

    public function index() {
        return $this->redirect(['controller' => 'Agencies/agencymanager']);
    }

}
