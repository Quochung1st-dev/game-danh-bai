<?php
App::uses( 'AppController', 'Controller' );

/**
 * GiftCodes Controller
 *
 * @property GiftCode $GiftCode
 * @property PaginatorComponent $Paginator
 */
class GiftCodesController extends AppController {

	/**
	 * Components
	 *
	 * @var array
	 */
	public $uses = [ 'GiftCode', 'EventCode', 'Agency', 'User' ];
	public $components = array( 'Paginator' );

	/**
	 * index method
	 *
	 * @return void
	 */
	public function index() {
		$this->set( 'title_for_layout', 'Quản lý code' );
		$this->set( 'activeMenu', 'GiftCodes' );

		$dataGet = $this->request->query;

		$conditions = [
			"GiftCode.agencyId" => $this->authUser['Agency']['userid']
		];

		if (isset($dataGet["keyword"]) && !empty($dataGet["keyword"])) {
			$conditions["OR"] = [
				"GiftCode.id" => $dataGet["keyword"],
				"GiftCode.eventid" => $dataGet["keyword"]
			];
		}

		$this->paginate = [
			"conditions" => $conditions
		];

		$giftCodes = $this->paginate( "GiftCode" );

		$this->set( compact( "giftCodes" ) );
	}

	public function getUserNameById($id) {
		$this->User->recursive = -1;
		$user = $this->User->findById($id);
		if ($user) {
			return $user["User"]["displayname"];
		}
		return "";
	}

	/**
	 * view method
	 *
	 * @throws NotFoundException
	 *
	 * @param string $id
	 *
	 * @return void
	 */
	public function view( $id = null ) {
		if ( ! $this->GiftCode->exists( $id ) ) {
			throw new NotFoundException( __( 'Invalid gift code' ) );
		}
		$options = array( 'conditions' => array( 'GiftCode.' . $this->GiftCode->primaryKey => $id ) );
		$this->set( 'giftCode', $this->GiftCode->find( 'first', $options ) );
	}

	/**
	 * add method
	 *
	 * @return void
	 */
	public function add() {
		if ( $this->request->is( 'post' ) ) {
			$this->GiftCode->create();
			if ( $this->GiftCode->save( $this->request->data ) ) {
				$this->Flash->success( __( 'The gift code has been saved.' ) );

				return $this->redirect( array( 'action' => 'index' ) );
			} else {
				$this->Flash->error( __( 'The gift code could not be saved. Please, try again.' ) );
			}
		}
	}

	/**
	 * edit method
	 *
	 * @throws NotFoundException
	 *
	 * @param string $id
	 *
	 * @return void
	 */
	public function edit( $id = null ) {
		if ( ! $this->GiftCode->exists( $id ) ) {
			throw new NotFoundException( __( 'Invalid gift code' ) );
		}
		if ( $this->request->is( array( 'post', 'put' ) ) ) {
			if ( $this->GiftCode->save( $this->request->data ) ) {
				$this->Flash->success( __( 'The gift code has been saved.' ) );

				return $this->redirect( array( 'action' => 'index' ) );
			} else {
				$this->Flash->error( __( 'The gift code could not be saved. Please, try again.' ) );
			}
		} else {
			$options             = array( 'conditions' => array( 'GiftCode.' . $this->GiftCode->primaryKey => $id ) );
			$this->request->data = $this->GiftCode->find( 'first', $options );
		}
	}

	/**
	 * delete method
	 *
	 * @throws NotFoundException
	 *
	 * @param string $id
	 *
	 * @return void
	 */
	public function delete( $id = null ) {
		$this->GiftCode->id = $id;
		if ( ! $this->GiftCode->exists() ) {
			throw new NotFoundException( __( 'Invalid gift code' ) );
		}
		$this->request->allowMethod( 'post', 'delete' );
		if ( $this->GiftCode->delete() ) {
			$this->Flash->success( __( 'The gift code has been deleted.' ) );
		} else {
			$this->Flash->error( __( 'The gift code could not be deleted. Please, try again.' ) );
		}

		return $this->redirect( array( 'action' => 'index' ) );
	}

	public function export() {
		$admin = $this->Session->read( 'USER_LOGIN' );
		if ( ! isset( $admin ) ) {
			$this->Session->destroy();

			return $this->redirect( [ 'action' => 'login' ] );
		}
		$dataGet = $this->request->query;

		if ( ! isset( $dataGet["event_id"] ) ) {
			return $this->redirect( [ 'action' => 'index' ] );
		}

		$this->response->download( "export.csv" );

		$data = $this->GiftCode->find( 'all', [
			'fields'     => [ 'GiftCode.code' ],
			'conditions' => [
				'GiftCode.agencyId' => $admin["Agency"]["userid"],
				'GiftCode.eventid'  => $dataGet["event_id"]
			]
		] );

		$dataReturn = [];
		foreach ( $data as $k => $v ) {
			$dataReturn[]["Excel"] = [
				"code"   => $v["GiftCode"]["code"],
				"status" => isset( $v["UserCode"][0] ) ? $v["UserCode"][0]["status"] : 0
			];
		}
		$this->set( compact( 'dataReturn' ) );

		$this->layout = 'empty';

		return;
	}
}
