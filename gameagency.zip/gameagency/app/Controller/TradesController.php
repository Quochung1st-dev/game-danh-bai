<?php
App::uses( 'AppController', 'Controller' );
/**
 * Trades Controller
 *
 * @property Trade $Trade
 * @property PaginatorComponent $Paginator
 */

App::uses( 'HttpSocket', 'Network/Http' );

class TradesController extends AppController {

	private $STATUS_NHAN_CHUA_XLY = 3;
	private $STATUS_NHAN_DA_XLY = 4;
	private $STATUS_NHAN_TAM_HOAN = 5;
	private $STATUS_NHAN_HOAN_TRA = 6;
	private $STATUS_CHUYEN_THANH_CONG = 1;
	private $STATUS_CHUYEN_THU_HOI = 2;
	/**
	 * Components
	 *
	 * @var array
	 */
	public $components = array( 'Paginator' );
	public $uses = [ 'Trade', 'Agency', 'UserVerifiled', 'User' , 'Club', 'ZpPlayVipChanges', 'BlackListBank'];

	/**
	 * index method
	 *
	 * @return void
	 */
	public function index() {
		$this->set( 'title_for_layout', 'Gold đã nhận' );
		$this->set( 'activeMenu', 'tradedGold' );

		$dataGet    = $this->request->query;

        $admin = $this->Session->read('USER_LOGIN');
        if(isset($admin) && $admin['Agency']['parent'] == -1){
            $conditions = [
                'Trade.visible' => 1
            ];
        }else {
            $conditions = [
                'Trade.user_target' => $this->Session->read('USER_LOGIN.Agency.name'),
                'Trade.visible' => 1
            ];
        }
		if ( isset( $dataGet["keyword"] ) && trim( $dataGet["keyword"] ) != "" ) {
			$conditions["OR"] = [
				"Trade.id"         => $dataGet["keyword"],
				"User.displayname" => $dataGet["keyword"]
			];
		}

		if ( isset( $dataGet["start_date"] ) && $dataGet["start_date"] ) {
			$conditions["DATE(Trade.created) >="] = $dataGet["start_date"];
			$conditions["DATE(Trade.created) <="] = $dataGet["end_date"];
		} else {
			$conditions["DATE(Trade.created) >="] = date( "Y-m-01" );
			$conditions["DATE(Trade.created) <="] = date( "Y-m-d" );
		}
//		if ( isset( $dataGet["status"] ) && is_array( $dataGet["status"] ) ) {
//			$conditions["Trade.status IN"] = $dataGet["status"];
//		}
		if ( isset( $dataGet["type"] ) && is_array( $dataGet["type"] ) ) {
			if ( count( $dataGet["type"] ) == 1 ) {
				if ( $dataGet["type"][0] == 1 ) {
					$conditions["AND"]["OR"] = [
						[
							"User.agency"       => 1,
							"UserTarget.agency" => 0,
						],
						[
							"User.agency"       => 0,
							"UserTarget.agency" => 1,
						]
					];
				} else {
					$conditions["User.agency"]       = 1;
					$conditions["UserTarget.agency"] = 1;
				}
			}
		}

		$this->paginate = [
			'fields'     => [ 'User.id', 'Trade.*' ],
			'joins'      => array(
				array(
					'table'      => 'user_vics',
					'alias'      => 'User',
					'type'       => 'INNER',
					'conditions' => array(
						'User.displayname = Trade.user',
					)
				),
				array(
					'table'      => 'user_vics',
					'alias'      => 'UserTarget',
					'type'       => 'INNER',
					'conditions' => array(
						'UserTarget.displayname = Trade.user_target',
					)
				)
			),
			'order'      => 'Trade.id DESC',
			'conditions' => $conditions
		];
		$this->set( 'trades', $this->Paginator->paginate() );

		$sum_gold = $this->Trade->find( "first", [
			"recursive"  => - 1,
			"fields"     => [
				"SUM(Trade.gold) as total_gold"
			],
			'joins'      => array(
				array(
					'table'      => 'user_vics',
					'alias'      => 'User',
					'type'       => 'INNER',
					'conditions' => array(
						'User.displayname = Trade.user',
					)
				),
				array(
					'table'      => 'user_vics',
					'alias'      => 'UserTarget',
					'type'       => 'INNER',
					'conditions' => array(
						'UserTarget.displayname = Trade.user_target',
					)
				)
			),
			"conditions" => $conditions
		] );
		$this->set( 'sum_gold', isset( $sum_gold[0] ) ? intval( $sum_gold[0]["total_gold"] ) : 0 );
	}

	public function dlNhanHey( $id ) {
		$httpSocket = new HttpSocket();

		$data = 'id=' . $id . "&name=" . $this->authUser["Agency"]["name"];

		$secret = KEY_ENCODE; //product's secret key (get value from 1Pay product detail)

		$token = hash_hmac( "sha256", $data, $secret ); // create signature to check


		$url      = url_user_dlnhanhey . 'token=' . $token . "&id=" . $id . "&name=" . $this->authUser["Agency"]["name"];

		$response = json_decode( $httpSocket->get( $url ), true );
		if ( isset( $response["status"] ) && $response["status"] == 0 ) {
			$this->Flash->success( $response["mess"] );
		} else {
			$this->Flash->error( $response["mess"] );
		}

		return $this->redirect( $this->referer() );
	}

	public function dlTraHey( $id, $note = null ) {
		$httpSocket = new HttpSocket();
		$data       = 'id=' . $id . "&name=" . $this->authUser["Agency"]["name"] . "&note=" . urldecode( $note );

		$secret = KEY_ENCODE; //product's secret key (get value from 1Pay product detail)

		$token = hash_hmac( "sha256", $data, $secret ); // create signature to check


		$url      = url_user_dltrahey . 'token=' . $token . "&id=" . $id . "&note=" . urldecode( $note ) . "&name=" . $this->authUser["Agency"]["name"];
		$response = json_decode( $httpSocket->get( $url ), true );
		if ( isset( $response["status"] ) && $response["status"] == 0 ) {
			$this->Flash->success( $response["mess"] );
		} else {
			$this->Flash->error( $response["mess"] );
		}

		return $this->redirect( $this->referer() );
	}

	public function dlPause( $id = null, $note = null ) {
		$trade = $this->Trade->find( "first", [
			"recursive"  => - 1,
			"conditions" => [
				"Trade.id"          => $id,
				"Trade.user_target" => $this->authUser["Agency"]["name"],
                "Trade.status" => $this->STATUS_NHAN_CHUA_XLY,
			]
		] );
		if ( ! $trade ) {
			return $this->redirect( [ "action" => 'index' ] );
		}
		$data = [
			"id"     => $id,
			"status" => $this->STATUS_NHAN_TAM_HOAN,
			"note"   => urldecode( $note )
		];
		if ( $this->Trade->save( $data ) ) {
			$this->Flash->success( __( 'Tạm hoãn thành công.' ) );
		} else {
			$this->Flash->error( __( 'Không xư lý tạm hoãn được.' ) );
		}

		return $this->redirect( $this->referer() );
	}

	public function dlThuHoiHey( $id ) {
		$httpSocket = new HttpSocket();

		$data = 'id=' . $id . "&name=" . $this->authUser["Agency"]["name"];

		$secret = KEY_ENCODE; //product's secret key (get value from 1Pay product detail)

		$token = hash_hmac( "sha256", $data, $secret ); // create signature to check


		$url      = url_user_dlthuhoihey . 'token=' . $token . "&id=" . $id . "&name=" . $this->authUser["Agency"]["name"];

		$response = json_decode( $httpSocket->get( $url ), true );
		if ( isset( $response["status"] ) && $response["status"] == 0 ) {
			$this->Flash->success( $response["mess"] );
		} else {
			$this->Flash->error( $response["mess"] );
		}

		return $this->redirect( $this->referer() );
	}

	public function saveBankBan(){
        if ($this->request->is('post')) {
            $dataPost = $this->request->data;
            if ($this->BlackListBank->save($dataPost)) {
                $this->Flash->success('Thêm Bank Bẩn thành công !');
            } else {
                $this->Flash->error('Có lỗi xảy ra');
            }
        }
        return $this->redirect(['action' => 'black_bank']);
    }

    public function black_bank(){
        $this->set( 'title_for_layout', 'Danh sách bank bẩn' );
        $this->set( 'activeMenu', 'black_bank' );

        $bankList = $this->BlackListBank->find("all");
        $this->set( 'bankList', $bankList );

    }

	public function chuyengold() {
		$this->set( 'title_for_layout', 'Tool chuyển gold' );
		$this->set( 'activeMenu', 'chuyengold' );


		$this->Trade->recursive = 0;

		$admin = $this->Session->read( 'USER_LOGIN' );
		if ( ! isset( $admin ) ) {
			$this->Session->destroy();

			return $this->redirect( [ 'action' => 'login' ] );
		}


		$httpSocket = new HttpSocket();

		$dataPost = $this->request->data;
		if ( $dataPost ) {
			if ( isset( $dataPost['layma'] ) ) {
				$this->request->data['gold']  = intval( str_replace( ',', '', $this->request->data( 'gold' ) ) );
				$this->request->data['gold1'] = intval( str_replace( ',', '', $this->request->data( 'gold1' ) ) );
				$url                          = url_user_getDLotp . 'id=' . $admin['Agency']['id'];
				$response = $httpSocket->get( $url );

				$this->Flash->success( $response );

			} else if ( isset( $dataPost['tinh'] ) ) {
				if ( $dataPost['tinh'] == "Tính" ) {
					$this->request->data['vnd'] = intval( str_replace( ',', '', $this->request->data( 'vnd' ) ) );
					$this->request->data['goldT']  = intval( floor( $this->request->data['vnd'] * 100 / $this->request->data['tygia'] ) );
					$this->request->data['goldT1'] = intval( floor( $this->request->data['vnd'] * 100 / $this->request->data['tygia'] ) );
				} else {

                    $this->request->data['vnd'] = intval( str_replace( ',', '', $this->request->data( 'vnd' ) ) );
                    $this->request->data['tygia'] = intval( str_replace( ',', '', $this->request->data( 'tygia' ) ) );
                    $this->request->data['gold'] = intval( str_replace( ',', '', $this->request->data( 'goldT1' ) ) );
                    if($admin['Agency']['parent'] > 0)
                        $this->request->data['gold1'] = $this->request->data['gold'] * 0.02;
                    else
                        $this->request->data['gold1'] = 0;
                        $this->request->data['goldT1'] = intval( str_replace( ',', '', $this->request->data( 'goldT1' ) ) );
				}
			} else if ( isset( $dataPost['userTarget'] ) ) {

				$dl  = $this->Agency->find( "first", [
					'conditions' => [
						'Agency.id' => $admin['Agency']["id"]
					]

				] );
				$rs1 = $this->UserVerifiled->find( "first", [
					'conditions' => [
						'UserVerifiled.user_id' => $dl['Agency']['userid'],
						'UserVerifiled.status'  => 1,
					]
				] );

				if ( count( $rs1 ) == 0 ) {
					$this->Flash->success( "Chưa xác thực tài khoản" );

					return;
				}//


				$gold1 = intval( str_replace( ',', '', $this->request->data( 'gold1' ) ) );
				$gold = intval( str_replace( ',', '', $this->request->data( 'gold' ) ) );

				if ( $dl['Agency']['gold'] - 10000 < $gold1) {
					$this->request->data['gold']  = 0;
					$this->request->data['gold1'] = 0;
					$this->Flash->success( "Số tiền còn lại sau khi chuyển phải hơn 10.000 " . game_currency );
				} else if ($rs1['UserVerifiled']['code'] == $dataPost['otpcode'] && ! empty( $dataPost['otpcode'] ) ) {
					$id = $rs1['UserVerifiled']['id'];
					$this->UserVerifiled->query( "UPDATE `user_vic_verifileds` SET `code`='' WHERE `id` = $id" );
					$userTarget = $this->request->data( 'userTarget' ) ? $this->request->data( 'userTarget' ) : null;
					$gold       = $gold ? $gold : 0;
					$goldSub       = $gold1 ? $gold1 : 0;
					$mess       = $this->request->data( 'mess' ) ? $this->request->data( 'mess' ) : null;
					if ( $userTarget != null && $gold != null && $mess != null ) {

						$userCurren = $admin['Agency']['name'];

						$data = "userCurren=" . $userCurren . '&userTarget=' . $userTarget . '&gold=' . $gold;

						$secret = KEY_ENCODE; //product's secret key (get value from 1Pay product detail)

						$token = hash_hmac( "sha256", $data, $secret ); // create signature to check


						$url      = url_user_send_gold . 'token=' . $token . "&userCurren=" . $userCurren . '&userTarget=' . $userTarget . '&gold=' . $gold. '&goldsub=' . $goldSub . '&mess=' . $mess;

						$response = $httpSocket->get( $url );

						sleep( 5 );

						$this->Flash->success( $response->body );

						return $this->redirect( [ 'action' => 'chuyengold' ] );

					}
					$this->request->data = [];
				} else {
					$this->Flash->success( "Code không đúng" );
				}
			}

		}


		$admin = $this->Session->read( 'USER_LOGIN' );
		if ( ! isset( $admin ) ) {
			$this->Session->destroy();

			return $this->redirect( [ 'action' => 'login' ] );
		}
		$this->paginate = [
			'order'      => 'id DESC',
			'conditions' => '"user" = ' . $admin['Agency']['userid']
		];
		$this->set( 'trades', $this->Paginator->paginate() );
	}

    public function chuyengolddl() {
        $this->set( 'title_for_layout', 'Tool chuyển gold Đại lý' );
        $this->set( 'activeMenu', 'chuyengolddl' );


        $this->Trade->recursive = 0;

        $admin = $this->Session->read( 'USER_LOGIN' );
        if ( ! isset( $admin ) ) {
            $this->Session->destroy();

            return $this->redirect( [ 'action' => 'login' ] );
        }
        $listID = [];
        $listName  = [];

        if($admin['Agency']['parent'] == 0){
            $rs = $this->Agency->find("all",[
                'conditions' => [
                    'parent' => $admin['Agency']['userid'],
                ]
            ]);
            for($i = 0; $i< count($rs); $i++){
                $listID[$i] = $rs[$i]['Agency']['id'];
                $listName[$i] = $rs[$i]['Agency']['name'];
            }
        }else{
            $rs = $this->Agency->find("all",[
                'conditions' => [
                    'userid' => $admin['Agency']['parent'],
                ]
            ]);
            for($i = 0; $i< count($rs); $i++){
                $listID[$i] = $rs[$i]['Agency']['id'];
                $listName[$i] = $rs[$i]['Agency']['name'];
            }
        }

        $this->set('listName', $listName);
        $httpSocket = new HttpSocket();
//UPDATE `list_cards` SET `card_type`="VIETTEL",`card_num`=1000000,`status`=1 WHERE status = 2
        $dataPost = $this->request->data;
        if ( $dataPost ) {

            if ( isset( $dataPost['layma'] ) ) {
                $this->request->data['gold']  = intval( str_replace( ',', '', $this->request->data( 'gold' ) ) );
                $this->request->data['gold1'] = intval( str_replace( ',', '', $this->request->data( 'gold1' ) ) );
                $url                          = url_user_getDLotp . 'id=' . $admin['Agency']['id'];
//                echo $url;
//                die;
                $response = $httpSocket->get( $url );

                $this->Flash->success( $response );

            } else if ( isset( $dataPost['tinh'] ) ) {
                if ( $dataPost['tinh'] == "Tính" ) {
                    $this->request->data['vnd'] = intval( str_replace( ',', '', $this->request->data( 'vnd' ) ) );
//					echo "Tinh";
//					echo floor( $this->request->data['vnd'] * 100 / $this->request->data['tygia'] );
                    $this->request->data['goldT']  = intval( floor( $this->request->data['vnd'] * 100 / $this->request->data['tygia'] ) );

//                    if($admin['Agency']['parent'] > 0)
//                        $this->request->data['goldT'] = intval( floor($this->request->data['goldT'] + $this->request->data['goldT'] * 0.01));
//                    $this->request->data['goldT1'] = intval( floor( $this->request->data['vnd'] * 100 / $this->request->data['tygia'] ) );
//                    pr($this->request->data);
                } else {

                    $this->request->data['vnd'] = intval( str_replace( ',', '', $this->request->data( 'vnd' ) ) );
                    $this->request->data['tygia'] = intval( str_replace( ',', '', $this->request->data( 'tygia' ) ) );
                    $this->request->data['gold'] = intval( str_replace( ',', '', $this->request->data( 'goldT' ) ) );
//                    $this->request->data['gold1'] = intval( str_replace( ',', '', $this->request->data( 'goldT1' ) ) );
                    $this->request->data['goldT'] = intval( str_replace( ',', '', $this->request->data( 'goldT' ) ) );
//                    $this->request->data['goldT1'] = intval( str_replace( ',', '', $this->request->data( 'goldT1' ) ) );
                }
            } else if ( isset( $dataPost['userTarget'] ) ) {

                $dl  = $this->Agency->find( "first", [
                    'conditions' => [
                        'Agency.id' => $admin['Agency']["id"]
                    ]

                ] );
                $rs1 = $this->UserVerifiled->find( "first", [
                    'conditions' => [
                        'UserVerifiled.user_id' => $dl['Agency']['userid'],
                        'UserVerifiled.status'  => 1,
                    ]
                ] );

                if ( count( $rs1 ) == 0 ) {
                    $this->Flash->success( "Chưa xác thực tài khoản" );

                    return;
                }//


                $gold1 = intval( str_replace( ',', '', $this->request->data( 'gold' ) ) );
                $userTarget = $listName[$this->request->data( 'userTarget' )];
//                echo $userTarget;
//                die;
                if ( $dl['Agency']['gold'] - 10000 < $gold1) {
                    $this->request->data['gold']  = 0;
//                    $this->request->data['gold1'] = 0;
                    $this->Flash->success( "Số tiền còn lại sau khi chuyển phải hơn 10.000 " . game_currency );
                } else if ($rs1['UserVerifiled']['code'] == $dataPost['otpcode'] && ! empty( $dataPost['otpcode'] ) ) {
                    $id = $rs1['UserVerifiled']['id'];
                    $this->UserVerifiled->query( "UPDATE `user_vic_verifileds` SET `code`='' WHERE `id` = $id" );
//                    $userTarget = $this->request->data( 'userTarget' ) ? $this->request->data( 'userTarget' ) : null;

                    $gold       = $gold1 ? $gold1 : null;
                    $mess       = $this->request->data( 'mess' ) ? $this->request->data( 'mess' ) : null;
                    if ( $userTarget != null && $gold != null && $mess != null ) {

                        $userCurren = $admin['Agency']['name'];

                        $data = "userCurren=" . $userCurren . '&userTarget=' . $userTarget . '&gold=' . $gold;

                        $secret = KEY_ENCODE; //product's secret key (get value from 1Pay product detail)

                        $token = hash_hmac( "sha256", $data, $secret ); // create signature to check


                        $url      = url_user_send_gold . 'token=' . $token . "&userCurren=" . $userCurren . '&userTarget=' . $userTarget . '&gold=' . $gold . '&goldsub=' . 0 . '&mess=' . $mess;

                        $response = $httpSocket->get( $url );

                        sleep( 5 );

                        $this->Flash->success( $response->body );

                        return $this->redirect( [ 'action' => 'chuyengolddl' ] );

                    }
                    $this->request->data = [];
                } else {
                    $this->Flash->success( "Code không đúng" );
                }
            }

        }


        $admin = $this->Session->read( 'USER_LOGIN' );
        if ( ! isset( $admin ) ) {
            $this->Session->destroy();

            return $this->redirect( [ 'action' => 'login' ] );
        }
        $this->paginate = [
            'order'      => 'id DESC',
            'conditions' => '"user" = ' . $admin['Agency']['userid']
        ];
        $this->set( 'trades', $this->Paginator->paginate() );
    }


    public function goldGui() {
		$this->set( 'title_for_layout', 'Gold đã chuyển' );
		$this->set( 'activeMenu', 'goldGui' );

		$dataGet = $this->request->query;
        $admin = $this->Session->read('USER_LOGIN');
        if(isset($admin) && $admin['Agency']['parent'] == -1){
            $conditions = [
                'Trade.visible' => 1
            ];
        }else {
            $conditions = [
                'Trade.user' => $this->Session->read('USER_LOGIN.Agency.name'),
                'Trade.visible' => 1
            ];
        }
		if ( isset( $dataGet["keyword"] ) && trim( $dataGet["keyword"] ) != "" ) {
			$conditions["OR"] = [
				"Trade.id"               => $dataGet["keyword"],
				"UserTarget.displayname" => $dataGet["keyword"]
			];
		}

		if ( isset( $dataGet["start_date"] ) && $dataGet["start_date"] && isset( $dataGet["end_date"] ) && $dataGet["end_date"] ) {
			$conditions["DATE(Trade.created) >="] = $dataGet["start_date"];
			$conditions["DATE(Trade.created) <="] = $dataGet["end_date"];
		} else {
			$conditions["DATE(Trade.created) >="] = date( "Y-m-01" );
			$conditions["DATE(Trade.created) <="] = date( "Y-m-d" );
		}
		if ( isset( $dataGet["status"] ) && is_array( $dataGet["status"] ) ) {
			$conditions["Trade.status IN"] = $dataGet["status"];
		}
		if ( isset( $dataGet["type"] ) && is_array( $dataGet["type"] ) ) {
			if ( count( $dataGet["type"] ) == 1 ) {
				if ( $dataGet["type"][0] == 1 ) {
					$conditions["AND"]["OR"] = [
						[
							"User.agency"       => 1,
							"UserTarget.agency" => 0,
						],
						[
							"User.agency"       => 0,
							"UserTarget.agency" => 1,
						]
					];
				} else {
					$conditions["User.agency"]       = 1;
					$conditions["UserTarget.agency"] = 1;
				}
			}
		}

		$this->paginate = [
			'fields'     => [ 'UserTarget.id', 'Trade.*' ],
			'joins'      => array(
				array(
					'table'      => 'user_vics',
					'alias'      => 'User',
					'type'       => 'INNER',
					'conditions' => array(
						'User.displayname = Trade.user',
					)
				),
				array(
					'table'      => 'user_vics',
					'alias'      => 'UserTarget',
					'type'       => 'INNER',
					'conditions' => array(
						'UserTarget.displayname = Trade.user_target',
					)
				)
			),
			'order'      => 'Trade.id DESC',
			'conditions' => $conditions
		];
		$this->set( 'trades', $this->Paginator->paginate() );

		$sum_gold = $this->Trade->find( "first", [
			"recursive"  => - 1,
			"fields"     => [
				"SUM(Trade.gold) as total_gold"
			],
			'joins'      => array(
				array(
					'table'      => 'user_vics',
					'alias'      => 'User',
					'type'       => 'INNER',
					'conditions' => array(
						'User.displayname = Trade.user',
					)
				),
				array(
					'table'      => 'user_vics',
					'alias'      => 'UserTarget',
					'type'       => 'INNER',
					'conditions' => array(
						'UserTarget.displayname = Trade.user_target',
					)
				)
			),
			"conditions" => $conditions
		] );
		$this->set( 'sum_gold', isset( $sum_gold[0] ) ? intval( $sum_gold[0]["total_gold"] ) : 0 );
	}

	public function editGui( $id = null ) {
		$this->set( 'title_for_layout', 'Sửa Gold đã chuyển' );
		$this->set( 'activeMenu', 'goldGui' );

		$trade = $this->Trade->find( "first", [
			"recursive"  => - 1,
			"conditions" => [
				"Trade.id"   => $id,
				"Trade.user" => $this->authUser["Agency"]["name"]
			]
		] );

		if ( ! $trade ) {
			return $this->redirect( [ "action" => 'goldGui' ] );
		}

		if ( $this->request->is( array( 'post', 'put' ) ) ) {

			if ( $this->Trade->save( $this->request->data ) ) {
				$this->Flash->success( __( 'The trade has been saved.' ) );

				return $this->redirect( [ 'action' => 'goldGui' ] );
			} else {
				$this->Flash->error( __( 'The trade could not be saved. Please, try again.' ) );
			}
		} else {
			$options             = array( 'conditions' => array( 'Trade.' . $this->Trade->primaryKey => $id ) );
			$this->request->data = $this->Trade->find( 'first', $options );
		}
	}

	/**
	 * delete method
	 *
	 * @throws NotFoundException
	 *
	 * @param string $id
	 *
	 * @return void
	 */
	public function delete( $id = null ) {
//		$this->Trade->id = $id;
//		if (!$this->Trade->exists()) {
//			throw new NotFoundException(__('Invalid trade'));
//		}
//		$this->request->allowMethod('post', 'delete');
//		if ($this->Trade->delete()) {
//			$this->Flash->success(__('The trade has been deleted.'));
//		} else {
//			$this->Flash->error(__('The trade could not be deleted. Please, try again.'));
//		}
//		return $this->redirect(array('action' => 'index'));
	}

	public function getUserIdByName() {
		$dataGet    = $this->request->query;
		$name       = isset( $dataGet['name'] ) ? trim( $dataGet["name"] ) : null;
		$dataReturn = [
			"status" => false,
			"data"   => null
		];
		if ( $name ) {
			$user = $this->User->find( 'first', [
				'recursive'  => - 1,
				'conditions' => [
					'displayname' => $name
				]
			] );
			if ( $user ) {
				$dataReturn["status"] = true;
				$dataReturn["data"]   = $user["User"]["id"];
			}
		}
		header( "Content-type: application/json" );
		echo json_encode( $dataReturn );
		die;
	}

	public function getOTPCode() {
		$admin      = $this->Session->read( 'USER_LOGIN' );
		$dataReturn = [
			"status" => false,
			"data"   => null
		];
		if ( isset( $admin ) && $admin ) {
			$httpSocket = new HttpSocket();
			$url        = url_user_getDLotp . 'id=' . $admin['Agency']['id'];
			$response   = $httpSocket->get( $url );
			$dataReturn = [
				"status" => true,
				"data"   => $response
			];
		}
		header( "Content-type: application/json" );
		echo json_encode( $dataReturn );
		die;
	}

	public function thongke_tongdat(){
        $this->set( 'title_for_layout', 'Thống kê Luồng' );
        $this->set( 'activeMenu', 'thongke_tongdat' );
        $dataGet = $this->request->query;
        if ( isset( $dataGet["start_date"] ) && $dataGet["start_date"] && isset( $dataGet["end_date"] ) && $dataGet["end_date"] ) {
            $dt = "DATE(created) >= '" . $dataGet["start_date"] . "' and " . "DATE(created) <= '" .$dataGet["end_date"] ."'";
        } else {
            $dt = "DATE(created) >= '" . date( "Y-m-01" ) . "' and " . "DATE(created) <= '" . date( "Y-m-d" )."'";
        }
        $agency = $this->Trade->query('select agencies.displayname,agencies.name,agencies.userid,agencies.parent from agencies');
        for($i = 0; $i < count($agency); $i ++){
            $agency[$i]['agencies']['gold'] = 0;
            $agency[$i]['agencies']['listUser'] = [];

            $listUser = $this->getListUserTradeByAgency($agency[$i]['agencies']['name'], $dt);
            for($j = 0; $j < count($listUser); $j++){
                if($this->getUserTradeMaxByAgency($agency[$i]['agencies']['name'], $listUser[$j], $dt)){
                    $gold = $this->getGoldByUser($listUser[$j], $dt);
                    $agency[$i]['agencies']['gold'] += $gold;
                    $agency[$i]['agencies']['listUser'][] = array($listUser[$j],$gold);
//                    $agency[$i]['agencies']['listUser'][] = $listUser[$j];
                }
            }
        }
        for($i = 0; $i < count($agency); $i ++){
            if($agency[$i]['agencies']['parent'] > 0){
                for($j = 0; $j < count($agency); $j ++){
                    if($agency[$i]['agencies']['parent'] == $agency[$j]['agencies']['userid']){
                        $agency[$j]['agencies']['gold'] += $agency[$i]['agencies']['gold'];
                        for($k = 0; $k < count($agency[$i]['agencies']['listUser']); $k++){
                            $agency[$j]['agencies']['listUser'][] = $agency[$i]['agencies']['listUser'][$k];
                        }

                    }
                }
            }
        }

        //sap xep
        for($i = 0; $i < count($agency) - 1; $i ++){
            for($j = $i + 1; $j < count($agency); $j ++){
                if($agency[$i]['agencies']['parent'] == 0 && $agency[$j]['agencies']['parent'] == 0){
                    if($agency[$j]['agencies']['gold'] > $agency[$i]['agencies']['gold']){
                        $tmp = $agency[$j]['agencies'];
                        $agency[$j]['agencies'] = $agency[$i]['agencies'];;
                        $agency[$i]['agencies'] = $tmp;
                    }
                }
            }
            //Sắp xếp list User
            if($agency[$i]['agencies']['parent'] == 0) {
                for ($j = 0; $j < count($agency[$i]['agencies']['listUser']) - 1; $j++){
                    for ($k = $j + 1; $k < count($agency[$i]['agencies']['listUser']); $k++){
                        if($agency[$i]['agencies']['listUser'][$k][1] > $agency[$i]['agencies']['listUser'][$j][1]){
                            $tmp = $agency[$i]['agencies']['listUser'][$k];
                            $agency[$i]['agencies']['listUser'][$k] = $agency[$i]['agencies']['listUser'][$j];
                            $agency[$i]['agencies']['listUser'][$j] = $tmp;
                        }
                    }
                }

            }
        }

//        pr($agency);
        $this->set("agency", $agency);
    }

    public function getListUserTradeByAgency($agency , $dt){
	    $listUser = [];
        $trade1 = $this->Trade->query('select user as displayname from trades where user_target = "'.$agency.'" and '.$dt.' group by displayname');

        for($i = 0; $i< count($trade1); $i++){
            if(!in_array($trade1[$i]['trades']['displayname'], $listUser)){
                $listUser[] = $trade1[$i]['trades']['displayname'];
            }
        }

        $trade2 = $this->Trade->query('select user_target as displayname from trades where user = "'.$agency.'" and '.$dt.' group by displayname');
        for($i = 0; $i< count($trade2); $i++){
            if(!in_array($trade2[$i]['trades']['displayname'], $listUser)){
                $listUser[] = $trade2[$i]['trades']['displayname'];
            }
        }

        return $listUser;
    }

    public function getGoldByUser($user, $dt){
        $u = $this->User->find("first",[
            'conditions' => [
                'displayname' => $user
            ]
        ]);
        if(count($u) == 0)
            return 0;
        $qr = 'select sum(phe) as phe from user_change_golds where userid = '.$u['User']['id'].' and gameid < 100 and '.$dt;
        $gold = $this->Trade->query($qr);
//        pr($gold);
        if(isset($gold[0][0]['phe']))
            return $gold[0][0]['phe'];
        return 0;
    }

    private function getUserTradeMaxByAgency($agency, $user, $dt){
        $qr = '
            select *, sum(gold) as gold , (select sum(gold) from trades where (Trade.user = user and Trade.user_target = user_target) OR (Trade.user = user_target and Trade.user_target = user)) as goldTotal from trades as Trade
            where 
            ((user in (select agencies.name from agencies) and user_target not in (select agencies.name from agencies)) or 
            (user_target in (select agencies.name from agencies) and user not in (select agencies.name from agencies)))
            and (user = "' . $user .'" or user_target = "' . $user .'")
            and '.$dt.'
            group by user, user_target
            order by gold desc, modified limit 1';

        $tradeGold = $this->Trade->query($qr);
        if(count($tradeGold) == 0)
            return -1;
        if($agency != $tradeGold[0]['Trade']['user'] && $agency != $tradeGold[0]['Trade']['user_target'])
            return 0;
        return 1;
    }

	public function thongkeluong(){
        $dataGet = $this->request->query;
        if ( isset( $dataGet["start_date"] ) && $dataGet["start_date"] && isset( $dataGet["end_date"] ) && $dataGet["end_date"] ) {
            $dt = "DATE(created) >= '" . $dataGet["start_date"] . "' and " . "DATE(created) <= '" .$dataGet["end_date"] ."'";
        } else {
            $dt = "DATE(created) >= '" . date( "Y-m-01" ) . "' and " . "DATE(created) <= '" . date( "Y-m-d" )."'";
        }
        $tradeOut = $this->Trade->query('
            select user, sum(gold) as gold from trades 
            where user in (select agencies.name from agencies where parent = 0 and status = 0)
            and user_target not in ("haheyvip99","backheyvip68","Tuhanoi99")
            and user_target not in (select agencies.name from agencies)
            and status = 1
            and '.$dt.'
            group by user 
            order by sum(gold) desc');
//        pr($tradeOut);
        $tradeIn = $this->Trade->query('
            select user_target, sum(gold) as gold from trades 
            where user_target in (select agencies.name from agencies where parent = 0 and status = 0)
            and user not in ("haheyvip99","backheyvip68","Tuhanoi99")
            and user not in (select agencies.name from agencies)
            and status = 4
            and '.$dt.'
            group by user_target 
            order by sum(gold) desc');
//        pr($tradeIn);

        $agency = $this->Trade->query('select agencies.displayname,agencies.name,agencies.userid from agencies where parent = 0 and status = 0');

        for($i = 0; $i < count($agency); $i ++){
            $agency[$i]['agencies']['gold'] = 0;
            $agency[$i]['agencies']['goldALL'] = 0;
            for($j = 0; $j < count($tradeIn); $j ++){
                if(strtolower($agency[$i]['agencies']['name']) == strtolower($tradeIn[$j]['trades']['user_target']))
                    $agency[$i]['agencies']['gold'] = $tradeIn[$j][0]['gold'];
            }
            for($j = 0; $j < count($tradeOut); $j ++){
                if(strtolower($agency[$i]['agencies']['name']) == strtolower($tradeOut[$j]['trades']['user']))
                    $agency[$i]['agencies']['gold'] += $tradeOut[$j][0]['gold'];
            }
            $agency[$i]['agencies']['goldALL'] = $this->getGoldC2($agency[$i]['agencies']['userid'], $dt) + $agency[$i]['agencies']['gold'];
        }

        //Sap Xep
        for($i = 0; $i < count($agency) - 1; $i++){
            for($j = $i + 1; $j < count($agency); $j++){
                if($agency[$i]['agencies']['goldALL'] < $agency[$j]['agencies']['goldALL']){
                    $tmp = $agency[$i];
                    $agency[$i] = $agency[$j];
                    $agency[$j] = $tmp;
                }
            }
        }
        $this->set( 'title_for_layout', 'Top doanh số C1' );
        $this->set( 'activeMenu', 'thongkeluong' );
        $this->set( 'agency', $agency);
    }

    private function getGoldC2($userIDC1, $dt){
        $agency = $this->Trade->query('select agencies.name from agencies where parent = '.$userIDC1.' and status = 0');
        $gold = 0;
        for ($i = 0; $i< count($agency); $i++){
            $tradeOut = $this->Trade->query('
                select user, sum(gold) as gold from trades 
                where user = "'.$agency[$i]['agencies']['name'].'"
                and user_target not in (select agencies.name from agencies)
                and status = 1
                and '.$dt.'
                group by user 
                order by sum(gold) desc');
//            pr($tradeOut);
            if($tradeOut)
                $gold += $tradeOut[0][0]['gold'];
            $tradeIn = $this->Trade->query('
                select user_target, sum(gold) as gold from trades 
                where user_target = "'.$agency[$i]['agencies']['name'].'"
                and user not in (select agencies.name from agencies)
                and status = 4
                and '.$dt.'
                group by user 
                order by sum(gold) desc');
//            pr($tradeIn);
            if($tradeIn)
                $gold += $tradeIn[0][0]['gold'];
        }
        return $gold;
    }

    public function thongkeClub(){
        $dataGet = $this->request->query;
        if ( isset( $dataGet["start_date"] ) && $dataGet["start_date"] && isset( $dataGet["end_date"] ) && $dataGet["end_date"] ) {
            $dt = "DATE(create_date) >= '" . $dataGet["start_date"] . "' and " . "DATE(create_date) <= '" .$dataGet["end_date"] ."'";
        } else {
            $dt = "DATE(create_date) >= '" . date( "Y-m-01" ) . "' and " . "DATE(create_date) <= '" . date( "Y-m-d" )."'";
        }

        $listAgency = $this->Agency->find("all",[
            'conditions' => [
                'parent' => 0,
                'status' => 0
            ]
        ]);

        for($i = 0; $i< count($listAgency); $i++){
            $listUserClub = $this->Club->find("all",[
                'conditions' => [
                    'useridTarget' => $listAgency[$i]['Agency']['userid'],
                ]
            ]);

            $listAgency[$i]['Agency']['totalVP'] = 0;

            if(count($listUserClub) > 0){
//                pr($listUserClub);
//                pr($listAgency[$i]);
                for($j = 0 ; $j< count($listUserClub); $j++){
                    $kq = $this->ZpPlayVipChanges->query("select sum(`vip_change`) as vip from `zp_play_vip_changes` where `userid` = ".$listUserClub[$j]['Club']['userid']." and `create_date` > '".$listUserClub[$j]['Club']['created']."' and ". $dt);
                    if($kq[0][0]['vip'])
                        $listAgency[$i]['Agency']['totalVP'] += $kq[0][0]['vip'];
//                    pr($kq);
                }
            }
            $listAgency[$i]['Agency']['numberVP'] = count($listUserClub);
        }
//        pr($listAgency);
        //Sap Xep
        for($i = 0; $i < count($listAgency) - 1; $i++){
            for($j = $i + 1; $j < count($listAgency); $j++){
                if($listAgency[$i]['Agency']['totalVP'] < $listAgency[$j]['Agency']['totalVP']){
                    $tmp = $listAgency[$i];
                    $listAgency[$i] = $listAgency[$j];
                    $listAgency[$j] = $tmp;
                }
            }
        }
        $this->set( 'title_for_layout', 'Top Câu Lạc Bộ' );
        $this->set( 'activeMenu', 'thongkeClub' );
        $this->set( 'agency', $listAgency);
    }

    public function thongkeMember(){
        $admin = $this->Session->read( 'USER_LOGIN' );
        if ( ! isset( $admin ) ) {
            $this->Session->destroy();

            return $this->redirect( [ 'action' => 'login' ] );
        }
        $dataGet = $this->request->query;
        if ( isset( $dataGet["start_date"] ) && $dataGet["start_date"] && isset( $dataGet["end_date"] ) && $dataGet["end_date"] ) {
            $dt = "DATE(create_date) >= '" . $dataGet["start_date"] . "' and " . "DATE(create_date) <= '" .$dataGet["end_date"] ."'";
        } else {
            $dt = "DATE(create_date) >= '" . date( "Y-m-01" ) . "' and " . "DATE(create_date) <= '" . date( "Y-m-d" )."'";
        }

        $listAgency = $this->Club->query("
        select `clubs`.`userid`, `clubs`.`created`, `casino_log`.`zp_play_vip_changes`.`displayname`, sum(`vip_change`) as vip 
        from `clubs`, `casino_log`.`zp_play_vip_changes` 
        where clubs.`userid` = `casino_log`.`zp_play_vip_changes`.`userid`
        and `casino_log`.`zp_play_vip_changes`.`create_date` > `clubs`.`created`
        and `clubs`.`useridTarget` = ".$admin['Agency']['userid']."
        and ".$dt."
        GROUP BY clubs.userid 
        ORDER BY vip desc
        ");
//        pr($listAgency);

        $this->set( 'title_for_layout', 'Top Member' );
        $this->set( 'activeMenu', 'thongkeMember' );
        $this->set( 'agency', $listAgency);
    }
    public function thongkeMemberAll(){
        $admin = $this->Session->read( 'USER_LOGIN' );
        if ( ! isset( $admin ) ) {
            $this->Session->destroy();

            return $this->redirect( [ 'action' => 'login' ] );
        }
//        $listAgency = $this->Club->query("
//        select `clubs`.`userid`, `clubs`.`created`, `casino_log`.`zp_play_vip_changes`.`displayname`, sum(`vip_change`) as vip
//        from `clubs`, `casino_log`.`zp_play_vip_changes`
//        where clubs.`userid` = `casino_log`.`zp_play_vip_changes`.`userid`
//        and `casino_log`.`zp_play_vip_changes`.`create_date` > `clubs`.`created`
//        and `clubs`.`useridTarget` = ".$admin['Agency']['userid']."
//        GROUP BY clubs.userid
//        ORDER BY vip desc
//        ");
        $listAgency = $this->Club->query("
        select `clubs`.`userid`, `clubs`.`created`, `user_vics`.`displayname`, sum(`casino_log`.`zp_play_vip_changes`.`vip_change`) as vip
        from `clubs` LEFT JOIN `casino_log`.`zp_play_vip_changes` ON `clubs`.`userid` = `casino_log`.`zp_play_vip_changes`.`userid` 
        INNER JOIN `user_vics` ON `clubs`.`userid` = `user_vics`.`id` 
        WHERE `clubs`.`useridTarget` = ".$admin['Agency']['userid']."
        GROUP BY clubs.userid 
        ORDER BY vip desc
        ");
//        pr($listAgency);

        $this->set( 'title_for_layout', 'Danh sách Member' );
        $this->set( 'activeMenu', 'thongkeMemberAll' );
        $this->set( 'agency', $listAgency);
    }
}
