<?php
App::uses('HttpSocket', 'Network/Http');
App::uses('AppController', 'Controller');
/**
 * Agencies Controller
 *
 * @property Agency $Agency
 * @property PaginatorComponent $Paginator
 */
class AgenciesController extends AppController {

    public $uses = ['Agency', 'EventCode', 'Trade', 'ZpMoneyWastes', 'User', 'ZpDatTaiXiuGame', 'Trade', 'Tkdaily', 'TaixiuUser', 'SlotUser'];
    /**
     * Components
     *
     * @var array
     */
    public $components = array('Paginator');

    /**
     * index method
     *
     * @return void
     */
    public function index() {
        $this->set('title_for_layout', 'Thống kê');
        $this->set('activeMenu', 'agencies');


        $dataGet = $this->request->query;

        $conditions = [];

	    if ( isset( $dataGet["start_date"] ) && $dataGet["start_date"] ) {
		    $conditions["DATE(Trade.created) >="] = $dataGet["start_date"];
		    $conditions["DATE(Trade.created) <="] = $dataGet["end_date"];
	    } else {
		    $conditions["DATE(Trade.created) >="] = date( "Y-m-01" );
		    $conditions["DATE(Trade.created) <="] = date( "Y-m-d" );
	    }
	    if ( isset( $dataGet["type"] ) && is_array( $dataGet["type"] ) ) {
		    if ( count( $dataGet["type"] ) == 1 ) {
			    if ( $dataGet["type"][0] == 1 ) {
				    $conditions["AND"]["OR"] = [
					    [
						    "User.agency"       => 1,
						    "UserTarget.agency" => 0,
					    ],
					    [
						    "User.agency"       => 0,
						    "UserTarget.agency" => 1,
					    ]
				    ];
			    } else {
				    $conditions["User.agency"]       = 1;
				    $conditions["UserTarget.agency"] = 1;
			    }
		    }
	    }
	    $user = $this->authUser["Agency"]["name"];
	    $this->Trade->recursive = -1;
        $arr_day = $this->Trade->find('all', [
        	'fields' => ['DISTINCT DATE(Trade.created) as created'],
	        'joins'      => array(
		        array(
			        'table'      => 'user_vics',
			        'alias'      => 'User',
			        'type'       => 'INNER',
			        'conditions' => array(
				        'User.displayname = Trade.user',
			        )
		        ),
		        array(
			        'table'      => 'user_vics',
			        'alias'      => 'UserTarget',
			        'type'       => 'INNER',
			        'conditions' => array(
				        'UserTarget.displayname = Trade.user_target',
			        )
		        )
	        ),
	        "conditions" => [
	            "OR" => [
	            	"Trade.user" => $user,
	            	"Trade.user_target" => $user,
	            ],
		        $conditions
	        ],
	        'order' => 'Trade.created ASC'
        ]);
        $dataReturn = [
        	"total_gold_chuyen" => 0,
        	"total_gold_nhan" => 0,
        	"list" => [],
	        "children" => false
        ];

        $child = $this->Agency->find('all', [
        	'recursive' => -1,
        	'fields' => ['name'],
	        'conditions' => [
	        	'parent' => $this->authUser["Agency"]["userid"]
	        ]
        ]);
        $arr_child = [];
        foreach ($child as $item) {
        	$arr_child[] = $item["Agency"]["name"];
        }

        if($arr_child) {
	        $dataReturn["children"] = true;
        }

		foreach ($arr_day as $date) {
			$curDate = $date[0]["created"];
			$sum_chuyen = $this->Trade->find("first", [
				"fields" => [
					"SUM(Trade.gold) as total_gold"
				],
				'joins'      => array(
					array(
						'table'      => 'user_vics',
						'alias'      => 'User',
						'type'       => 'INNER',
						'conditions' => array(
							'User.displayname = Trade.user',
						)
					),
					array(
						'table'      => 'user_vics',
						'alias'      => 'UserTarget',
						'type'       => 'INNER',
						'conditions' => array(
							'UserTarget.displayname = Trade.user_target',
						)
					)
				),
				"conditions" => [
					"Trade.user" => $user,
					"Trade.status" => 1,
					"DATE(Trade.created)" => $curDate,
					$conditions
				]
			]);
			$sum_nhan = $this->Trade->find("first", [
				"fields" => [
					"SUM(Trade.gold) as total_gold"
				],
				'joins'      => array(
					array(
						'table'      => 'user_vics',
						'alias'      => 'User',
						'type'       => 'INNER',
						'conditions' => array(
							'User.displayname = Trade.user',
						)
					),
					array(
						'table'      => 'user_vics',
						'alias'      => 'UserTarget',
						'type'       => 'INNER',
						'conditions' => array(
							'UserTarget.displayname = Trade.user_target',
						)
					)
				),
				"conditions" => [
					"Trade.user_target" => $user,
					"Trade.status" => 4,
					"DATE(Trade.created)" => $curDate,
					$conditions
				]
			]);

			$sum_2_chuyen = 0;
			$sum_2_nhan = 0;

			if ($arr_child) {
				$sum2chuyen = $this->Trade->find("first", [
					"fields" => [
						"SUM(Trade.gold) as total_gold"
					],
					'joins'      => array(
						array(
							'table'      => 'user_vics',
							'alias'      => 'User',
							'type'       => 'INNER',
							'conditions' => array(
								'User.displayname = Trade.user',
							)
						),
						array(
							'table'      => 'user_vics',
							'alias'      => 'UserTarget',
							'type'       => 'INNER',
							'conditions' => array(
								'UserTarget.displayname = Trade.user_target',
							)
						)
					),
					"conditions" => [
						"Trade.user" => $arr_child,
						"Trade.status" => 1,
						"DATE(Trade.created)" => $curDate,
						$conditions
					]
				]);
				$sum2nhan = $this->Trade->find("first", [
					"fields" => [
						"SUM(Trade.gold) as total_gold"
					],
					'joins'      => array(
						array(
							'table'      => 'user_vics',
							'alias'      => 'User',
							'type'       => 'INNER',
							'conditions' => array(
								'User.displayname = Trade.user',
							)
						),
						array(
							'table'      => 'user_vics',
							'alias'      => 'UserTarget',
							'type'       => 'INNER',
							'conditions' => array(
								'UserTarget.displayname = Trade.user_target',
							)
						)
					),
					"conditions" => [
						"Trade.user_target" => $arr_child,
						"Trade.status" => 4,
						"DATE(Trade.created)" => $curDate,
						$conditions
					]
				]);
				$sum_2_chuyen = intval($sum2chuyen[0]["total_gold"]);
				$sum_2_nhan = intval($sum2nhan[0]["total_gold"]);
			}

			$dataReturn["list"][] = [
				"created" => $curDate,
				"gold_chuyen" => intval($sum_chuyen[0]["total_gold"]),
				"gold_nhan" => intval($sum_nhan[0]["total_gold"]),
				"gold_2_chuyen" => $sum_2_chuyen,
				"gold_2_nhan" => $sum_2_nhan,
			];

			$dataReturn["total_gold_chuyen"] += intval($sum_chuyen[0]["total_gold"]) + $sum_2_chuyen;
			$dataReturn["total_gold_nhan"] += intval($sum_nhan[0]["total_gold"]) + $sum_2_nhan;
		}
		$this->set(compact("dataReturn"));
    }

    public function tkgold(){
        $this->set('title_for_layout', "Luồng giao dịch người chơi");
        $admin = $this->Session->read('USER_LOGIN');
        if(!isset($admin)){
            $this->Session->destroy();
            return $this->redirect(['action' => 'login']);
        }

        $dataPost = $this->request->data;
        $wh = "";
        $curDate = date("Y-m-d");
        if(isset($dataPost['date1']) and is_array($dataPost['date1'])){
            $curDate1 = $dataPost['date1']['year'].'-'.$dataPost['date1']['month'].'-'.$dataPost['date1']['day'];
        }else{
            $curDate1 = $curDate;
        }

        $data = $this->getListGoldAgency($admin['Agency']['name'],$curDate1);
        $this->set('listUOk', $data);
        $this->set('activeMenu', 'tkgold');
        $this->set('curDate1', $curDate1);

    }

    public function tkListAgency(){
        $this->set('title_for_layout', "Luồng đại lý cấp 2");
        $this->set('activeMenu', "tkListAgency");
        $admin = $this->Session->read('USER_LOGIN');
        if(!isset($admin)){
            $this->Session->destroy();
            return $this->redirect(['action' => 'login']);
        }
        $dataPost = $this->request->data;
        $curDate = date("Y-m-d");
        if(isset($dataPost['date2']) and is_array($dataPost['date2'])){
            $curDate2 = $dataPost['date2']['year'].'-'.$dataPost['date2']['month'].'-'.$dataPost['date2']['day'];
        }else{
            $curDate2 = $curDate;
        }
        if(isset($dataPost['type']) and $dataPost['type'] == 'fee'){
            die;
        }
        $listAgency2 = $this->getListAgency2($admin['Agency']['userid']);

        if(count($listAgency2) > 0){
            for($i = 0; $i < count($listAgency2); $i++){
                $dt = $this->getListGoldAgency($listAgency2[$i]['Agency']['name'],$curDate2);
                $listAgency2[$i]['Agency']['count'] = $dt['count'];
                $listAgency2[$i]['Agency']['trade_out'] = $this->getSumTradeOut($listAgency2[$i]['Agency']['name'], $curDate2);
                $listAgency2[$i]['Agency']['trade_in'] = $this->getSumTradeIn($listAgency2[$i]['Agency']['name'], $curDate2);
            }
        }

        $this->set('listAgency', $listAgency2);
        $this->set('activeMenu', 'tkListAgency');
        $this->set('curDate2', $curDate2);

    }

    private function getListUserTrade($date){
        $user = $this->Trade->find("all",[
                'fields' => [
                    'user_target as name'
                ],
                'conditions' => [
                    'DATE(created)' => $date
                ],
                'group' => 'user_target'
            ]
            );

        $user1 = $this->Trade->find("all",[
                'fields' => [
                    'user as name'
                ],
                'conditions' => [
                    'DATE(created)' => $date
                ],
                'group' => 'user'
            ]
        );
        $listU = [];
        $listU1 = [];
        for($i = 0; $i < count($user); $i++){
            $vl = strtolower($user[$i]['Trade']['name']);
            $vl = trim($vl," ");
            if(!in_array($vl, $listU)){
                array_push($listU, $vl);
            }
        }

        for($i = 0; $i < count($user1); $i++){
            $vl = strtolower($user1[$i]['Trade']['name']);
            $vl = trim($vl," ");
            if(!in_array($vl, $listU)){
                array_push($listU, $vl);
            }
        }
        for($i = 0; $i < count($listU); $i++){
            $listU1[$i]['name'] = $listU[$i];
        }

        return $listU1;
    }


    private function sumGoldTX($disname){
        $rs = $this->TaixiuUser->find("first",[
            'fields' => [
                'dailyWon_1',
                'dailyLost_1'
            ],
            'conditions' => [
                'displayname' => $disname
            ],
        ]);
        if(count($rs) > 0)
            return $rs['TaixiuUser']['dailyWon_1'] + $rs['TaixiuUser']['dailyLost_1'];
        return 0;
    }

    private function sumGoldSl($disname){
        $rs = $this->SlotUser->find("first",[
            'fields' => [
                'dailyBet_1'
            ],
            'conditions' => [
                'displayname' => $disname
            ],
        ]);
        if(count($rs) > 0)
            return $rs['SlotUser']['dailyBet_1'];
        return 0;
    }

    public function tkcrontabnew(){
        $curDate = date('Y-m-d', strtotime(' -1 day'));

        $curDate = "2018-10-09";
        $listAgency = $this->getListAgency1();

        $listUserTrade = $this->getListUserTrade($curDate);
        for($i = 0; $i < count($listUserTrade); $i++){
            $goldTX = $this->sumGoldTX($listUserTrade[$i]['name']);
            $goldSlot = $this->sumGoldSl($listUserTrade[$i]);
            $listUserTrade[$i]['phe'] = $goldTX * 0.01 + $goldSlot * 0.02;

            $trade = $this->getGoldUserByAllAgency($listUserTrade[$i]['name'],$curDate);
            $listUserTrade[$i]['trade'] = $trade;
        }
        for($i = 0; $i < count($listAgency); $i++){
            $tnhan1 = $this->getSumTradeIn($listAgency[$i]['Agency']['name'],$curDate);
            $tchuyen1 = $this->getSumTradeOut($listAgency[$i]['Agency']['name'],$curDate);
            $tgiaodichIn = $this->getSumTradeInUser($listAgency[$i]['Agency']['name'],$curDate);
            $tgiaodichOut = $this->getSumTradeOutUser($listAgency[$i]['Agency']['name'],$curDate);
            $listAgency2 = $this->getListAgency2($listAgency[$i]['Agency']['userid']);
            $total = 0;
            for($j = 0; $j < count($listAgency2); $j++){

                $tnhan2 = $this->getSumTradeIn($listAgency2[$j]['Agency']['name'],$curDate);
                $tchuyen2 = $this->getSumTradeOut($listAgency2[$j]['Agency']['name'],$curDate);
                $tgiaodichIn2 = $this->getSumTradeInUser($listAgency2[$j]['Agency']['name'],$curDate);
                $tgiaodichOut2 = $this->getSumTradeOutUser($listAgency2[$j]['Agency']['name'],$curDate);
                $listT = $this->getListUserBuyAgency($listAgency2[$j]['Agency']['name'],$curDate);
                $listAgency2[$j]['Agency']['gphe'] = 0;
                for($t = 0; $t < count($listUserTrade); $t++){
                    if(in_array($listUserTrade[$t]['name'],$listT)) {
                        $gold = $this->getGoldUserByAgency($listUserTrade[$t]['name'], $listAgency2[$j]['Agency']['name'], $curDate);
                        if ($gold > 0) {
                            $listAgency2[$j]['Agency']['gphe'] = ceil($listAgency2[$j]['Agency']['gphe'] + $gold / $listUserTrade[$t]['trade'] * $listUserTrade[$t]['phe']);
                        }
                    }
                }

                $total += $listAgency2[$j]['Agency']['gphe'];
                $this->Tkdaily->create();
                $this->Tkdaily->save(array(
                    'gold' => $listAgency2[$j]['Agency']['gold'],
                    'tongchuyen' => $tchuyen2,
                    'tongnhan' => $tnhan2,
                    'tongphe' => $listAgency2[$j]['Agency']['gphe'],
                    'tongphec2' => 0,
                    'nhan_user' => $tgiaodichIn2,
                    'chuyen_user' => $tgiaodichOut2,
                    'tendaily' => $listAgency2[$j]['Agency']['name'],
                    'tencap1' => $listAgency[$i]['Agency']['name'],
                    'ngaytk' => $curDate,
                ));
            }
            $listAgency[$i]['Agency']['gnhan'] = $tnhan1;
            $listAgency[$i]['Agency']['gchuyen'] = $tchuyen1;
            $listAgency[$i]['Agency']['gphe'] = 0;

            $listT = $this->getListUserBuyAgency($listAgency[$i]['Agency']['name'],$curDate);
            for($j = 0; $j < count($listUserTrade); $j++){
                if(in_array($listUserTrade[$j]['name'],$listT)) {
                    $gold = $this->getGoldUserByAgency($listUserTrade[$j]['name'], $listAgency[$i]['Agency']['name'], $curDate);
                    if ($gold > 0) {
                        $listAgency[$i]['Agency']['gphe'] = ceil($listAgency[$i]['Agency']['gphe'] + $gold / $listUserTrade[$j]['trade'] * $listUserTrade[$j]['phe']);
                    }
                }
            }
            $this->Tkdaily->create();
            $this->Tkdaily->save(array(
                'gold' => $listAgency[$i]['Agency']['gold'],
                'tongchuyen' => $listAgency[$i]['Agency']['gchuyen'],
                'tongnhan' => $listAgency[$i]['Agency']['gnhan'],
                'tongphe' => $listAgency[$i]['Agency']['gphe'],
                'tongphec2' => 0,
                'nhan_user' => $tgiaodichIn,
                'chuyen_user' => $tgiaodichOut,
                'tendaily' => $listAgency[$i]['Agency']['name'],
                'tencap1' => "",
                'ngaytk' => $curDate,
            ));

        }

//        pr($listAgency);

        die;
    }

    public function tkcrontabNew1(){
        $curDate = date('Y-m-d', strtotime(' -1 day'));
//        $curDate = "2018-12-29";
        $listAgency = $this->getListAgency1();


        for($i = 0; $i < count($listAgency); $i++){

            $listAgency2 = $this->getListAgency2($listAgency[$i]['Agency']['userid']);
            $total = 0;
            for($j = 0; $j < count($listAgency2); $j++){
                $t1 = $this->getSumTradeInUser($listAgency2[$j]['Agency']['name'],$curDate);
                $t2 = $this->getSumTradeOutUser($listAgency2[$j]['Agency']['name'],$curDate);
                $total = $t1 + $t2;

            }
            if($total > 0){
                $this->Trade->query("
                INSERT INTO `trades` 
                (`id`, `user`, `user_target`, `gold`, `mess`, `status`, `note`, `created`, `modified`) VALUES 
                (NULL, 'haheyvip99', '".$listAgency[$i]['Agency']['name']."', '".$total* 0.02."', 'Hoàn trả tổng phí giao dịch của C2', '3', NULL, '".$curDate."', '".$curDate."');
                ");
            }
        }

        die;
    }

    public function tkcrontab(){
        $curDate = date("Y-m-d");
        $curDate = "2018-10-06";

//        $data = $this->getListGoldAgency("shop247",$curDate);
//        die;

        $listAgency1 = $this->getListAgency1();

        for($i = 0; $i< count($listAgency1); $i++){
            $data = $this->getListGoldAgency($listAgency1[$i]['Agency']['name'],$curDate);
            $listAgency2 = $this->getListAgency2($listAgency1[$i]['Agency']['userid']);
            $tnhan = $this->getSumTradeIn($listAgency1[$i]['Agency']['name'],$curDate);
            $tchuyen = $this->getSumTradeOut($listAgency1[$i]['Agency']['name'],$curDate);


            $total = 0;
            for($j = 0; $j < count($listAgency2); $j++){
                $data2 = $this->getListGoldAgency($listAgency2[$j]['Agency']['name'],$curDate);
                $tnhan1 = $this->getSumTradeIn($listAgency2[$j]['Agency']['name'],$curDate);
                $tchuyen1 = $this->getSumTradeOut($listAgency2[$j]['Agency']['name'],$curDate);

                $total += $data2['count'];
                $this->Tkdaily->create();
                $this->Tkdaily->save(array(
                    'tongchuyen' => $tchuyen1,
                    'tongnhan' => $tnhan1,
                    'tongphe' => $data2['count'] * 0.4,
                    'tongphec2' => 0,
                    'tendaily' => $listAgency2[$j]['Agency']['name'],
                    'tencap1' => $listAgency1[$i]['Agency']['name'],
                    'ngaytk' => $curDate,
                ));
            }

            $this->Tkdaily->create();
            $this->Tkdaily->save(array(
                'tongchuyen' => $tchuyen,
                'tongnhan' => $tnhan,
                'tongphe' => $data['count']  * 0.4,
                'tongphec2' => $total * 0.4,
                'tendaily' => $listAgency1[$i]['Agency']['name'],
                'tencap1' => "",
                'ngaytk' => $curDate,
            ));
        }
        die;
    }

    public function getListAgency1(){
        $listUser = $this->Agency->find("all",[
            'conditions' =>
                'parent = 0',
        ]);
        return $listUser;
    }

    public function getSumTradeOut($user_name, $date){
        $sum = $this->Trade->find('all', [
            'fields' => [
                'SUM(Trade.gold) as sum_gold'
            ],
            'conditions' => [
                'user' => $user_name,
                'DATE(created)' => $date
            ],
        ]);
        return isset($sum[0][0]['sum_gold']) ? $sum[0][0]['sum_gold'] : 0;
    }

    public function getSumTradeIn($user_name, $date){
        $sum = $this->Trade->find('all', [
            'fields' => [
                'SUM(Trade.gold) as sum_gold'
            ],
            'conditions' => [
                'user_target' => $user_name,
                'DATE(created)' => $date
            ],
        ]);
        return isset($sum[0][0]['sum_gold']) ? $sum[0][0]['sum_gold'] : 0;
    }

    public function getSumTradeInUser($user_name, $date){
        $sum = $this->Trade->find('all', [
            'fields' => [
                'SUM(Trade.gold) as sum_gold'
            ],
            'conditions' => [
                'user_target' => $user_name,
                'user not in (select name from agencies)',
                'DATE(created)' => $date
            ],
        ]);
        $goldIn =  isset($sum[0][0]['sum_gold']) ? $sum[0][0]['sum_gold'] : 0;


        return $goldIn;
    }

    public function getSumTradeOutUser($user_name, $date){

        $sum1 = $this->Trade->find('all', [
            'fields' => [
                'SUM(Trade.gold) as sum_gold'
            ],
            'conditions' => [
                'user' => $user_name,
                'user_target not in (select name from agencies)',
                'DATE(created)' => $date
            ],
        ]);
        $goldOut =  isset($sum1[0][0]['sum_gold']) ? $sum1[0][0]['sum_gold'] : 0;

        return $goldOut;
    }


    public function getListGoldAgency($agencyName, $curDate){
        $listAgency = $this->getListAgency();
        $listU = $this->getListUserBuyAgency($agencyName, $curDate);
        $listUOk = [];
        $index = 0;
        $count = 0;
        $count1 = 0;
        $count2 = 0;
        if(count($listU) > 0){
            for($i = 0; $i< count($listU); $i++){
                $countgold = $this->getGoldUserByAgency($listU[$i],$agencyName, $curDate);
//                echo $countgold . '----';
                $check = 0;
                for($j = 0; $j < count($listAgency); $j++){
                    $cg = $this->getGoldUserByAgency($listU[$i],$listAgency[$j]['Agency']['name'], $curDate);
//                    echo $cg. '------- '. $listU[$i] . '- ------ '.$listAgency[$j]['Agency']['name']. '<br/>';
                    if($cg > $countgold){
                        $check = 1;
                        break;
                    }
                }
                if($check == 0){
                    $user = $this->User->find("first", [
                        'conditions' => [
                            'User.displayname' => $listU[$i]
                        ]
                    ]);
                    if(count($user) > 0)
                        $listUOk[$index]["userid"] = $user['User']['id'];
                    else
                        $listUOk[$index]["userid"] = 0;
                    $listUOk[$index]["user"] = $listU[$i];
                    $listUOk[$index]["countgold"] = $countgold;
                    $listUOk[$index]["gold"] = $this->sumGoldSlot($listUOk[$index]["userid"], $curDate);
                    $listUOk[$index]["gold1"] = $this->sumGoldTaiXiu($listUOk[$index]["userid"], $curDate);
                    $count1 += $listUOk[$index]["gold"];
                    $count2 += $listUOk[$index]["gold1"];
                    $count = $count + $listUOk[$index]["gold"] + $listUOk[$index]["gold1"];
                    $index++;
                }
            }
        }

        $data['list'] = $listUOk;
        $data['count'] = $count;
        $data['count1'] = $count1;
        $data['count2'] = $count2;

        pr($data);
        return $data;
    }

    public function sumGoldSlot($userID, $curDate){

        $count = $this->ZpMoneyWastes->query("SELECT SUM(waste_money) as gold_total from zp_money_wastes WHERE userid = $userID and DATE(create_date) = '$curDate'");
        if(isset($count[0][0]['gold_total'])){
            return $count[0][0]['gold_total'];
        }else
            return 0;
    }

    public function sumGoldTaiXiu($userID, $curDate){

        $count = $this->ZpDatTaiXiuGame->query("SELECT SUM(tx_gold) as gold_total from `zp_dat_tai_xiu_games`  WHERE `userid` = $userID and (`type` = 4) and DATE(create_date) = '$curDate'");
//        pr($count);
        if(isset($count[0][0]['gold_total'])){
            return $count[0][0]['gold_total'];
        }else
            return 0;
    }
//1491
    public function getListAgency2($agenciID){
        $listUser = $this->Agency->find("all",[
            'conditions' =>
                'parent = '.$agenciID,
        ]);
        return $listUser;
    }

    public function getListAgency(){
        $listUser = $this->Agency->find("all",[
            'fields' => 'name'
        ]);
        return $listUser;
    }

    public function getGoldUserByAllAgency($user, $curDate){
        $count = $this->Trade->find('first',[
            'fields' => 'SUM(gold) as gold_total',
            'conditions' =>
                '((user = "' .$user . '" and user_target in (select agencies.name from agencies)) or 
                 (user_target = "' .$user . '" and  user in (select agencies.name from agencies))) and DATE(created) = "'.$curDate.'"'
        ]);

        if(isset($count[0]['gold_total'])){
            return $count[0]['gold_total'];
        }else
            return 0;
    }

    public function getGoldUserByAgency($user, $agency, $curDate){
        $count = $this->Trade->find('first',[
            'fields' => 'SUM(gold) as gold_total',
            'conditions' =>
                '(user = "' .$user . '" and user_target = "'.$agency.'" or 
                 user = "' .$agency . '" and  user_target = "'.$user.'") and DATE(created) = "'.$curDate.'"'
        ]);

        if(isset($count[0]['gold_total'])){
            return $count[0]['gold_total'];
        }else
            return 0;
    }

    public function getListUserBuyAgency($name, $curDate){
        $listUser = $this->Trade->find("all",[
            'conditions' => "(user = '".$name."' or user_target = '".$name."') and DATE(created) = '".$curDate . "'"
        ]);
        $listUS = [];
        $t = 0;
        if(count($listUser) > 0){
            for($i = 0; $i < count($listUser); $i++){
                if($listUser[$i]['Trade']['user'] == $name){
                    $vl = strtolower($listUser[$i]['Trade']['user_target']);
                }else{
                    $vl =  strtolower($listUser[$i]['Trade']['user']);
                }
                $vl = trim($vl," ");
                if(!in_array($vl, $listUS)){
                    $listUS[$t] = $vl;
                    $t++;
                }
            }
        }
//        $listUS = array_unique($listUS);
        return $listUS;
    }

    /**
     * view method
     *
     * @throws NotFoundException
     * @param string $id
     * @return void
     */
    public function view($id = null) {
        if (!$this->Agency->exists($id)) {
            throw new NotFoundException(__('Invalid agency'));
        }
        $options = array('conditions' => array('Agency.' . $this->Agency->primaryKey => $id));
        $this->set('agency', $this->Agency->find('first', $options));
    }

    public function agencymanager() {
        $this->set('title_for_layout', 'Thông tin đại lý');
        $this->set('activeMenu', 'agencymanager');

        $agency2 = $this->Agency->find('all', [
        	"conditions" => [
        		"Agency.parent" => $this->authUser['Agency']['userid']
	        ]
        ]);
        $agency1 = $this->Agency->find('all', [
        	"conditions" => [
        		"Agency.id" => $this->authUser['Agency']['parent']
	        ]
        ]);
        $this->set(compact("agency2"));

        $sum_sell = $this->Trade->find("first", [
        	"fields" => [
        		"SUM(Trade.gold) as total_gold"
	        ],
	        "conditions" => [
	        	"Trade.user" => $this->authUser['Agency']['name'],
		        "Trade.status" => 1,
		        "DATE(Trade.created) >=" => date("Y-m-01")
	        ]
        ]);
	    $sum_sell = intval($sum_sell[0]["total_gold"]);
        $this->set(compact("sum_sell"));

	    $sum_buy = $this->Trade->find("first", [
		    "fields" => [
			    "SUM(Trade.gold) as total_gold"
		    ],
		    "conditions" => [
			    "Trade.user_target" => $this->authUser['Agency']['name'],
			    "Trade.status" => 4,
			    "DATE(Trade.created) >=" => date("Y-m-01")
		    ]
	    ]);
	    $sum_buy = intval($sum_buy[0]["total_gold"]);
	    $this->set(compact("sum_buy"));
      $this->set(compact("agency2"));
      $this->set(compact("agency1"));
    }


	public function getUserNameById() {
		$dataGet    = $this->request->query;
		$id       = isset( $dataGet['id'] ) ? trim( $dataGet["id"] ) : null;
		$dataReturn = [
			"status" => false,
			"data"   => null
		];
		if ( $id ) {
			$user = $this->User->find( 'first', [
				'recursive'  => - 1,
				'conditions' => [
					'id' => $id
				]
			] );
			if ( $user ) {
				$dataReturn["status"] = true;
				$dataReturn["data"]   = $user["User"]["displayname"];
			}
		}
		header( "Content-type: application/json" );
		echo json_encode( $dataReturn );
		die;
	}

    public function dailyc2() {
	    $this->set('title_for_layout', 'Đại lý cấp 2');
	    $this->set('activeMenu', 'dailyc2');

	    $this->paginate = [
	    	"conditions" => [
	    		"parent" => $this->authUser["Agency"]["userid"]
		    ]
	    ];

	    $data = $this->paginate("Agency");
	    $this->set(compact("data"));
    }

	public function addc2() {
		$this->set('title_for_layout', 'Thêm mới đại lý cấp 2');
		$this->set('activeMenu', 'dailyc2');

		if ($this->request->is('post')) {
			$dataPost = $this->request->data;
			$exist = $this->Agency->findByName($dataPost["Agency"]["name"]);
			if ($exist) {
				$this->Flash->error("Tài khoản " . $dataPost["Agency"]["name"] . " đã là đại lý");
			} else {
				$this->Agency->create();
				$this->request->data['Agency']['parent'] = $this->authUser['Agency']['userid'];
				$this->request->data['Agency']['password'] = md5($this->request->data['Agency']['password']);
				//missing some params
				$user = $this->User->findById($dataPost['Agency']['userid']);
				if ($user) {

					$this->request->data['Agency']['username'] = $user['User']['username'];
					$this->request->data['Agency']['address'] = $this->authUser['Agency']['address'];
					$this->request->data['Agency']['face'] = 'not found';
					$this->request->data['Agency']['num'] = 0;
					$this->request->data['Agency']['level'] = 0;
					$this->request->data['Agency']['gold'] = 0;
					$this->request->data['Agency']['subgold'] = 0;
					$this->request->data['Agency']['created'] = date('Y-m-d H:i:s');

					if ($this->Agency->save($this->request->data)) {
						$this->Flash->success(__('Thêm mới đại lý cấp 2 thành công.'));
						$this->User->updateAll([
							'agency' => 1
						], [
							'id' => $dataPost["Agency"]["userid"]
						]);

						$this->sendKichhoat($user);

						return $this->redirect(array('action' => 'dailyc2'));
					}
				} else {
					$this->Flash->error(__('The agency could not be saved. Please, try again.'));
				}
			}
		}
	}

	private function sendKichhoat($user)
    {
        $d = Security::hash($user['User']['id'] . "+" . KEY_ENCODE, "sha256");

        $secret = KEY_ENCODE;

        $token = hash_hmac("sha256", $d, $secret); // create signature to check
        $url = url_admin_created_agency . 'token=' . $token . '&userid=' . $user['User']['id'];

        $httpSocket = new HttpSocket();
        $response = $httpSocket->get($url);
        if ($response == "thanh cong") {
            return 0;
        } else {
            return 1;
        }
    }

	public function editc2($id = null) {
		$this->set('title_for_layout', 'Chỉnh sửa đại lý cấp 2');
		$this->set('activeMenu', 'dailyc2');


    	$agency = $this->Agency->findById($id);
    	if (!$agency || $agency["Agency"]["parent"] != $this->authUser["Agency"]["userid"]) {
    		return $this->redirect(["action" => "dailyc2"]);
	    }

		if ($this->request->is(array('post', 'put'))) {
			if (!empty($this->request->data['Agency']['password'])) {
				$this->request->data['Agency']['password'] = md5($this->request->data['Agency']['password']);
			} else {
				unset($this->request->data['Agency']['password']);
			}
			if ($this->Agency->save($this->request->data)) {
				$this->Flash->success(__('Cập nhật đại lý thành công'));
				return $this->redirect(array('action' => 'dailyc2'));
			} else {
				$this->Flash->error(__('The agency could not be saved. Please, try again.'));
			}
		} else {
			$this->request->data = $agency;
		}
	}

	public function delc2($id = null) {
		$agency = $this->Agency->findById($id);
		if (!$agency || $agency["Agency"]["parent"] != $this->authUser["Agency"]["userid"]) {
			return $this->redirect(["action" => "dailyc2"]);
		}

		$this->Agency->id = $id;
		if ($this->Agency->delete()) {
			$this->User->updateAll([
				'agency' => 0
			], [
				'id' => $agency["Agency"]["userid"]
			]);
			$this->Flash->success(__('Xoá đại lý thành công.'));
		} else {
			$this->Flash->error(__('The gift code could not be deleted. Please, try again.'));
		}
		return $this->redirect(array('action' => 'dailyc2'));
	}

	public function thongkec2() {
		$this->set('title_for_layout', 'Thêm mới đại lý cấp 2');
		$this->set('activeMenu', 'thongkec2');

		$dataGet = $this->request->query;

		$conditions = [];


		if ( isset( $dataGet["start_date"] ) && $dataGet["start_date"] ) {
			$conditions["DATE(Trade.created) >="] = $dataGet["start_date"];
			$conditions["DATE(Trade.created) <="] = $dataGet["end_date"];
		} else {
			$conditions["DATE(Trade.created) >="] = date( "Y-m-01" );
			$conditions["DATE(Trade.created) <="] = date( "Y-m-d" );
		}
		if ( isset( $dataGet["type"] ) && is_array( $dataGet["type"] ) ) {
			if ( count( $dataGet["type"] ) == 1 ) {
				if ( $dataGet["type"][0] == 1 ) {
					$conditions["AND"]["OR"] = [
						[
							"User.agency"       => 1,
							"UserTarget.agency" => 0,
						],
						[
							"User.agency"       => 0,
							"UserTarget.agency" => 1,
						]
					];
				} else {
					$conditions["User.agency"]       = 1;
					$conditions["UserTarget.agency"] = 1;
				}
			}
		}

		$this->Trade->recursive = -1;

		$dataReturn = [
			"total_gold_chuyen" => 0,
			"total_gold_nhan" => 0,
			"list" => [],
		];

		$conds = [];
		if (isset($dataGet["keyword"]) && !empty($dataGet["keyword"])) {
			$conds[] = ["Agency.name" => $dataGet["keyword"]];
		}

		$children = $this->Agency->find('all', [
			'recursive' => -1,
			'fields' => ['name'],
			'conditions' => [
				'parent' => $this->authUser["Agency"]["userid"],
				$conds
			]
		]);
		$arr_child = [];
		foreach ($children as $item) {
			$arr_child[] = $item["Agency"]["name"];
		}

		$arr_day = $this->Trade->find('all', [
			'fields' => ['DISTINCT DATE(Trade.created) as created'],
			'joins'      => array(
				array(
					'table'      => 'user_vics',
					'alias'      => 'User',
					'type'       => 'INNER',
					'conditions' => array(
						'User.displayname = Trade.user',
					)
				),
				array(
					'table'      => 'user_vics',
					'alias'      => 'UserTarget',
					'type'       => 'INNER',
					'conditions' => array(
						'UserTarget.displayname = Trade.user_target',
					)
				)
			),
			"conditions" => [
				"OR" => [
					"Trade.user" => $arr_child,
					"Trade.user_target" => $arr_child,
				],
				$conditions
			],
			'order' => 'Trade.created ASC'
		]);


		foreach ($arr_day as $date) {
			$curDate = $date[0]["created"];
			foreach ($children as $child) {
				$sum_chuyen = $this->Trade->find("first", [
					"fields" => [
						"SUM(Trade.gold) as total_gold"
					],
					'joins'      => array(
						array(
							'table'      => 'user_vics',
							'alias'      => 'User',
							'type'       => 'INNER',
							'conditions' => array(
								'User.displayname = Trade.user',
							)
						),
						array(
							'table'      => 'user_vics',
							'alias'      => 'UserTarget',
							'type'       => 'INNER',
							'conditions' => array(
								'UserTarget.displayname = Trade.user_target',
							)
						)
					),
					"conditions" => [
						"Trade.user" => $child["Agency"]["name"],
						"Trade.status" => 1,
						"DATE(Trade.created)" => $curDate,
						$conditions
					]
				]);

				$sum_nhan = $this->Trade->find("first", [
					"fields" => [
						"SUM(Trade.gold) as total_gold"
					],
					'joins'      => array(
						array(
							'table'      => 'user_vics',
							'alias'      => 'User',
							'type'       => 'INNER',
							'conditions' => array(
								'User.displayname = Trade.user',
							)
						),
						array(
							'table'      => 'user_vics',
							'alias'      => 'UserTarget',
							'type'       => 'INNER',
							'conditions' => array(
								'UserTarget.displayname = Trade.user_target',
							)
						)
					),
					"conditions" => [
						"Trade.user_target" => $child["Agency"]["name"],
						"Trade.status" => 4,
						"DATE(Trade.created)" => $curDate,
						$conditions
					]
				]);

				$dataReturn["list"][] = [
					"created" => $curDate,
					"name" => $child["Agency"]["name"],
					"gold_chuyen" => intval($sum_chuyen[0]["total_gold"]),
					"gold_nhan" => intval($sum_nhan[0]["total_gold"]),
				];

				$dataReturn["total_gold_chuyen"] += intval($sum_chuyen[0]["total_gold"]);
				$dataReturn["total_gold_nhan"] += intval($sum_nhan[0]["total_gold"]);
			}
		}
		$this->set(compact("dataReturn"));
	}

	public function thuhoigd() {
		$this->set('title_for_layout', 'Thu hồi giao dịch cho C2');
		$this->set('activeMenu', 'thuhoigd');

		if ($this->request->is("post")){
			$dataPost = $this->request->data;
			$httpSocket = new HttpSocket();
			$id = $dataPost["Trade"]["id"];
			$data = 'id=' . $id . "&name=" . $this->authUser["Agency"]["name"];

			$secret = KEY_ENCODE; //product's secret key (get value from 1Pay product detail)

			$token = hash_hmac( "sha256", $data, $secret ); // create signature to check


			$url      = url_user_dlthuhoihey . 'token=' . $token . "&id=" . $id . "&name=" . $this->authUser["Agency"]["name"];
			$response = json_decode( $httpSocket->get( $url ), true );
			if ( isset( $response["status"] ) && $response["status"] == 0 ) {
				$this->Flash->success( $response["mess"] );
			} else {
				$this->Flash->error( $response["mess"] );
			}

			return $this->redirect( ["action" => "dailyc2"] );
		}
	}

	public function getTradeInfo() {
    	if (!$this->request->is("ajax")) {
    		throw new NotFoundException();
	    }
		$dataGet    = $this->request->query;
		$id       = isset( $dataGet['id'] ) ? trim( $dataGet["id"] ) : null;
		$dataReturn = [
			"status" => false,
			"data"   => null
		];
		if ( $id ) {
			$children = $this->Agency->find('all', [
				'recursive' => -1,
				'fields' => ['name'],
				'conditions' => [
					'parent' => $this->authUser["Agency"]["userid"],
				]
			]);
			$arr_child = [];
			foreach ($children as $item) {
				$arr_child[] = $item["Agency"]["name"];
			}

			$trade = $this->Trade->find( 'first', [
				'recursive'  => - 1,
				'conditions' => [
					'id' => $id,
					'user' => $arr_child
				]
			] );
			if ( $trade && $trade["Trade"]["status"] != 2) {
				$dataReturn["status"] = true;
				$dataReturn["data"]   = $trade["Trade"];
			}
		}
		header( "Content-type: application/json" );
		echo json_encode( $dataReturn );
		die;
	}
}
