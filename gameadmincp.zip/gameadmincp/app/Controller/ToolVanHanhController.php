<?php

App::uses( 'HttpSocket', 'Network/Http' );
class ToolVanHanhController extends AppController
{
    public $uses = ['GameTaixiuResult', 'SlotGame', 'Minigame', 'User', 'AdminChangeGold', 'Agency'];

    public function tai_xiu() {
        $this->set('title_for_layout', 'Tài xỉu: Tool Vận Hành');
        $this->set('activeMenu', 'tool_taixiu');

        $this->set("data",$this->GameTaixiuResult->query('select * from game_taixiu_results order by id desc limit 1'));

        $data = $this->request->query;
        //cmd game tài xỉu
        $CMD_ID = 4;

        if(isset($data['content'])) {
            $d = Security::hash($data['content'] . "+" .$CMD_ID . "+" . KEY_ENCODE, "sha256");

            $secret = KEY_ENCODE;

            $token = hash_hmac("sha256", $d, $secret); // create signature to check
            $url = url_adminmanager . 'token=' . $token . "&content=" . $data['content'] . '&code=' . $CMD_ID;
            $httpSocket = new HttpSocket();
            $response = $httpSocket->get($url);
            if ($response == "thanhh cong") {
                $this->Flash->success("Thành công");
            }else{
                $this->Flash->error("Xử lý không thành công." .$response);
            };
        }

    }


    public function slot() {
        $this->set('title_for_layout', 'Slot: Tool Vận Hành');
        $this->set('activeMenu', 'tool_slot');
        $this->set('data', $this->SlotGame->find('all'));
        $data = $this->request->query;

        if(isset($data['content'])) {
            $d = Security::hash($data['content'] . "+" . $data['command_id'] . "+" . KEY_ENCODE, "sha256");

            $secret = KEY_ENCODE;

            $token = hash_hmac("sha256", $d, $secret); // create signature to check
            $url = url_adminmanager . 'token=' . $token . "&content=" . $data['content'] . '&code=' . $data['command_id'];
            $httpSocket = new HttpSocket();
            $response = $httpSocket->get($url);
            if ($response == "thanhh cong") {
                $this->Flash->success("Thành công");
            }else{
                $this->Flash->error("Xử lý không thành công." .$response);
            };
        }
    }

    public function mini() {
        $this->set('title_for_layout', 'Mini: Tool Vận Hành');
        $this->set('activeMenu', 'tool_mini');
        $this->set('data', $this->Minigame->find('all'));
        $data = $this->request->query;

        if(isset($data['content'])) {
            $d = Security::hash($data['content'] . "+" . $data['command_id'] . "+" . KEY_ENCODE, "sha256");

            $secret = KEY_ENCODE;

            $token = hash_hmac("sha256", $d, $secret); // create signature to check
            $url = url_adminmanager . 'token=' . $token . "&content=" . $data['content'] . '&code=' . $data['command_id'];
            $httpSocket = new HttpSocket();
            $response = $httpSocket->get($url);
            if ($response == "thanhh cong") {
                $this->Flash->success("Thành công");
            }else{
                $this->Flash->error("Xử lý không thành công." .$response);
            };
        }
    }

    public function bao_tri(){
        $this->set('title_for_layout', 'Bảo trì: Tool Vận Hành');
        $this->set('activeMenu', 'bao_tri');
        $data = $this->request->query;
        if(isset($data['time'])) {
            $d = Security::hash($data['time'] . "+" . "content" . "+" . KEY_ENCODE, "sha256");

            $secret = KEY_ENCODE;

            $token = hash_hmac("sha256", $d, $secret); // create signature to check
            $url = url_admin_maintain . 'token=' . $token . "&content=" . "content" . '&time=' . $data['time'];
            $httpSocket = new HttpSocket();
            $response = $httpSocket->get($url);
            $this->Flash->success($response);
        }

    }

    public function getUserIdByName() {
        $dataGet    = $this->request->query;
        $name       = isset( $dataGet['name'] ) ? trim( $dataGet["name"] ) : null;
        $dataReturn = [
            "status" => false,
            "data"   => null
        ];
        if ( $name ) {
            $user = $this->User->find( 'first', [
                'recursive'  => - 1,
                'conditions' => [
                    'displayname' => $name
                ]
            ] );
            if ( $user ) {
                $dataReturn["status"] = true;
                $dataReturn["data"]   = $user["User"]["id"];
            }
        }
        header( "Content-type: application/json" );
        echo json_encode( $dataReturn );
        die;
    }

    public function cong_tru_tien(){
        $this->set('title_for_layout', 'Cộng trừ tiền: Tool Vận Hành');
        $this->set('activeMenu', 'cong_tru_tien');
        $param = $this->request->data;
        if(isset($param['userTarget'])) {

            $user = $this->User->find("first",[
                'conditions' => [
                    'displayname' => $param['userTarget']
                ]
            ]);
            if(count($user) == 0){
                $this->Flash->success("Không tìm thấy User.");
            }else {
                $d = Security::hash($user['User']['id'] . "+" . $param['title'] . "+" . $param['gold'] . "+" . $param['content'] . "+" . KEY_ENCODE, "sha256");

                $secret = KEY_ENCODE;

                $token = hash_hmac("sha256", $d, $secret); // create signature to check
                $url = url_admin_send_gold . 'token=' . $token . "&content=" . $param['content'] . '&title=' . $param['title'] . '&userid=' . $user['User']['id'] . '&gold=' . $param['gold'] . '&type=' . 1;
                echo $url;
//                die;
                $httpSocket = new HttpSocket();
                $response = $httpSocket->get($url);
                if ($response == "thanh cong") {
                    $admin = $this->Session->read('USER_LOGIN');
                    $this->AdminChangeGold->save(array(
                        'user_target' => $param['userTarget'],
                        'title' => $param['title'],
                        'content' => $param['content'],
                        'gold' => $param['gold'],
                        'admin' => $admin['AdmincpMember']['username'],
                        'type' => 0,
                        'created' => date("Y-m-d H:i:s"),
                    ));
                    $this->Flash->success("Xử lý thành công.");
                } else {
                    $this->Flash->error("Xử lý không thành công.");
                }
            }
        }

    }

    public function cong_tru_tien_code(){
        $this->set('title_for_layout', 'Cộng trừ tiền code: Tool Vận Hành');
        $this->set('activeMenu', 'cong_tru_tien_code');
        $param = $this->request->data;
        if(isset($param['userTarget'])) {

            $agency = $this->Agency->find("first",[
                'conditions' => [
                    'name' => $param['userTarget']
                ]
            ]);
            if(count($agency) == 0){
                $this->Flash->success("Không tìm thấy Đại lý.");
            }else {
                $this->Agency->save(array(
                    'id' => $agency['Agency']['id'],
                    'subgold' => $agency['Agency']['subgold'] + $param['gold'],
                ));

                $admin = $this->Session->read('USER_LOGIN');
                $this->AdminChangeGold->save(array(
                    'user_target' => $param['userTarget'],
                    'title' => $param['title'],
                    'content' => $param['content'],
                    'gold' => $param['gold'],
                    'admin' => $admin['AdmincpMember']['username'],
                    'type' => 1,
                    'created' => date("Y-m-d H:i:s"),
                ));
                $this->Flash->success("Xử lý thành công.");
            }
        }
    }

    public function code_dac_biet() {
        $this->set('title_for_layout', 'CODE đặc biệt');
        $this->set('activeMenu', 'code_dac_biet');
        $this->loadModel('SpecialCode');
        $this->paginate = [
            'fields' => [
                'SpecialCode.*',
                '(Select COUNT(*) from user_special_codes where special_id = SpecialCode.id) as total'
            ],
            'order' => 'SpecialCode.id DESC'
        ];
        $data = $this->paginate('SpecialCode');
        $this->set(compact('data'));
    }

    public function tao_code_dac_biet() {
        $this->set('title_for_layout', 'Tạo CODE đặc biệt');
        $this->set('activeMenu', 'code_dac_biet');
        $this->loadModel('SpecialCode');
        if ($this->request->is(['post', 'put'])) {
            $data_post = $this->request->data;
            $chkCode = $this->SpecialCode->find('first', ['conditions' => ['SpecialCode.code' => $data_post['SpecialCode']['code']]]);
            if ($chkCode) {
                $this->Flash->error('CODE: ' . $data_post['SpecialCode']['code'] . ' đã tồn tại.');
            } else {
                if ($this->SpecialCode->save($data_post['SpecialCode'])) {
                    $this->Flash->success('Tạo CODE đặc biệt thành công.');
                    return $this->redirect(['action' => 'code_dac_biet']);
                } else {
                    $this->Flash->error('Có lỗi xảy ra.');
                }
            }
        }
    }

    public function event_code() {
        $this->set('title_for_layout', 'Quản lý Event');
        $this->set('activeMenu', 'tool_event');
        $this->loadModel('EventCode');
		$this->EventCode->recursive = 0;

        $admin = $this->Session->read('USER_LOGIN');
        if(!isset($admin)){
            $this->Session->destroy();
            return $this->redirect(['action' => 'login']);
        }
        $this->paginate = [
            'order' => 'EventCode.id DESC',
            'conditions' => [
                'EventCode.agencyId' => $admin['AdmincpMember']['id']
            ]
        ];


        $this->set('eventCodes', $this->paginate('EventCode'));
    }
}
