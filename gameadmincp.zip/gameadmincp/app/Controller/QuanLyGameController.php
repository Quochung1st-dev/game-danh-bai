<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */


class QuanLyGameController extends AppController
{
    public $uses = [ 'GameTaixiuResult', 'GameTaixiuUserResult', 'GameSlotResult', 'Bigwin'];
    public $components = array('Paginator');
    public function tra_cuu_phien_tai_xiu() {
        $this->set('title_for_layout', 'Tra cứu phiên tài xỉu');
        $this->set('activeMenu', 'tra_cuu_phien_tai_xiu');

        $search = $this->request->query('keyword');
        $game = $this->GameTaixiuResult->find("first",[
            'conditions' => [
                'GameTaixiuResult.gameID' => $search
            ]
        ]);

        $this->paginate = [
            'conditions' => [
                'GameTaixiuUserResult.gameID' => $search
            ]
        ];
        $this->set('listUser', $this->Paginator->paginate('GameTaixiuUserResult'));
        $this->set('game', $game);

    }

    public function tra_cuu_phien_slot() {
        $this->set('title_for_layout', 'Tra cứu phiên slot');
        $this->set('activeMenu', 'tra_cuu_phien_slot');

        $dataGet = $this->request->query;
        if ( !isset( $dataGet["keyword"] )){
            $this->set("isData" , false);
        }else {
            $this->set("isData" , true);

            $conditions = [
                'GameSlotResult.spin_id' => $dataGet["keyword"]
            ];

            if (isset($dataGet["status"]) && is_array($dataGet["status"])) {
                $conditions["GameSlotResult.gameID IN"] = $dataGet["status"];
            }

            $data = $this->GameSlotResult->find("first",[
                'conditions' => $conditions
            ]);
            $this->set('data', $data);

        }
    }

    public function tra_cuu_no_hu() {
        $this->set('title_for_layout', 'Tra cứu nổ hũ');
        $this->set('activeMenu', 'tra_cuu_no_hu');
        $dataGet = $this->request->query;
        $conditions = [];
        if (isset($dataGet["start_date"]) && $dataGet["start_date"]) {
            $conditions["DATE(Bigwin.created) >="] = $dataGet["start_date"];
            $conditions["DATE(Bigwin.created) <="] = $dataGet["end_date"];
        } else {
            $conditions["DATE(Bigwin.created) >="] = date("Y-m-01");
            $conditions["DATE(Bigwin.created) <="] = date("Y-m-d");
        }
        if (isset($dataGet["status"]) && $dataGet["status"][0] > 0 && is_array($dataGet["status"])) {
            $conditions["Bigwin.gameID IN"] = $dataGet["status"];
        }

        $this->paginate = [
            'conditions' => $conditions,
            'order' => 'id desc'
        ];
        $this->set('games', $this->Paginator->paginate('Bigwin'));
    }

}
