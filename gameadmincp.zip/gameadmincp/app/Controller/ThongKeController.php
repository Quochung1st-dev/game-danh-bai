<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */


class ThongKeController extends AppController
{
    public $components = array('Paginator');
    public $uses = ['User', 'GameChangeGold', 'UserChangeGold', 'GameSlotResult', 'ListCard', 'Dailythe', 'Trade'];

    PUBLIC $GAME_ID_MINI_TAI_XIU = 1;
    PUBLIC $GAME_ID_MINI_SLOT_1 = 2;
    PUBLIC $GAME_ID_MINI_SLOT_2 = 3;
    PUBLIC $GAME_ID_MINI_CAO_THAP = 4;
    PUBLIC $GAME_ID_MINI_POKER = 5;

    PUBLIC $GAME_ID_SLOT_25 = 6;
    PUBLIC $GAME_ID_SLOT_20 = 7;
    PUBLIC $GAME_ID_SLOT_20_1 = 8;
    PUBLIC $GAME_ID_SLOT_20_2 = 9;

    PUBLIC $GAME_ID_BAN_CA = 20;

    PUBLIC $GAME_ID_GAME_BAI_TAI_XIU = 21;
    PUBLIC $GAME_ID_GAME_BAI_LIENG = 22;
    PUBLIC $GAME_ID_GAME_BAI_MAU_BINH = 23;
    PUBLIC $GAME_ID_GAME_BAI_TA_LA = 24;
    PUBLIC $GAME_ID_GAME_BAI_TLMN = 25;
    PUBLIC $GAME_ID_GAME_BAI_SAM = 26;
    PUBLIC $GAME_ID_GAME_BAI_BA_CAY = 27;
    PUBLIC $GAME_ID_GAME_BAI_XI_TO = 28;
    PUBLIC $GAME_ID_GAME_BAI_XOC_DIA = 29;
    PUBLIC $GAME_ID_GAME_BAI_POKER = 30;
    PUBLIC $GAME_ID_GAME_BAI_POKER_TOURNAMENT = 31;

    PUBLIC $GAME_ID_NAP_THE = 100;
    PUBLIC $GAME_ID_NAP_DAI_LY = 101;
    PUBLIC $GAME_ID_SMS = 102;
    PUBLIC $GAME_ID_EVENT = 103;
    PUBLIC $GAME_ID_CODE = 104;
    PUBLIC $GAME_ID_NPH = 105;
    PUBLIC $GAME_ID_PHAT_LOC = 107;
    PUBLIC $GAME_ID_VQMM = 108;
    PUBLIC $GAME_ID_OTHER = 106;

    public function thong_ke_user() {
        $this->set('title_for_layout', 'Thống kê user');
        $this->set('activeMenu', 'thong_ke_user');
        $dataGet = $this->request->query;

        if ( !isset( $dataGet["start_date"] )){
            $this->set("isData" , false);
        }else {
            $this->set("isData", true);
            $wh = "";
            if (isset($dataGet["start_date"]) && $dataGet["start_date"]) {
                $conditions["DATE(UserChangeGold.created) >="] = $dataGet["start_date"];
                $conditions["DATE(UserChangeGold.created) <="] = $dataGet["end_date"];
                $wh = "DATE(created) >= '".$dataGet["start_date"] . "' and DATE(created) <='".$dataGet["end_date"] . "'";
            } else {
                $conditions["DATE(UserChangeGold.created) >="] = date("Y-m-01");
                $conditions["DATE(UserChangeGold.created) <="] = date("Y-m-d");
                $wh = "DATE(created) >= '".date("Y-m-01") ."' and DATE(created) <='".date("Y-m-d")."'";
            }
            $order = 'userid DESC';
            if (isset($dataGet['key_sort'])) {
                $order = str_replace('_', ' ', $dataGet['key_sort']);
            }
            $this->paginate = [
                'fields' => array(
                    "UserChangeGold.*",
                    'sum(phe) as totalphe',
                    '(select sum(gold_in) from user_change_golds where userid = UserChangeGold.userid and gameid = '.$this->GAME_ID_NAP_DAI_LY.' and '.$wh .") as luongmua",
                    '(select sum(gold_out) from user_change_golds where userid = UserChangeGold.userid and gameid = '.$this->GAME_ID_NAP_DAI_LY.' and '.$wh .") as luongban",
                    '(select sum(card_num) from list_cards where userID = UserChangeGold.userid and status = 1 and '.$wh .") as luongthe",
                    '(select sum(gold_out) from user_change_golds where userid = UserChangeGold.userid and gameid < 100 and '. $wh .') as luongtong',
                ),
                'conditions' => $conditions,
                'group' => 'userid',
                'order' => $order
            ];
            $this->set('listUser', $this->Paginator->paginate('UserChangeGold'));
        }

    }

    function getStatusStr($id) {
        switch ($id) {
            case 1:
                return "Tài Xỉu";
            case 6:
                return "Tây du ký";
            case 7:
                return "Avengers";
            case 9:
                return "Justice League";
            case 2:
                return "Kim cương";
            case 3:
                return "Mèo thần tài";
            case 4:
                return "Cao Thap";
            case 5:
                return "Mini Poker";
            case 20:
                return "Bắn cá";
            case 26:
                return "Sâm";
            case 27:
                return "Ba cây";
            case 25:
                return "TLMN";
            case 23:
                return "Mậu Binh";
            case 100:
                return "Nạp thẻ";
            case 101:
                return "Nạp đại lý";
            case 104:
                return "GiftCode";
            case 108:
                return "VQMM";
            case 102:
                return "SMS";
            case 107:
                return "Phát Lộc";
            case 106:
                return "Giao dịch khác";
            default:
                return "Khác";
        }
    }

    public function thong_ke_phe() {
        $this->set('title_for_layout', 'Thống kê phế');
        $this->set('activeMenu', 'thong_ke_phe');

        $dataGet = $this->request->query;
        if ( !isset( $dataGet["status"] )){
            $this->set("isData" , false);
        }else {
            $this->set("isData", true);
//        if ( isset( $dataGet["keyword"] ) && trim( $dataGet["keyword"] ) != "" ) {
//            $conditions["OR"] = [
//                "Trade.id"         => $dataGet["keyword"],
//                "User.displayname" => $dataGet["keyword"]
//            ];
//        }
//            pr($dataGet);
            if (isset($dataGet["status"]) && $dataGet["status"][0] > 0 && is_array($dataGet["status"])) {
                $conditions["GameChangeGold.gameID IN"] = $dataGet["status"];
                $conditions1["GameChangeGold.gameID IN"] = $dataGet["status"];
            } else {
                $conditions = [
                    'GameChangeGold.gameid >' => 0
                ];
                $conditions1 = [
                    'GameChangeGold.gameid >' => 0
                ];
            }


            if (isset($dataGet["start_date"]) && $dataGet["start_date"]) {
                $conditions["DATE(GameChangeGold.created) >="] = $dataGet["start_date"];
                $conditions["DATE(GameChangeGold.created) <="] = $dataGet["end_date"];
            } else {
                $conditions["DATE(GameChangeGold.created) >="] = date("Y-m-01");
                $conditions["DATE(GameChangeGold.created) <="] = date("Y-m-d");
            }

            $phes = $this->GameChangeGold->find('all',
                [
                    'fields' => array(
                        'sum(gold_in) as gold_in',
                        'sum(gold_out) as gold_out',
                        'gameid',
                        'DATE(created) as date',
                        'sum(phe) as phe'
                    ),
                    'conditions' => $conditions,
                    "group" => "gameid, DATE(created)",
                    "order" => "date, phe desc"
                ]
            );
            for($i = 0; $i < count($phes); $i++){
                $phes[$i]['GameChangeGold']['gamename'] = $this->getStatusStr($phes[$i]['GameChangeGold']['gameid']);
            }
            $phetong = $this->GameChangeGold->find('all',
                [
                    'fields' => array(
                        'sum(gold_in) as gold_in',
                        'sum(gold_out) as gold_out',
                        'gameid',
                        'sum(phe) as phe'
                    ),
                    'conditions' => $conditions1
                ]
            );

            $this->set('phe', $phes);
            $this->set('phetong', $phetong);
        }

    }

    public function thong_ke_nap() {
        $this->set('title_for_layout', 'Thống kê nạp');
        $this->set('activeMenu', 'thong_ke_nap');

        $dataGet = $this->request->query;
        if ( !isset( $dataGet["status"] )){
            $this->set("isData" , false);
        }else {
            $this->set("isData", true);

            if (isset($dataGet["status"]) && $dataGet["status"][0] > 0 && is_array($dataGet["status"])) {
                $conditions["ListCard.khid IN"] = $dataGet["status"];
                $conditions1["ListCard.khid IN"] = $dataGet["status"];
            } else {
                $conditions = [
                    'ListCard.khid >' => 0
                ];
            }

            $conditions["ListCard.status"] = 1;
            if (isset($dataGet["start_date"]) && $dataGet["start_date"]) {
                $conditions["DATE(ListCard.created) >="] = $dataGet["start_date"];
                $conditions["DATE(ListCard.created) <="] = $dataGet["end_date"];
            } else {
                $conditions["DATE(ListCard.created) >="] = date("Y-m-01");
                $conditions["DATE(ListCard.created) <="] = date("Y-m-d");
            }

            $kh = $this->Dailythe->find("all");
            $napthe = $this->ListCard->find('all',
                [
                    'fields' => array(
                        'sum(card_num) as tongnap',
                        'khid',
                        'DATE(created) as date',
                    ),
                    'conditions' => $conditions,
                    "group" => "khid, DATE(created)",
                    "order" => "date, tongnap desc"
                ]
            );
            for($i = 0; $i < count($napthe); $i++){
                $napthe[$i]['ListCard']['name'] = $kh[$napthe[$i]['ListCard']['khid'] - 1]['Dailythe']['username'];
            }
//            pr($napthe);
//            die;
            $this->set('napthe', $napthe);
        }
    }


    public function thong_ke_chung() {
        $this->set('activeMenu', 'thong_ke_chung');
        $this->set('title_for_layout', 'Thống kê chung');

        $start_date = $this->request->query('start_date') ? $this->request->query('start_date') : date('Y-m-01');
        $end_date = $this->request->query('end_date') ? $this->request->query('end_date') : date('Y-m-d');

        if ($start_date && $end_date) {
            //User đăng ký trong ngày
            $nru_ios = $this->User->find('count', [
                'recursive' => -1,
                'conditions' => [
                    'DATE(User.created) >=' => $start_date,
                    'DATE(User.created) <=' => $end_date,
                    'User.typeOS' => 1
                ]
            ]);
            $nru_android = $this->User->find('count', [
                'recursive' => -1,
                'conditions' => [
                    'DATE(User.created) >=' => $start_date,
                    'DATE(User.created) <=' => $end_date,
                    'User.typeOS' => 2
                ]
            ]);
            $nru_web = $this->User->find('count', [
                'recursive' => -1,
                'conditions' => [
                    'DATE(User.created) >=' => $start_date,
                    'DATE(User.created) <=' => $end_date,
                    'User.typeOS' => 0
                ]
            ]);
            $this->set('nru', [
                'ios' => $nru_ios,
                'android' => $nru_android,
                'web' => $nru_web
            ]);

            //User đăng nhập trong ngày.
            $this->loadModel('LogUserLogin');
            $lu_ios = $this->LogUserLogin->find('first', [
                'fields' => [
                    'COUNT(DISTINCT(`LogUserLogin`.`userID`)) as total'
                ],
                'recursive' => -1,
                'conditions' => [
                    'DATE(LogUserLogin.createdDate) >=' => $start_date,
                    'DATE(LogUserLogin.createdDate) <=' => $end_date,
                    'LogUserLogin.os_flatform' => 'ios'
                ]
            ]);
            $lu_android = $this->LogUserLogin->find('first', [
                'fields' => [
                    'COUNT(DISTINCT(`LogUserLogin`.`userID`)) as total'
                ],
                'recursive' => -1,
                'conditions' => [
                    'DATE(LogUserLogin.createdDate) >=' => $start_date,
                    'DATE(LogUserLogin.createdDate) <=' => $end_date,
                    'LogUserLogin.os_flatform' => 'android'
                ]
            ]);
            $lu_web = $this->LogUserLogin->find('first', [
                'fields' => [
                    'COUNT(DISTINCT(`LogUserLogin`.`userID`)) as total'
                ],
                'recursive' => -1,
                'conditions' => [
                    'DATE(LogUserLogin.createdDate) >=' => $start_date,
                    'DATE(LogUserLogin.createdDate) <=' => $end_date,
                    'LogUserLogin.os_flatform' => 'web'
                ]
            ]);
            $this->set('lu', [
                'ios' => $lu_ios[0]['total'],
                'android' => $lu_android[0]['total'],
                'web' => $lu_web[0]['total']
            ]);

            //Tổng số thành viên
            $total_member = $this->User->find('count');
            $this->set(compact('total_member'));

            //Tiền nạp trong ngày
            $total_charge_1 = $this->ListCard->find('first', [
                'fields' => [
                    'SUM(ListCard.card_num) as total'
                ],
                'conditions' => [
                    'DATE(ListCard.created) >=' => $start_date,
                    'DATE(ListCard.created) <=' => $end_date,
                    'ListCard.status' => 1,
                    'ListCard.khid' => 1
                ],
                'group' => 'ListCard.khid'
            ]);
            $total_charge_2 = $this->ListCard->find('first', [
                'fields' => [
                    'SUM(ListCard.card_num) as total'
                ],
                'conditions' => [
                    'DATE(ListCard.created) >=' => $start_date,
                    'DATE(ListCard.created) <=' => $end_date,
                    'ListCard.status' => 1,
                    'ListCard.khid' => 2
                ],
                'group' => 'ListCard.khid'
            ]);
            $total_charge_3 = $this->ListCard->find('first', [
                'fields' => [
                    'SUM(ListCard.card_num) as total'
                ],
                'conditions' => [
                    'DATE(ListCard.created) >=' => $start_date,
                    'DATE(ListCard.created) <=' => $end_date,
                    'ListCard.status' => 1,
                    'ListCard.khid' => 3
                ],
                'group' => 'ListCard.khid'
            ]);
            $this->set('total_charge', [
                'paygate_1' => isset($total_charge_1[0]) ? $total_charge_1[0]['total'] : 0,
                'paygate_2' => isset($total_charge_2[0]) ? $total_charge_2[0]['total'] : 0,
                'paygate_3' => isset($total_charge_3[0]) ? $total_charge_3[0]['total'] : 0
            ]);
            //Tong so phe
            $phe_tx = $this->GameChangeGold->find('first', [
                'fields' => [
                    'SUM(GameChangeGold.phe) as total'
                ],
                'conditions' => [
                    'DATE(GameChangeGold.created) >=' => $start_date,
                    'DATE(GameChangeGold.created) <=' => $end_date,
                    'GameChangeGold.gameid IN' => [1]
                ]
            ]);
            $phe_slot = $this->GameChangeGold->find('first', [
                'fields' => [
                    'SUM(GameChangeGold.phe) as total'
                ],
                'conditions' => [
                    'DATE(GameChangeGold.created) >=' => $start_date,
                    'DATE(GameChangeGold.created) <=' => $end_date,
                    'GameChangeGold.gameid IN' => [6,7,9]
                ]
            ]);
            $phe_minislot = $this->GameChangeGold->find('first', [
                'fields' => [
                    'SUM(GameChangeGold.phe) as total'
                ],
                'conditions' => [
                    'DATE(GameChangeGold.created) >=' => $start_date,
                    'DATE(GameChangeGold.created) <=' => $end_date,
                    'GameChangeGold.gameid IN' => [2,3,5]
                ]
            ]);
            $phe_banca = $this->GameChangeGold->find('first', [
                'fields' => [
                    'SUM(GameChangeGold.phe) as total'
                ],
                'conditions' => [
                    'DATE(GameChangeGold.created) >=' => $start_date,
                    'DATE(GameChangeGold.created) <=' => $end_date,
                    'GameChangeGold.gameid IN' => [20]
                ]
            ]);
            $phe_bai = $this->GameChangeGold->find('first', [
                'fields' => [
                    'SUM(GameChangeGold.phe) as total'
                ],
                'conditions' => [
                    'DATE(GameChangeGold.created) >=' => $start_date,
                    'DATE(GameChangeGold.created) <=' => $end_date,
                    'GameChangeGold.gameid IN' => [23,25,26,27]
                ]
            ]);
            $this->set('phe', [
                'taixiu' => $phe_tx[0]['total'],
                'slot' => $phe_slot[0]['total'],
                'minislot' => $phe_minislot[0]['total'],
                'banca' => $phe_banca[0]['total'],
                'bai' => $phe_bai[0]['total']
            ]);
            
            //CCU By Game
            $this->loadModel('LogCcuByGame');
            $ccu = $this->LogCcuByGame->find('first', [
                'order' => 'id desc'
            ]);
            $ccu_game = json_decode( $ccu['LogCcuByGame']['ccu'], true );
            $ccu = [
                'taixiu' => 0,
                'slot' => 0,
                'banca' => 0,
                'minislot' => 0,
                'bai' => 0
            ];
            foreach($ccu_game as $k => $v) {
                if (in_array($k, [1])) {
                    $ccu['taixiu'] = $ccu['taixiu'] + $v;
                } else if (in_array($k, [6, 7, 9])) {
                    $ccu['slot'] = $ccu['slot'] + $v;
                } else if (in_array($k, [20])) {
                    $ccu['banca'] = $ccu['banca'] + $v;
                } else if (in_array($k, [2,3,5])) {
                    $ccu['minislot'] = $ccu['minislot'] + $v;
                } else if (in_array($k, [23,25,26,27])) {
                    $ccu['bai'] = $ccu['bai'] + $v;
                }
            }
            $this->set(compact('ccu'));

            //Tôngt tiền từ Giftcode
            $this->loadModel('GameChangeGold');
            $giftcode = $this->GameChangeGold->find('first', [
                'fields' => [
                    'SUM(GameChangeGold.gold_in) as total'
                ],
                'conditions' => [
                    'DATE(GameChangeGold.created) >=' => $start_date,
                    'DATE(GameChangeGold.created) <=' => $end_date,
                    'GameChangeGold.gameid IN' => [104]
                ]
            ]);
            $this->set('total_giftcode', isset($giftcode[0]) ? $giftcode[0]['total'] : 0);   
            $this->set('isSearch', true);
        } else {
            $this->set('isSearch', false);
        }
    }
}
