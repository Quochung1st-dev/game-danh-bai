<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */

App::uses('HttpSocket', 'Network/Http');

class QuanLyMemberController extends AppController
{
    public $components = array('Paginator');

    public $uses = [ 'AdmincpGroup', 'AdmincpMember', 'UserVerifiled' ,'Trade', 'ListCard', 'UserTransaction', 'User', 'GiftCode' , 'UserBlocks'];
    public function thong_tin_tai_khoan() {
        $this->set('title_for_layout', 'Thông tin tài khoản');
        $this->set('activeMenu', 'thong_tin_tai_khoan');

        $search = $this->request->query('keyword');
        $type = $this->request->query('type');
        $conditions = [];
        if (trim($search) != '') {
            if ($type == "displayname") {
                $conditions['User.displayname'] = $search;
            } else if ($type == "phone") {
                $conditions['User.phone'] = $search;
            } else if ($type == "ip") {
                $conditions['User.ipaddress'] = $search;
            } else {
                $conditions['User.id'] = $search;
            }
        }
        $this->paginate = [
            'conditions' => $conditions,
            'order' => 'User.id DESC'
        ];

        $this->set('userSearch', $this->Paginator->paginate('User'));

    }

    public function chi_tiet($id = null) {
        $user = $this->User->find('first', [
            'fields' => array('User.*', 'UserVerifiled.*'),
            'joins' => array(
                array(
                    'table' => 'user_vic_verifileds',
                    'alias' => 'UserVerifiled',
                    'type' => 'LEFT',
                    'conditions' => array(
                        'User.id = UserVerifiled.user_id'
                    )
                )
            ),
            'conditions' => [
                "User.id" => $id
            ],
        ]);
        if (!$user) {
            $this->Flash->error('Không tim thấy tài khoản !');
            return $this->redirect($this->referer());
        }

        $this->paginate = [
            "conditions" => [
                "GiftCode.id in (select user_codes.codeid from user_codes where userid = " . $user['User']['id'] . ")"
            ],
            "order" => 'GiftCode.id desc'
        ];

        $this->set("giftCodes",$this->paginate( "GiftCode" ));

        $this->set(compact('user'));
    }

    public function ban_member($id = null){
      $this->set( 'title_for_layout', 'Khóa tài khoản người dùng' );
      $this->set( 'activeMenu', 'ban_member' );

      $user = $this->User->find('first', [
          'conditions' => [
              "User.id" => $id
          ],
      ]);
      if (!$user) {
          $this->Flash->error('Không tim thấy tài khoản !');
          return $this->redirect($this->referer());
      }
      $loginuser = $this->Session->read( 'USER_LOGIN' );
      if($this->request->is('post')){
        $dataPost = $this->request->data;
        $user_id = $dataPost['ban_member']['userid'];
        $user_displayname = $dataPost['ban_member']['username'];
        $manager = $dataPost['ban_member']['manager'];
        $content = $dataPost['ban_member']['content'];

        $nam = $dataPost['ban_member']['nam'];
        $thang = $dataPost['ban_member']['thang'];
        $ngay = $dataPost['ban_member']['ngay'];
        $gio = $dataPost['ban_member']['gio'];
        $phut = $dataPost['ban_member']['phut'];
        $datenow = date("Y-m-d H:i:s");
        $addphut = date('Y-m-d H:i:s', strtotime('+'.$phut.' minutes', strtotime($datenow)));
        $addgio = date('Y-m-d H:i:s', strtotime('+'.$gio.' hours', strtotime($addphut)));
        $addngay = date('Y-m-d H:i:s', strtotime('+'.$ngay.' days', strtotime($addgio)));
        $addthang = date('Y-m-d H:i:s', strtotime('+'.$thang.' months', strtotime($addngay)));
        $addnam = date('Y-m-d H:i:s', strtotime('+'.$nam.' years', strtotime($addthang)));
        $this->Flash->success("Xử lý thành công.");
        $this->UserBlocks->save(array(
            'user_displayname' => $user_displayname,
            'user_id' => $user_id,
            'manager' => $manager,
            'content' => $content,
            'block_date' => $addnam
        ));
        $this->User->save(array(
        'id' => $user_id,
        'ban' => 1,
        ));
        $this->Flash->success("Xử lý thành công.");
        return $this->redirect(array('action' => 'khoa_member'));
      }else{

      }


      $this->set('user',$user);
      $this->set('loginuser',$loginuser);




    }

    public function unban_member($is = null){
      $this->set( 'title_for_layout', 'Mở khóa tài khoản người dùng' );
      $this->set( 'activeMenu', 'unban_member' );

    }

//     public function ban_unban($id = null) {
//         $user = $this->User->find('first', [
//             'conditions' => [
//                 "User.id" => $id
//             ],
//         ]);
//         if (!$user) {
//             $this->Flash->error('Không tim thấy tài khoản !');
//             return $this->redirect($this->referer());
//         }
//
//         if($user['User']['ban'] == 0) {
//             $d = Security::hash($user['User']['id'] . "+" . "Admin Kick User" . "+" . KEY_ENCODE, "sha256");
//  //           echo $d;
//             $secret = KEY_ENCODE;
//
//             $token = hash_hmac("sha256", $d, $secret); // create signature to check
//             $url = url_admin_kich . 'token=' . $token . "&content=" . "Admin Kick User" . '&userID=' . $user['User']['id'];
//   //              echo $url;
// //                die;
//             $httpSocket = new HttpSocket();
//             $response = $httpSocket->get($url);
//             if ($response == "thanh cong") {
//
//                 $d = Security::hash($user['User']['id'] . "+" . 100000000 . "+" . "Admin Kick Ban" . "+" . 1 . "+" . KEY_ENCODE, "sha256");
//                 $token = hash_hmac("sha256", $d, $secret); // create signature to check
//                 $url = url_admin_ban . 'token=' . $token . "&content=" . "Admin Kick Ban" . '&userid=' . $user['User']['username'] . '&type=' . 1 . '&time=' . 100000000;
// //                echo $url;
// //                die;
//                 $httpSocket = new HttpSocket();
//                 $response = $httpSocket->get($url);
//                 if ($response == "thanh cong") {
//                     $this->Flash->success("Xử lý thành công.");
//                     $this->User->save(array(
//                         'id' => $user['User']['id'],
//                         'ban' => 1,
//                     ));
//                 } else {
//                     $this->Flash->error("Ban User không thành công.");
//                 }
//
//             } else {
//                 $this->Flash->error("Kick không thành công.");
//             }
//         }else{
//             $secret = KEY_ENCODE;
//             $d = Security::hash($user['User']['id'] . "+" . 100000000 . "+" . "Admin Kick UnBan" . "+" . 3 . "+" . KEY_ENCODE, "sha256");
//             $token = hash_hmac("sha256", $d, $secret); // create signature to check
//
//             $url = url_admin_ban . 'token=' . $token . "&content=" . "Admin Kick Ban" . '&userid=' . $user['User']['username'] . '&type=' . 3 . '&time=' . 100000000;
//                 echo $url;
// //                die;
//             $httpSocket = new HttpSocket();
//             $response = $httpSocket->get($url);
//             if ($response == "thanh cong") {
//                 $this->Flash->success("Xử lý thành công.");
//                 $this->User->save(array(
//                     'id' => $user['User']['id'],
//                     'ban' => 0,
//                 ));
//             } else {
//                 $this->Flash->error("UnBan User không thành công.");
//             }
//         }
//         return $this->redirect(['action' => 'thong_tin_tai_khoan']);
//     }

    public function lich_su_nguoi_dung() {
        $this->set('title_for_layout', 'Lịch sử người dùng');
        $this->set('activeMenu', 'lich_su_nguoi_dung');

        $dataGet = $this->request->query;
        // if ( !isset( $dataGet["keyword"] )){
        //     $this->set("isData" , false);
        // }else {
            $this->set("isData" , true);
//        if ( isset( $dataGet["keyword"] ) && trim( $dataGet["keyword"] ) != "" ) {
//            $conditions["OR"] = [
//                "Trade.id"         => $dataGet["keyword"],
//                "User.displayname" => $dataGet["keyword"]
//            ];
//        }
//            pr($dataGet);
            if(isset($dataGet["keyword"]))
            $conditions = [
                'UserTransaction.userDisplayname' => $dataGet["keyword"]
            ];

            if (isset($dataGet["start_date"]) && $dataGet["start_date"]) {
                $conditions["DATE(UserTransaction.transDate) >="] = $dataGet["start_date"];
                $conditions["DATE(UserTransaction.transDate) <="] = $dataGet["end_date"];
            } else {
                $conditions["DATE(UserTransaction.transDate) >="] = date("Y-m-01");
                $conditions["DATE(UserTransaction.transDate) <="] = date("Y-m-d");
            }
            if (isset($dataGet["status"]) && $dataGet["status"][0] > 0 && is_array($dataGet["status"])) {
                $conditions["UserTransaction.gameID IN"] = $dataGet["status"];
            }

            $this->paginate = [
                'order' => 'UserTransaction.id DESC',
                'conditions' => $conditions
            ];
            $this->set('trans', $this->Paginator->paginate('UserTransaction'));

        // }

    }

    public function lich_su_chuyen_khoan() {
        $this->set( 'title_for_layout', 'Lịch sử chuyển khoản' );
        $this->set( 'activeMenu', 'lich_su_chuyen_khoan' );

        $dataGet = $this->request->query;

        if (isset($dataGet["type"]) && is_array($dataGet["type"])) {
            if (count($dataGet["type"]) == 1) {
                if ($dataGet["type"][0] == 1) {
                    $conditions = [
                        'Trade.user' => $dataGet["keyword"]
                    ];
                } else if ($dataGet["type"][0] == 2) {
                    $conditions = [
                        'Trade.user_target' => $dataGet["keyword"]
                    ];
                }
            }else{
                $conditions = [
                    'OR' => [
                        'Trade.user' => $dataGet["keyword"],
                        'Trade.user_target' => $dataGet["keyword"],
                    ]
                ];
            }
        }else if (isset($dataGet['keyword']) && trim($dataGet['keyword']) != '') {
            $conditions = [
                'OR' => [
                    'Trade.user' => $dataGet["keyword"],
                    'Trade.user_target' => $dataGet["keyword"],
                ]
            ];
        }

        if (isset($dataGet["start_date"]) && $dataGet["start_date"]) {
            $conditions["DATE(Trade.created) >="] = $dataGet["start_date"];
            $conditions["DATE(Trade.created) <="] = $dataGet["end_date"];
        } else {
            $conditions["DATE(Trade.created) >="] = date("Y-m-01");
            $conditions["DATE(Trade.created) <="] = date("Y-m-d");
        }
        if (isset($dataGet["status"]) && is_array($dataGet["status"])) {
            $conditions["Trade.status IN"] = $dataGet["status"];
        }

        $this->paginate = [
            'fields' => ['User.id', 'Trade.*'],
            'joins' => array(
                array(
                    'table' => 'user_vics',
                    'alias' => 'User',
                    'type' => 'INNER',
                    'conditions' => array(
                        'User.displayname = Trade.user',
                    )
                )
            ),
            'order' => 'Trade.id DESC',
            'conditions' => $conditions
        ];
        $this->set('trades', $this->Paginator->paginate('Trade'));

        $sum_gold = $this->Trade->find("first", [
            "recursive" => -1,
            "fields" => [
                "SUM(Trade.gold) as total_gold"
            ],
            'joins' => array(
                array(
                    'table' => 'user_vics',
                    'alias' => 'User',
                    'type' => 'INNER',
                    'conditions' => array(
                        'User.displayname = Trade.user',
                    )
                )
            ),
            "conditions" => $conditions
        ]);
        $this->set('sum_gold', isset($sum_gold[0]) ? intval($sum_gold[0]["total_gold"]) : 0);
    }

    public function an_giao_dich($id = null, $status = 0) {
        $trade = $this->Trade->findById($id);
        if (!$trade) {
            $this->Flash->error('Không tìm thấy giao dịch.');
        } else {
            $trade['Trade']['visible'] = $status ? 1 : 0;
            // pr($trade);die;
            if ($this->Trade->save($trade['Trade'])) {
                $this->Flash->success('Cập nhật giao dịch thành công.');
            } else {
                $this->Flash->error('Có lỗi xảy ra.');
            }
        }
        return $this->redirect($this->referer());
    }

    public function lich_su_nap_the() {
        $this->set( 'title_for_layout', 'Lịch sử nạp thẻ' );
        $this->set( 'activeMenu', 'lich_su_nap_the' );

        $dataGet = $this->request->query;
        if ( !isset( $dataGet["keyword"] )){
            $this->set("isData" , false);
            $this->paginate = [
                'fields' => array('ListCard.*'),
                'order' => 'id desc'
            ];
            $this->set('listCard', $this->Paginator->paginate('ListCard'));
        }else {
            $this->set("isData" , true);
//        if ( isset( $dataGet["keyword"] ) && trim( $dataGet["keyword"] ) != "" ) {
//            $conditions["OR"] = [
//                "Trade.id"         => $dataGet["keyword"],
//                "User.displayname" => $dataGet["keyword"]
//            ];
//        }
            $conditions = [
                'ListCard.displayname' => $dataGet["keyword"]
            ];

            if (isset($dataGet["start_date"]) && $dataGet["start_date"]) {
                $conditions["DATE(ListCard.created) >="] = $dataGet["start_date"];
                $conditions["DATE(ListCard.created) <="] = $dataGet["end_date"];
            } else {
                $conditions["DATE(ListCard.created) >="] = date("Y-m-01");
                $conditions["DATE(ListCard.created) <="] = date("Y-m-d");
            }
            if (isset($dataGet["status"]) && is_array($dataGet["status"])) {
                $conditions["ListCard.status IN"] = $dataGet["status"];
            }

            $this->paginate = [
                'order' => 'ListCard.id DESC',
                'conditions' => $conditions
            ];
            $this->set('listcards', $this->Paginator->paginate('ListCard'));

            $sum_gold = $this->ListCard->find("first", [
                "recursive" => -1,
                "fields" => [
                    "SUM(card_num) as total_gold"
                ],
                "conditions" => $conditions
            ]);
            $this->set('sum_gold', isset($sum_gold[0]) ? intval($sum_gold[0]["total_gold"]) : 0);
        }
    }

    public function khoa_member(){
        $this->set( 'title_for_layout', 'Khóa menber' );
        $this->set( 'activeMenu', 'khoa_member' );

        $search = $this->request->query('keyword');
        $type = $this->request->query('type');
        $conditions = [];
        if (trim($search) != '') {
            if ($type == "user_displayname") {
                $conditions['UserBlocks.user_displayname'] = $search;
            } else if ($type == "user_id") {
                $conditions['UserBlocks.user_id'] = $search;
            }else {
                $conditions['UserBlocks.id'] = $search;
            }
        }
        $this->paginate = [
            'conditions' => $conditions,
            'order' => 'UserBlocks.id DESC'
        ];

        $this->set('userBlocksSearch', $this->Paginator->paginate('UserBlocks'));
    }

    public function sua_khoa_member(){
      $this->set( 'title_for_layout', 'Sửa khóa tài khoản người dùng' );
      $this->set( 'activeMenu', 'sua_khoa_member' );

      $id = $this->request->query('id');
      if (!$this->UserBlocks->exists($id)) {
          throw new NotFoundException(__('Không tồn tại'));
      }
      $userblocks = $this->UserBlocks->find("first",[
          'conditions' => [
              'UserBlocks.id' => $id,
          ]
      ]);
      $user = $this->Session->read( 'USER_LOGIN' );
      $manager = $user['AdmincpMember']['username'];
      if($this->request->is('post')){
        $dataPost = $this->request->data;
        $idbanned = $userblocks['UserBlocks']['id'];
        $user_displayname = $userblocks['UserBlocks']['user_displayname'];
        $user_id = $userblocks['UserBlocks']['user_id'];
        $content = $dataPost['khoa_member']['content'];
        $nam = $dataPost['khoa_member']['nam'];
        $thang = $dataPost['khoa_member']['thang'];
        $ngay = $dataPost['khoa_member']['ngay'];
        $gio = $dataPost['khoa_member']['gio'];
        $phut = $dataPost['khoa_member']['phut'];
        $datenow = date("Y-m-d H:i:s");
        $addphut = date('Y-m-d H:i:s', strtotime('+'.$phut.' minutes', strtotime($datenow)));
        $addgio = date('Y-m-d H:i:s', strtotime('+'.$gio.' hours', strtotime($addphut)));
        $addngay = date('Y-m-d H:i:s', strtotime('+'.$ngay.' days', strtotime($addgio)));
        $addthang = date('Y-m-d H:i:s', strtotime('+'.$thang.' months', strtotime($addngay)));
        $addnam = date('Y-m-d H:i:s', strtotime('+'.$nam.' years', strtotime($addthang)));
        $this->Flash->success("Xử lý thành công.");
        $this->UserBlocks->save(array(
            'id' => $idbanned,
            'user_displayname' => $user_displayname,
            'user_id' => $user_id,
            'manager' => $manager,
            'content' => $content,
            'block_date' => $addnam
        ));
        return $this->redirect(['action' => 'khoa_member']);
      }
      $this->set('userblocks',$userblocks);
    }

    public function un_banned($id = null){
      $this->set( 'title_for_layout', 'Xóa khóa tài khoản cho người dùng' );
      $this->set( 'activeMenu', 'un_banned' );

      $userblocks = $this->UserBlocks->find('first', [
          'conditions' => [
              "UserBlocks.user_id" => $id
          ],
      ]);
      $id_block = $userblocks['UserBlocks']['id'];
      if (!$userblocks) {
          $this->Flash->error('Không tim thấy tài khoản !');
          return $this->redirect($this->referer());
      }
      $id_user = $userblocks['UserBlocks']['user_id'];
      $user = $this->User->find('first',[
          'conditions' => [
              "User.id" => $id_user
          ],
      ]);
      $ban = $user['User']['ban'];
      if($user['User']['ban'] == 1) {
        $this->Flash->success("Thành công");
        $this->User->save(array(
            'id' => $user['User']['id'],
            'ban' => 0,
        ));
        $this->UserBlocks->id = $id_block;
        $this->UserBlocks->delete();
      }else{
        $this->Flash->error("Xóa khóa không thành công.");
      }
      return $this->redirect($this->referer());
    }
}
