<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Controller', 'Controller');

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {
	public $components = array('DebugKit.Toolbar', 'Session', 'Flash', 'Paginator');


	protected $authUser;
    public function beforeFilter()
    {
        parent::beforeFilter();

        if (!in_array($this->request->params['action'], ['login'])){
            $this->loadModel('AdmincpMember');
            $admin = $this->Session->read('USER_LOGIN');

            if (!$admin){
				$this->redirect('/dangnhap');
                //$this->layout = "error";
//                return $this->redirect(['controller' => 'Admins', 'action' => 'unauthorized_exception']);
                throw new UnauthorizedException();
            }
            $member = $this->AdmincpMember->find( "first", [
                'fields' => array('AdmincpMember.*', 'AdmincpGroup.*'),
                'joins' => array(
                    array(
                        'table' => 'admincp_group',
                        'alias' => 'AdmincpGroup',
                        'type' => 'INNER',
                        'conditions' => array(
                            'AdmincpMember.groupid = AdmincpGroup.id'
                        )
                    )
                ),
                'conditions' => [
                    'AdmincpMember.id' => $admin['AdmincpMember']['id']
                ]

            ]);
//            pr($member);
            if($admin['AdmincpMember']['groupid'] == 0){
                $member['AdmincpGroup']['acl'] = "QuanLyMember,QuanLyGame,QuanLyGameBai,ThongKe,QuanLyDaiLy,Setting,LichSu,QuanTriVien,ToolVanHanh,Home";
                $check = true;
            }else {
                $tmp = strpos($member['AdmincpGroup']['acl'], $this->request->params['controller']);
                if($tmp === false) {
                    $check = false;
//                    echo '111';
                }
                else {
                    $check = true;
//                    echo '222';
                }
            }
            if(in_array($this->request->params['controller'], ['Home'])){
                $check = true;
            }

            if (!$check){
				$this->redirect('/dangnhap');
                //$this->layout = "error";
//                return $this->redirect(['controller' => 'Admins', 'action' => 'unauthorized_exception']);
                throw new UnauthorizedException();
            }

	        $this->authUser =$member;
	        $this->set( 'APP_AGENCY', $this->authUser );

        }
    }
}
