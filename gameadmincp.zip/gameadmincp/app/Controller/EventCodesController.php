<?php
App::uses('AppController', 'Controller');
App::uses('HttpSocket', 'Network/Http');
App::uses('GGAuth', 'Lib');
/**
 * EventCodes Controller
 *
 * @property EventCode $EventCode
 * @property PaginatorComponent $Paginator
 */
class EventCodesController extends AppController {
    public $uses = ['EventCode', 'GiftCode', 'Agency', 'UserVerifiled'];
/**
 * Components
 *
 * @var array
 */
    private $GIFT_CODE_SECRET_KEY = "1bCFH3f5z9qlBHj1LPKx";
	public $components = array('Paginator');
/**
 * index method
 *
 * @return void
 */
	public function index() {
        $this->set('title_for_layout', 'Quản lý Event');
		$this->set('activeMenu', 'EventCodes');
		$this->EventCode->recursive = 0;

        $admin = $this->Session->read('USER_LOGIN');
        if(!isset($admin)){
            $this->Session->destroy();
            return $this->redirect(['action' => 'login']);
        }
        $this->paginate = [
            'order' => 'id DESC',
            'conditions' => 'agencyId = '. $admin['Agency']['userid']
        ];


        $this->set('eventCodes', $this->Paginator->paginate());
	}

/**
 * view method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function view($id = null) {
		if (!$this->EventCode->exists($id)) {
			throw new NotFoundException(__('Invalid event code'));
		}
        $admin = $this->Session->read('USER_LOGIN');
        if(!isset($admin)){
            $this->Session->destroy();
            return $this->redirect(['action' => 'login']);
        }
		$options = array('conditions' => array('EventCode.' . $this->EventCode->primaryKey => $id, 'EventCode.agencyId' => $admin['Agency']['userid']));

		$this->set('eventCode', $this->EventCode->find('first', $options));
	}

/**
 * add method
 *
 * @return void
 */
    public function random_string($length, $upCase = false) {
        $key = '';
        $keys = array_merge(range(0, 9), range('a', 'z'));
        if($upCase == true){
            $keys = array_merge(range(0, 9), range('a', 'z'),range('A', 'Z') );
        }
        for ($i = 0; $i < $length; $i++) {
            $key .= $keys[array_rand($keys)];
        }

        return $key;
    }

	public function add() {
        $this->set('title_for_layout', 'Thêm mới Event');
		$this->set('activeMenu', 'EventCodes');

		if ($this->request->is('post')) {

		    //pr($this->request->data);
            $rs1 = $this->UserVerifiled->find( "first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $this->authUser['Agency']['userid'],
                    'UserVerifiled.status'  => 1,
                ]
            ] );

            if ( count( $rs1 ) == 0 ) {
                $this->Flash->error( "Chưa xác thực tài khoản" );
                return;
            }

            if ($this->request->data['start_date'] >= $this->request->data['expired_date']) {
	            $this->Flash->error( "Ngày hết hạn phải lớn hơn ngày bắt đầu" );
	         return;
            }

            $this->request->data['EventCode']['agencyId'] = $this->authUser['Agency']['userid'];
			$this->request->data['EventCode']['number_code'] = intval(str_replace( ',', '', $this->request->data['EventCode']['number_code'] ));
			$this->request->data['EventCode']['gold'] = intval(str_replace( ',', '', $this->request->data['EventCode']['gold'] ));
			$this->request->data['EventCode']['start_date'] = $this->request->data['start_date'];
			$this->request->data['EventCode']['expired_date'] = $this->request->data['expired_date'];
			$this->request->data['EventCode']['description'] = '';
			$this->request->data['EventCode']['create_date'] = date("Y-m-d H:i:s");
			$this->request->data['EventCode']['type_code'] = $this->request->data['EventCode']['type_code'][0];
			$this->request->data['EventCode']['vpoint'] = 0;
			$this->request->data['EventCode']['gameid'] = "1";
			$code = $this->request->data['otpcode'];
			$gg_code = $this->request->data['gg_code'];
			$event['EventCode'] = $this->request->data['EventCode'];
            $verify_code = false;
            if ( $rs1['UserVerifiled']['code'] == $code && !empty($code)) {
                $verify_code = true;
            }
            $tmp_user = $this->Session->read("USER_LOGIN");
            $ga = new GGAuth();
            if ($ga->verifyCode($tmp_user['Agency']['ga_code'], $gg_code)) {
                $verify_code = true;
            }

            if($verify_code == true) {
                $this->EventCode->create();
                $rs = $this->EventCode->save($event);
                $g = $this->request->data['EventCode']['number_code'] * $this->request->data['EventCode']['gold'];
                $ok = false;
                if ($g > 0 && $g <= $this->authUser['Agency']['subgold'])
                    $ok = true;
                if (!$ok) {
                    $this->Flash->error(__('Bạn không đủ tiền phụ để tạo code'));
                } else if ($rs) {
                    for ($i = 0; $i < $this->request->data['EventCode']['number_code']; $i++) {
                        $rdString = $this->random_string(10);
                        $rdMD5 = substr(md5($rdString), 0, 6);
                        $rdKey = md5($rdMD5 . '' . $this->GIFT_CODE_SECRET_KEY);
                        $code = substr($rdKey, 0, 4) . '' . $rdMD5;

                        $this->GiftCode->create();
                        $this->GiftCode->save(array('secure_code' => '123456', 'code' => $code, 'eventid' => $rs['EventCode']['id'], 'agencyId' => $this->request->data['EventCode']['agencyId']));

                    }
                    $g2 = $this->authUser['Agency']['subgold'] - $g;
                    $this->Agency->save(array('id' => $this->authUser['Agency']['id'], 'subgold' => $g2));

                    $this->Flash->success(__('Thêm mới EVENT thành công.'));
                    return $this->redirect(array('action' => 'index'));
                } else {
//                	pr($rs);
                    $this->Flash->error(__('The event code could not be saved. Please, try again.'));
                }
            }else{
                $this->Flash->error(__('Mã otp code không đúng'));
            }
			$this->request->data['EventCode']['number_code'] = number_format($this->request->data['EventCode']['number_code']);
			$this->request->data['EventCode']['gold'] = number_format($this->request->data['EventCode']['gold']);
		}
	}

    public function getOTPCode() {
        $admin = $this->Session->read( 'USER_LOGIN' );
        $dataReturn = [
            "status" => false,
            "data" => null
        ];
        if (isset( $admin ) && $admin ) {
            $httpSocket = new HttpSocket();
            $url = url_user_getDLotp . 'id=' . $admin['Agency']['id'];
            $response = $httpSocket->get( $url );
            $dataReturn = [
                "status" => true,
                "data" => $response
            ];
        }
        header("Content-type: application/json");
        echo json_encode($dataReturn);die;
    }

/**
 * edit method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function edit($id = null) {
//		if (!$this->EventCode->exists($id)) {
//			throw new NotFoundException(__('Invalid event code'));
//		}
//
//        $admin = $this->Session->read('USER_LOGIN');
//        if(!isset($admin)){
//            $this->Session->destroy();
//            return $this->redirect(['action' => 'login']);
//        }
//
//		if ($this->request->is(array('post', 'put'))) {
//            pr($this->request->data);
//			if ($this->EventCode->save($this->request->data) ) {
//                $this->Flash->success(__('The event code has been saved.'));
//                return $this->redirect(array('action' => 'index'));
//			} else {
//				$this->Flash->error(__('The event code could not be saved. Please, try again.'));
//			}
//		} else {
//			$options = array('conditions' => array('EventCode.' . $this->EventCode->primaryKey => $id, 'EventCode.agencyId' => $admin['Agency']['userid']));
//			$this->request->data = $this->EventCode->find('first', $options);
//		}
	}

/**
 * delete method
 *
 * @throws NotFoundException
 * @param string $id
 * @return void
 */
	public function delete($id = null) {
//		$this->EventCode->id = $id;
//		if (!$this->EventCode->exists()) {
//			throw new NotFoundException(__('Invalid event code'));
//		}
//		$this->request->allowMethod('post', 'delete');
//		if ($this->EventCode->delete()) {
//			$this->Flash->success(__('The event code has been deleted.'));
//		} else {
//			$this->Flash->error(__('The event code could not be deleted. Please, try again.'));
//		}
//		return $this->redirect(array('action' => 'index'));
	}
}
