<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */


class QuanLyGameBaiController extends AppController
{

    public $uses = [ 'GameCardInfo', 'GameCardUserInfo'];
    public function tim_kiem_van_choi() {
        $this->set('title_for_layout', 'Tìm kiếm ván chơi');
        $this->set('activeMenu', 'tim_kiem_van_choi');

        $dataGet = $this->request->query;
        if ( !isset( $dataGet["keyword"] )){
            $this->set("isData" , false);
        }else {
            $this->set("isData" , true);

            $conditions = [
                'GameCardInfo.gameSessionID' => $dataGet["keyword"]
            ];

            $data = $this->GameCardInfo->find("first",[
                'conditions' => $conditions
            ]);
            $this->set('data', $data);

        }
    }

    public function tim_kiem_ban_ca() {
        $this->set('title_for_layout', 'Tìm kiếm ván chơi');
        $this->set('activeMenu', 'tim_kiem_van_choi');

        $dataGet = $this->request->query;
        if ( !isset( $dataGet["keyword"] )){
            $this->set("isData" , false);
        }else {
            $this->set("isData" , true);

            $conditions = [
                'GameCardInfo.gameSessionID' => $dataGet["keyword"],
                'GameCardInfo.gameID' => 20,
            ];

            $data = $this->GameCardInfo->find("first",[
                'conditions' => $conditions
            ]);
            $this->set('data', $data);

            $conditions = [
                'GameCardUserInfo.gameSessionID' => $dataGet["keyword"],
                'GameCardInfo.gameID' => 20,
            ];

            $data1 = $this->GameCardUserInfo->find("first",[
                'conditions' => $conditions
            ]);
            $this->set('data1', $data1);

        }
    }

    public function thong_tin_ban_choi() {
        $this->set('title_for_layout', 'Thông tin bàn chơi');
        $this->set('activeMenu', 'thong_tin_ban_choi');

        $dataGet = $this->request->query;
        if ( !isset( $dataGet["keyword"] )){
            $this->set("isData" , false);
        }else {
            $this->set("isData" , true);

            $conditions = [
                'GameCardUserInfo.gameSessionID' => $dataGet["keyword"]
            ];

            $data = $this->GameCardUserInfo->find("first",[
                'conditions' => $conditions
            ]);
            $this->set('data', $data);

        }

    }

    public function thong_tin_ccu() {
        $this->set('title_for_layout', 'Thông tin CCU');
        $this->set('activeMenu', 'thong_tin_ccu');
    }

}
