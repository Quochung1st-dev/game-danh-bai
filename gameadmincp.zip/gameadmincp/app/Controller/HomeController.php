<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */


class HomeController extends AppController
{
    public $uses = ['Trade','Agency','ListCard','UserLogin','ZpMoneyWaste', 'GameChangeGold', 'ZpGiftCode', 'KpiSystemLog', 'User', 'UserTransaction','LogCcuByGame'];

    private $GAME_ID_MINI_POKER = 5;
    private $GAME_ID_MINI_SLOT_2 = 3;
    private $GAME_ID_MINI_SLOT_1 = 2;
    private $GAME_ID_SLOT_25 = 6;
    private $GAME_ID_SLOT_20 = 7;
    private $GAME_ID_SLOT_20_1 = 8;
    private $GAME_ID_SLOT_20_2 = 9;

//    public function index() {
//        return $this->redirect(['controller' => 'Admins/login_ss']);
//    }

    private function a3UserLogin($startDate, $endDate){
        $qr = "select userID, Date(createdDate) as datelogin ,
    COUNT(DISTINCT DAY(createdDate)) AS DaysInMonth  from `user_registers` where  Date(createdDate) > '".$startDate."' and Date(createdDate) <= '".$endDate."' group by userID";

//        echo $qr.'<br/>';
        $rs = $this->UserTransaction->query($qr);
        $d = 0;
        if($rs){
            for ($i = 0; $i < count($rs); $i++){
                if($rs[$i][0]['DaysInMonth'] == 3)
                    $d = $d + 1;
            }
            return $d;
        }else{
            return 0;
        }

    }

    public function getcculog()
    {
        $this->layout = 'ajax';
        $last_ccu = $this->UserTransaction->query("SELECT * FROM `casino_log`.`kpi_system_metrics` AS `KpiSystemLog` ORDER BY `created` DESC LIMIT 1");
        $this->set(compact('last_ccu'));
        return $this->render();
    }

    public function index() {
        $this->set('activeMenu', 'tong_quan');
        $this->set('title_for_layout', 'Tổng quan');
        $check_permission = strpos($this->authUser['AdmincpGroup']['acl'], 'ThongKe');
        $this->set('check_permission', $check_permission);
        //User đăng ký trong ngày
        $nru_ios = $this->User->find('count', [
            'recursive' => -1,
            'conditions' => [
                'DATE(User.created)' => date('Y-m-d'),
                'User.typeOS' => 1
            ]
        ]);
        $nru_android = $this->User->find('count', [
            'recursive' => -1,
            'conditions' => [
                'DATE(User.created)' => date('Y-m-d'),
                'User.typeOS' => 2
            ]
        ]);
        $nru_web = $this->User->find('count', [
            'recursive' => -1,
            'conditions' => [
                'DATE(User.created)' => date('Y-m-d'),
                'User.typeOS' => 0
            ]
        ]);
        $this->set('nru', [
            'ios' => $nru_ios,
            'android' => $nru_android,
            'web' => $nru_web
        ]);

        //User đăng nhập trong ngày.
        $this->loadModel('LogUserLogin');
        $lu_ios = $this->LogUserLogin->find('first', [
            'fields' => [
                'COUNT(DISTINCT(`LogUserLogin`.`userID`)) as total'
            ],
            'recursive' => -1,
            'conditions' => [
                'DATE(LogUserLogin.createdDate)' => date('Y-m-d'),
                'LogUserLogin.os_flatform' => 'ios'
            ]
        ]);
        $lu_android = $this->LogUserLogin->find('first', [
            'fields' => [
                'COUNT(DISTINCT(`LogUserLogin`.`userID`)) as total'
            ],
            'recursive' => -1,
            'conditions' => [
                'DATE(LogUserLogin.createdDate)' => date('Y-m-d'),
                'LogUserLogin.os_flatform' => 'android'
            ]
        ]);
        $lu_web = $this->LogUserLogin->find('first', [
            'fields' => [
                'COUNT(DISTINCT(`LogUserLogin`.`userID`)) as total'
            ],
            'recursive' => -1,
            'conditions' => [
                'DATE(LogUserLogin.createdDate)' => date('Y-m-d'),
                'LogUserLogin.os_flatform' => 'web'
            ]
        ]);
        $this->set('lu', [
            'ios' => $lu_ios[0]['total'],
            'android' => $lu_android[0]['total'],
            'web' => $lu_web[0]['total']
        ]);

        //Tổng số thành viên
        $total_member = $this->User->find('count');
        $this->set(compact('total_member'));

        //Tiền nạp trong ngày
        $total_charge_1 = $this->ListCard->find('first', [
            'fields' => [
                'SUM(ListCard.card_num) as total'
            ],
            'conditions' => [
                'DATE(ListCard.created)' => date("Y-m-d"),
                'ListCard.status' => 1,
                'ListCard.khid' => 1
            ],
            'group' => 'ListCard.khid'
        ]);
        $total_charge_2 = $this->ListCard->find('first', [
            'fields' => [
                'SUM(ListCard.card_num) as total'
            ],
            'conditions' => [
                'DATE(ListCard.created)' => date("Y-m-d"),
                'ListCard.status' => 1,
                'ListCard.khid' => 2
            ],
            'group' => 'ListCard.khid'
        ]);
        $total_charge_3 = $this->ListCard->find('first', [
            'fields' => [
                'SUM(ListCard.card_num) as total'
            ],
            'conditions' => [
                'DATE(ListCard.created)' => date("Y-m-d"),
                'ListCard.status' => 1,
                'ListCard.khid' => 3
            ],
            'group' => 'ListCard.khid'
        ]);
        $this->set('total_charge', [
            'paygate_1' => isset($total_charge_1[0]) ? $total_charge_1[0]['total'] : 0,
            'paygate_2' => isset($total_charge_2[0]) ? $total_charge_2[0]['total'] : 0,
            'paygate_3' => isset($total_charge_3[0]) ? $total_charge_3[0]['total'] : 0
        ]);
        //Tong so phe
        $phe_tx = $this->GameChangeGold->find('first', [
            'fields' => [
                'SUM(GameChangeGold.phe) as total'
            ],
            'conditions' => [
                'DATE(GameChangeGold.created)' => date("Y-m-d"),
                'GameChangeGold.gameid IN' => [1]
            ]
        ]);
        $phe_slot = $this->GameChangeGold->find('first', [
            'fields' => [
                'SUM(GameChangeGold.phe) as total'
            ],
            'conditions' => [
                'DATE(GameChangeGold.created)' => date("Y-m-d"),
                'GameChangeGold.gameid IN' => [6,7,9]
            ]
        ]);
        $phe_minislot = $this->GameChangeGold->find('first', [
            'fields' => [
                'SUM(GameChangeGold.phe) as total'
            ],
            'conditions' => [
                'DATE(GameChangeGold.created)' => date("Y-m-d"),
                'GameChangeGold.gameid IN' => [2,3,5]
            ]
        ]);
        $phe_banca = $this->GameChangeGold->find('first', [
            'fields' => [
                'SUM(GameChangeGold.phe) as total'
            ],
            'conditions' => [
                'DATE(GameChangeGold.created)' => date("Y-m-d"),
                'GameChangeGold.gameid IN' => [20]
            ]
        ]);
        $phe_bai = $this->GameChangeGold->find('first', [
            'fields' => [
                'SUM(GameChangeGold.phe) as total'
            ],
            'conditions' => [
                'DATE(GameChangeGold.created)' => date("Y-m-d"),
                'GameChangeGold.gameid IN' => [23,25,26,27]
            ]
        ]);
        $this->set('phe', [
            'taixiu' => $phe_tx[0]['total'],
            'slot' => $phe_slot[0]['total'],
            'minislot' => $phe_minislot[0]['total'],
            'banca' => $phe_banca[0]['total'],
            'bai' => $phe_bai[0]['total']
        ]);

        //CCU By Game
        $this->loadModel('LogCcuByGame');
        $ccu = $this->LogCcuByGame->find('first', [
            'order' => 'id desc'
        ]);
        $ccu_game = json_decode( $ccu['LogCcuByGame']['ccu'], true );
        $ccu = [
            'taixiu' => 0,
            'slot' => 0,
            'banca' => 0,
            'minislot' => 0,
            'bai' => 0
        ];
        foreach($ccu_game as $k => $v) {
            if (in_array($k, [1])) {
                $ccu['taixiu'] = $ccu['taixiu'] + $v;
            } else if (in_array($k, [6, 7, 9])) {
                $ccu['slot'] = $ccu['slot'] + $v;
            } else if (in_array($k, [20])) {
                $ccu['banca'] = $ccu['banca'] + $v;
            } else if (in_array($k, [2,3,5])) {
                $ccu['minislot'] = $ccu['minislot'] + $v;
            } else if (in_array($k, [23,25,26,27])) {
                $ccu['bai'] = $ccu['bai'] + $v;
            }
        }
        $this->set(compact('ccu'));

        //Tôngt tiền từ Giftcode
        $this->loadModel('GameChangeGold');
        $giftcode = $this->GameChangeGold->find('first', [
            'fields' => [
                'SUM(GameChangeGold.gold_in) as total'
            ],
            'conditions' => [
                'DATE(GameChangeGold.created)' => date("Y-m-d"),
                'GameChangeGold.gameid IN' => [104]
            ]
        ]);
        $this->set('total_giftcode', isset($giftcode[0]) ? $giftcode[0]['total'] : 0);
    }

    public function thongke() {
        $cur_day = date('d');
        $cur_month = date('m');
        if ($this->request->is('get')) {
            $param = $this->request->query;
            if (!empty($param['months'])) {
                $cur_month = $param['months'];
            }
        }
        $cur_year = date('Y');
        $day_in_month = $number = cal_days_in_month(CAL_GREGORIAN, $cur_month, $cur_year);

        $a3User = [];

        for($i = 1; $i<= $day_in_month; $i++){
            $day = $i;
            if($i < 10)
                $day = "0".$i;
            $end =  date("Y-".$cur_month."-".$day);
            $start =  date('Y-m-d', strtotime('-3 day', strtotime($end)));
            $a3User[] = $this->a3UserLogin($start, $end);
//            die;
        }
//        pr($a3User);
//        die;

        //ccu

        $currDate = date('Y-m-d');
        $qr = "select ROUND(AVG(ccu)) as ccu, EXTRACT(HOUR from created)  as h from `kpi_system_metrics` where Date(created) = '".$currDate."' GROUP BY h";
        $rsCcu = $this->UserTransaction->query($qr);

        $ccu = [];
        $labelCCU = [];
        for($i = 0; $i< 24; $i++){
            $labelCCU[] = $i. ' Giờ';
            if($i < count($rsCcu))
                $ccu[] = $rsCcu[$i][0]['ccu'];
            else
                $ccu[] = 0;
        }
//        pr($ccu);
//        die;
        //
        $cash_in_card = $this->ListCard->find('all', array(
                'fields' => [
                    'SUM(card_num) as card_num',
                    'DAY(created) as day'
                ],
                'conditions' => array(
                    'MONTH(created)'=>$cur_month,
                    'YEAR(created)' =>$cur_year,
                    'status' => 1,
                ),
                'group'=>[
                    'DAY(created)'
                ]
            )
        );

        $cash_in = $this->Trade->find('all', array(
                'fields' => [
                    'SUM(gold) as gold',
                    'DAY(created) as day'
                ],
                'conditions' => array(
                    'MONTH(created)'=>$cur_month,
                    'YEAR(created)' =>$cur_year,
                    'status' => 1,
                    'user in (select agencies.name from agencies)',
                    'user_target not in (select agencies.name from agencies)',
                ),
                'group'=>[
                    'DAY(created)'
                ]
            )
        );
//        pr($cash_in);
//        die;
        $cash_out = $this->Trade->find('all', array(
                'fields' => [
                    'SUM(gold) as gold',
                    'DAY(created) as day'
                ],
                'conditions' => array(
                    'MONTH(created)'=>$cur_month,
                    'YEAR(created)' =>$cur_year,
                    'status' => 4,
                    'user not in (select agencies.name from agencies)',
                    'user_target in (select agencies.name from agencies)',
                ),

                'group'=>[
                    'DAY(created)'
                ]
            )
        );
//        pr($cash_out);
//        die;
//        $outs = [];
//        foreach ($cash_out as $cash){
//            @$outs[$cash[0]['day']] += $cash[0]['cash_out'];
//        }
        // login / register

        $login = $this->UserLogin->find('all',[
            'fields' => [
                'COUNT(id) as login',
                'DAY(createdDate) as day'
            ],
            'conditions' => array(
                'MONTH(createdDate)'=>$cur_month,
                'YEAR(createdDate)' =>$cur_year,
            ),
            'group'=>[
                'DAY(createdDate)'
            ]
        ]);
//        pr($login);
//        die;
        $register0 = $this->User->find('all',[
            'fields' => [
                'COUNT(typeOS) as register',
                'DAY(created) as day'
            ],
            'conditions' => array(
                'MONTH(created)'=>$cur_month,
                'YEAR(created)' =>$cur_year,
            ),
            'group'=>[
                'DAY(created)'
            ]
        ]);

        $register = $this->User->find('all',[
            'fields' => [
                'COUNT(typeOS) as register',
                'DAY(created) as day'
            ],
            'conditions' => array(
                'MONTH(created)'=>$cur_month,
                'YEAR(created)' =>$cur_year,
                'typeOS'=> 1,
            ),
            'group'=>[
                'DAY(created)'
            ]
        ]);
        $register1 = $this->User->find('all',[
            'fields' => [
                'COUNT(typeOS) as register',
                'DAY(created) as day'
            ],
            'conditions' => array(
                'MONTH(created)'=>$cur_month,
                'YEAR(created)' =>$cur_year,
                'typeOS'=> 2,
            ),
            'group'=>[
                'DAY(created)'
            ]
        ]);
        $register2 = $this->User->find('all',[
            'fields' => [
                'COUNT(typeOS) as register',
                'DAY(created) as day'
            ],
            'conditions' => array(
                'MONTH(created)'=>$cur_month,
                'YEAR(created)' =>$cur_year,
                'typeOS'=> 0,
            ),
            'group'=>[
                'DAY(created)'
            ]
        ]);
        $register3 = $this->User->find('all',[
            'fields' => [
                'COUNT(typeOS) as register',
                'DAY(created) as day'
            ],
            'conditions' => array(
                'MONTH(created)'=>$cur_month,
                'YEAR(created)' =>$cur_year,
                'typeOS'=> 6,
            ),
            'group'=>[
                'DAY(created)'
            ]
        ]);
        $register4 = $this->User->find('all',[
            'fields' => [
                'COUNT(typeOS) as register',
                'DAY(created) as day'
            ],
            'conditions' => array(
                'MONTH(created)'=>$cur_month,
                'YEAR(created)' =>$cur_year,
                'typeOS'=> 10,
            ),
            'group'=>[
                'DAY(created)'
            ]
        ]);
        $taixiu = $this->GameChangeGold->find('all',[
            'fields' => [
                'SUM(gold_out) as sum_gold',
                'DAY(created) as day'
            ],
            'conditions' => array(
                'MONTH(created)'=>$cur_month,
                'YEAR(created)' =>$cur_year,
                'gameid' => 1,
            ),
            'group'=>[
                'DAY(created)'
            ]
        ]);

//        pr($taixiu);
//        die;

        $slot = $this->GameChangeGold->find('all',[
            'fields' => [
                'SUM(gold_out) as sum_waste_money',
                'DAY(created) as day'
            ],
            'conditions' => array(
                'MONTH(created)'=>$cur_month,
                'YEAR(created)' =>$cur_year,
                'gameid' => $this->GAME_ID_SLOT_25
            ),
            'group'=>[
                'DAY(created)'
            ]
        ]);
        $slotNC = $this->GameChangeGold->find('all',[
            'fields' => [
                'SUM(gold_out) as sum_waste_money',
                'DAY(created) as day'
            ],
            'conditions' => array(
                'MONTH(created)'=>$cur_month,
                'YEAR(created)' =>$cur_year,
                'gameid' => $this->GAME_ID_SLOT_20
            ),
            'group'=>[
                'DAY(created)'
            ]
        ]);
        $slotLS = $this->GameChangeGold->find('all',[
            'fields' => [
                'SUM(gold_out) as sum_waste_money',
                'DAY(created) as day'
            ],
            'conditions' => array(
                'MONTH(created)'=>$cur_month,
                'YEAR(created)' =>$cur_year,
                'gameid' => $this->GAME_ID_SLOT_20_1
            ),
            'group'=>[
                'DAY(created)'
            ]
        ]);

        $slotTH = $this->GameChangeGold->find('all',[
            'fields' => [
                'SUM(gold_out) as sum_waste_money',
                'DAY(created) as day'
            ],
            'conditions' => array(
                'MONTH(created)'=>$cur_month,
                'YEAR(created)' =>$cur_year,
                'gameid' => $this->GAME_ID_MINI_SLOT_2
            ),
            'group'=>[
                'DAY(created)'
            ]
        ]);
        $slotPoker = $this->GameChangeGold->find('all',[
            'fields' => [
                'SUM(gold_out) as sum_waste_money',
                'DAY(created) as day'
            ],
            'conditions' => array(
                'MONTH(created)'=>$cur_month,
                'YEAR(created)' =>$cur_year,
                'gameid' => $this->GAME_ID_MINI_POKER
            ),
            'group'=>[
                'DAY(created)'
            ]
        ]);
        $slotKC = $this->GameChangeGold->find('all',[
            'fields' => [
                'SUM(gold_out) as sum_waste_money',
                'DAY(created) as day'
            ],
            'conditions' => array(
                'MONTH(created)'=>$cur_month,
                'YEAR(created)' =>$cur_year,
                'gameid' => $this->GAME_ID_MINI_SLOT_1
            ),
            'group'=>[
                'DAY(created)'
            ]
        ]);

        $giftCode = $this->GameChangeGold->find('all',[
            'fields' => [
                'SUM(gold_out) as gold',
                'DAY(created) as day'
            ],
            'conditions' => array(
                'MONTH(created)'=>$cur_month,
                'YEAR(created)' =>$cur_year,
                'gameid' => -1
            ),
            'group'=>[
                'DAY(created)'
            ]
        ]);


//        $money_waste = $this->ZpMoneyWaste->find('all',[
//            'fields' => [
//                'SUM(waste_money) as sum_waste_money',
//                'DAY(create_date) as day'
//            ],
//            'conditions' => array(
//                'MONTH(create_date)'=>$cur_month,
//                'YEAR(create_date)' =>$cur_year,
//            ),
//            'group'=>[
//                'DAY(create_date)'
//            ]
//        ]);
        //
        $data_in =[];
        $data_in_card =[];
        $data_login =[];
        $data_register0 =[];
        $data_register =[];
        $data_register1 =[];
        $data_register2 =[];
        $data_register3 =[];
        $data_register4 =[];
        $label = [];
        $in = [];
        $in_card = [];
        $logins =[];
        $registers0 =[];
        $registers =[];
        $registers1 =[];
        $registers2 =[];
        $registers3 =[];
        $registers4 =[];
        $out = [];
        $data_taixiu = [];
        $taixius = [];
        $data_slot = [];
        $slots = [];

        $data_slot_NC = [];
        $slotsNC = [];

        $data_slot_LS = [];
        $slotsLS = [];

        $data_slot_Poker = [];
        $slotsPoker = [];

        $data_slot_KC = [];
        $slotsKC = [];

        $data_slotTH = [];
        $slotsTH = [];

        $data_gift = [];
        $gift = [];
        //

        for ($i = 0; $i < $day_in_month ; $i++){
            $day = $i+1;
            $label[] = 'Ngày '.$day;

            if (isset($cash_in[$i])){
                $data_in[$cash_in[$i][0]['day']] = $cash_in[$i][0]['gold'];
            }
            if (isset($cash_in_card[$i])){
                $data_in_card[$cash_in_card[$i][0]['day']] = $cash_in_card[$i][0]['card_num'];
            }
            if (isset($cash_out[$i])){
                $outs[$cash_out[$i][0]['day']] = $cash_out[$i][0]['gold'];
            }

            if (isset($login[$i])){
                $data_login[$login[$i][0]['day']] = $login[$i][0]['login'];
            }

            if (isset($register0[$i])){
                $data_register0[$register0[$i][0]['day']] = $register0[$i][0]['register'];
            }

            if (isset($register[$i])){
                $data_register[$register[$i][0]['day']] = $register[$i][0]['register'];
            }

            if (isset($register1[$i])){
                $data_register1[$register1[$i][0]['day']] = $register1[$i][0]['register'];
            }

            if (isset($register2[$i])){
                $data_register2[$register2[$i][0]['day']] = $register2[$i][0]['register'];
            }
            if (isset($register3[$i])){
                $data_register3[$register3[$i][0]['day']] = $register3[$i][0]['register'];
            }
            if (isset($register4[$i])){
                $data_register4[$register4[$i][0]['day']] = $register4[$i][0]['register'];
            }
            if (isset($taixiu[$i])){
                $data_taixiu[$taixiu[$i][0]['day']] = $taixiu[$i][0]['sum_gold'];
            }

            if (isset($slot[$i])){
                $data_slot[$slot[$i][0]['day']] = $slot[$i][0]['sum_waste_money'];
            }

            if (isset($slotNC[$i])){
                $data_slot_NC[$slotNC[$i][0]['day']] = $slotNC[$i][0]['sum_waste_money'];
            }

            if (isset($slotLS[$i])){
                $data_slot_LS[$slotLS[$i][0]['day']] = $slotLS[$i][0]['sum_waste_money'];
            }

            if (isset($slotTH[$i])){
                $data_slotTH[$slotTH[$i][0]['day']] = $slotTH[$i][0]['sum_waste_money'];
            }

            if (isset($slotPoker[$i])){
                $data_slot_Poker[$slotPoker[$i][0]['day']] = $slotPoker[$i][0]['sum_waste_money'];
            }
            if (isset($slotKC[$i])){
                $data_slot_KC[$slotKC[$i][0]['day']] = $slotKC[$i][0]['sum_waste_money'];
            }

            if (isset($giftCode[$i])){
                $data_gift[$giftCode[$i][0]['day']] = $giftCode[$i][0]['gold'];
            }
            //
            if (array_key_exists($day,$data_in)){
                $in[] = $data_in[$day];
            }else{
                $in[] = 0;
            }

            if (array_key_exists($day,$data_in_card)){
                $in_card[] = $data_in_card[$day];
            }else{
                $in_card[] = 0;
            }

            if (array_key_exists($day,$data_login)){
                $logins[] = $data_login[$day];
            }else{
                $logins[] = 0;
            }

            if (array_key_exists($day,$data_register0)){
                $registers0[] = $data_register0[$day];
            }else{
                $registers0[] = 0;
            }

            if (array_key_exists($day,$data_register)){
                $registers[] = $data_register[$day];
            }else{
                $registers[] = 0;
            }

            if (array_key_exists($day,$data_register1)){
                $registers1[] = $data_register1[$day];
            }else{
                $registers1[] = 0;
            }

            if (array_key_exists($day,$data_register2)){
                $registers2[] = $data_register2[$day];
            }else{
                $registers2[] = 0;
            }
            if (array_key_exists($day,$data_register3)){
                $registers3[] = $data_register3[$day];
            }else{
                $registers3[] = 0;
            }
            if (array_key_exists($day,$data_register4)){
                $registers4[] = $data_register4[$day];
            }else{
                $registers4[] = 0;
            }

//            if (array_key_exists($day,$outs)){
//                $out[] = $outs[$day];
//            }else{
//                $out[] = 0;
//            }

            if (array_key_exists($day,$data_taixiu)){
                $taixius[] = $data_taixiu[$day];
            }else{
                $taixius[] = 0;
            }

            if (array_key_exists($day,$data_slot)){
                $slots[] = $data_slot[$day] * 50;
            }else{
                $slots[] = 0;
            }

            if (array_key_exists($day,$data_slot_NC)){
                $slotsNC[] = $data_slot_NC[$day] * 50;
            }else{
                $slotsNC[] = 0;
            }

            if (array_key_exists($day,$data_slot_LS)){
                $slotsLS[] = $data_slot_LS[$day] * 50;
            }else{
                $slotsLS[] = 0;
            }

            if (array_key_exists($day,$data_slotTH)){
                $slotsTH[] = $data_slotTH[$day] * 50;
            }else{
                $slotsTH[] = 0;
            }
            if (array_key_exists($day,$data_slot_Poker)){
                $slotsPoker[] = $data_slot_Poker[$day] * 50;
            }else{
                $slotsPoker[] = 0;
            }
            if (array_key_exists($day,$data_slot_KC)){
                $slotsKC[] = $data_slot_KC[$day] * 50;
            }else{
                $slotsKC[] = 0;
            }

            if (array_key_exists($day,$data_gift)){
                $gift[] = $data_gift[$day];
            }else{
                $gift[] = 0;
            }
        }

        $label = json_encode($label,JSON_UNESCAPED_UNICODE);
        $labelCCU = json_encode($labelCCU,JSON_UNESCAPED_UNICODE);
        $in = json_encode($in,true);
        $in_card = json_encode($in_card,true);

        $logins = json_encode($logins,true);
        $registers0 = json_encode($registers0,true);
        $registers = json_encode($registers,true);
        $registers1 = json_encode($registers1,true);
        $registers2 = json_encode($registers2,true);
        $registers3 = json_encode($registers3,true);
        $registers4 = json_encode($registers4,true);
        $out = json_encode($out,true);
        $taixius = json_encode($taixius,true);
        $slots = json_encode($slots,true);

        $slotsNC = json_encode($slotsNC,true);
        $slotsLS = json_encode($slotsLS,true);
        $slotsTH = json_encode($slotsTH,true);
        $slotsKC = json_encode($slotsKC,true);
        $slotsPoker = json_encode($slotsPoker,true);

        $gift = json_encode($gift,true);
        $a3User = json_encode($a3User,true);

        $ccu = json_encode($ccu,true);
        $this->set([
            'cash_in' => $in,
            'cash_in_card' => $in_card,
            'cash_out' => $out,
            'logins' => $logins,
            'registers0' => $registers0,
            'registers' => $registers,
            'registers1' => $registers1,
            'registers2' => $registers2,
            'registers3' => $registers3,
            'registers4' => $registers4,
            'taixius' => $taixius,
            'slots' => $slots,
            'slotsNC' => $slotsNC,
            'slotsLS' => $slotsLS,
            'slotsTH' => $slotsTH,
            'slotsKC' => $slotsKC,
            'slotsPoker' => $slotsPoker,

            'gift' => $gift,
            'a3User' => $a3User,
            'ccu' => $ccu,
            'labelCCU' => $labelCCU,

            'cur_day'=>$cur_day,
            'cur_month'=>$cur_month,
            'cur_year'=>$cur_year,
            'day_in_month'=>$day_in_month,
            'label' => $label
        ]);
    }
}
