<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */


class QuanTriVienController extends AppController
{
    public $components = array('Paginator');

    public $uses = [ 'AdmincpGroup', 'AdmincpMember', 'UserVerifiled' ,'Admincp'];
    public function quantri_create_group(){
        $this->set('title_for_layout', 'Quản trị Nhóm');
        $this->set('activeMenu', 'quantri_list_group');
        if ($this->request->is('post')) {
//            pr($this->request->data);
            $this->AdmincpGroup->create();
            $arr = $this->request->data['admincp_group']['acl'];
            $type = "";

            for($i = 0; $i < count($arr); $i++){
                if($arr[$i] == 1){
                    $type .= "QuanLyMember,";
                }else if($arr[$i] == 2){
                    $type .= "QuanLyGame,";
                }else if($arr[$i] == 3){
                    $type .= "QuanLyGameBai,";
                }else if($arr[$i] == 4){
                    $type .= "ThongKe,";
                }else if($arr[$i] == 5){
                    $type .= "QuanLyDaiLy,";
                }else if($arr[$i] == 6){
                    $type .= "Setting,";
                }else if($arr[$i] == 7){
                    $type .= "LichSu,";
                }else {
                    $type .= "Tool,";
                }
            }
//            pr($this->request->data['admincp_group']);
//            $this->request->data['admincp_group']['name'] = $this->request->data['admincp_group']['name_group'];
//            $this->request->data['admincp_group']['acl'] = $type;
            $curDate = date("Y-m-d H:i:s");
            if ($this->AdmincpGroup->save(array(
                'name' => $this->request->data['admincp_group']['name'],
                'acl' => $type,
                'created' => $curDate,
            ))) {
                $this->Flash->success(__('Tạo nhóm thành công.'));
                return $this->redirect(array('action' => 'quantri_list_group'));
            } else {
                $this->Flash->error(__('Tạo nhóm không thành công.'));
            }
        }

        $options = array(1 => 'Quản lý member', 'Quản lý game', 'Quản lý game bài', 'Thống Kê', 'Quản Lý Đại Lý', 'Settings', 'Lịch sử', 'Tool vận hành');
        $selected = array();

        $this->set('options' , $options);
        $this->set('selected' , $selected);
    }

    public function quantri_edit_group($id = null) {
        $this->set('title_for_layout', 'Quản trị Nhóm');
        $this->set('activeMenu', 'quantri_list_group');
        $id = $this->request->query('id');
        if (!$this->AdmincpGroup->exists($id)) {
            throw new NotFoundException(__('Không tồn tại'));
        }
        if ($this->request->is(array('post', 'put'))) {

            $arr = $this->request->data['admincp_group']['acl'];
            $type = "";

            for($i = 0; $i < count($arr); $i++){
                if($arr[$i] == 1){
                    $type .= "QuanLyMember,";
                }else if($arr[$i] == 2){
                    $type .= "QuanLyGame,";
                }else if($arr[$i] == 3){
                    $type .= "QuanLyGameBai,";
                }else if($arr[$i] == 4){
                    $type .= "ThongKe,";
                }else if($arr[$i] == 5){
                    $type .= "QuanLyDaiLy,";
                }else if($arr[$i] == 6){
                    $type .= "Setting,";
                }else if($arr[$i] == 7){
                    $type .= "LichSu,";
                }else {
                    $type .= "ToolVanHanh,";
                }
            }
            $curDate = date("Y-m-d H:i:s");
            if ($this->AdmincpGroup->save(array(
                'id' => $id,
                'name' => $this->request->data['admincp_group']['name'],
                'acl' => $type,
                'created' => $curDate,
            ))) {
                $this->Flash->success(__('Sửa nhóm thành công.'));
                return $this->redirect(array('action' => 'quantri_list_group'));
            } else {
                $this->Flash->error(__('Sửa nhóm không thành công.'));
            }
        }

        $admincp = $this->AdmincpGroup->find("first",[
            'conditions' => [
                'id' => $id
            ]
        ]);
//        echo $id;
//        pr($admincp);
        $arr = explode(',',$admincp['AdmincpGroup']['acl']);
        $options = array(1 => 'Quản lý member', 'Quản lý game', 'Quản lý game bài', 'Thống Kê', 'Quản Lý Đại Lý', 'Settings', 'Lịch sử', 'Tool vận hành');
        $selected = array();
        for($i = 0; $i < count($arr); $i++){
            if($arr[$i] == 'QuanLyMember'){
                $selected[] = 1;
            }else if($arr[$i] == 'QuanLyGame'){
                $selected[] = 2;
            }else if($arr[$i] == 'QuanLyGameBai'){
                $selected[] = 3;
            }else if($arr[$i] == 'ThongKe'){
                $selected[] = 4;
            }else if($arr[$i] == 'QuanLyDaiLy'){
                $selected[] = 5;
            }else if($arr[$i] == 'Setting'){
                $selected[] = 6;
            }else if($arr[$i] == 'LichSu'){
                $selected[] = 7;
            }else if($arr[$i] == 'ToolVanHanh'){
                $selected[] = 8;
            }
        }

        $this->set('options' , $options);
        $this->set('selected' , $selected);
        $this->set('admincp' , $admincp);

    }

    public function quantri_delete_group($id = null) {
        $this->set('title_for_layout', 'Quản trị Nhóm');
        $this->set('activeMenu', 'quantri_list_group');
        $id = $this->request->query('id');

        $this->AdmincpGroup->id = $id;
        if (!$this->AdmincpGroup->exists()) {
            throw new NotFoundException(__('Không tồn tại'));
        }

        if ($this->AdmincpGroup->delete()) {
            $this->Flash->success(__('Xoá nhóm thành công.'));
        } else {
            $this->Flash->error(__('Xoá nhóm không thành công.'));
        }
        return $this->redirect(array('action' => 'quantri_list_group'));

    }

    public function quantri_list_group(){
        $this->set('title_for_layout', 'Quản trị Nhóm');
        $this->set('activeMenu', 'quantri_list_group');
        $list_group = $this->AdmincpGroup->find("all",[
        ]);
        $this->paginate = [
            'conditions' => [
                'AdmincpGroup.id >' => 1,
            ]
        ];

        $this->set('list_group', $this->Paginator->paginate('AdmincpGroup'));
    }

    //Member
    public function quantri_create_member(){
        $this->set('title_for_layout', 'Quản trị thành viên');
        $this->set('activeMenu', 'quantri_list_member');
        $list_group = $this->AdmincpGroup->find("all",[
            'conditions' => [
                'AdmincpGroup.id >' => 1,
            ]
        ]);
        if ($this->request->is('post')) {
            $this->AdmincpMember->create();
            $group = $this->request->data['admincp_member']['group'];

            $curDate = date("Y-m-d H:i:s");
            if ($this->AdmincpMember->save(array(
                'username' => $this->request->data['admincp_member']['username'],
                'password' => md5($this->request->data['admincp_member']['password']),
                'displayname' => $this->request->data['admincp_member']['displayname'],
                'phone' => $this->request->data['admincp_member']['phone'],
                'groupid' => $list_group[$group]['AdmincpGroup']['id'],
                'created' => $curDate,
            ))) {
                $this->Flash->success(__('Tạo thành viên thành công.'));
                return $this->redirect(array('action' => 'quantri_list_member'));
            } else {
                $this->Flash->error(__('Tạo thành viên không thành công.'));
            }
        }



        $options = [];
        for($i = 0; $i < count($list_group); $i++) {
            $options[] = $list_group[$i]['AdmincpGroup']['name'];
        }

        $this->set('options' , $options);

    }

    public function quantri_edit_member($id = null) {
        $this->set('title_for_layout', 'Quản trị thành viên');
        $this->set('activeMenu', 'quantri_list_member');
        $id = $this->request->query('id');
        if (!$this->AdmincpMember->exists($id)) {
            throw new NotFoundException(__('Không tồn tại'));
        }
        $member = $this->AdmincpMember->find("first",[
            'conditions' => [
                'AdmincpMember.id' => $id,
            ]
        ]);
        $list_group = $this->AdmincpGroup->find("all",[
            'conditions' => [
                'AdmincpGroup.id >' => 1,
            ]
        ]);
        if ($this->request->is('post')) {
            $group = $this->request->data['admincp_member']['group'];

            $curDate = date("Y-m-d H:i:s");
            if(strlen($this->request->data['admincp_member']['password']) == 32){
                $conditions = array(
                    'id' => $id,
                    'username' => $this->request->data['admincp_member']['username'],
                    'displayname' => $this->request->data['admincp_member']['displayname'],
                    'phone' => $this->request->data['admincp_member']['phone'],
                    'groupid' => $list_group[$group]['AdmincpGroup']['id'],
                    'created' => $curDate,
                );
            }else{
                $conditions = array(
                    'id' => $id,
                    'username' => $this->request->data['admincp_member']['username'],
                    'password' => md5($this->request->data['admincp_member']['password']),
                    'displayname' => $this->request->data['admincp_member']['displayname'],
                    'phone' => $this->request->data['admincp_member']['phone'],
                    'groupid' => $list_group[$group]['AdmincpGroup']['id'],
                    'created' => $curDate,
                );
            }
            if ($this->AdmincpMember->save($conditions)) {
                $this->Flash->success(__('Sửa thành viên thành công.'));
                return $this->redirect(array('action' => 'quantri_list_member'));
            } else {
                $this->Flash->error(__('Sửa thành viên không thành công.'));
            }
        }


        $select = 0;
        $options = [];
        for($i = 0; $i < count($list_group); $i++) {
            $options[] = $list_group[$i]['AdmincpGroup']['name'];
            if($member['AdmincpMember']['groupid'] == $list_group[$i]['AdmincpGroup']['id'])
                $select = $i;
        }
        $this->set('options' , $options);
        $this->set('select' , $select);
        $this->set('member' , $member);

    }

    public function quantri_list_member(){
        $this->set('title_for_layout', 'Quản trị thành viên');
        $this->set('activeMenu', 'quantri_list_member');
        $this->paginate = [
            'fields' => array('AdmincpMember.*', 'AdmincpGroup.*'),
            'joins' => array(
                array(
                    'table' => 'admincp_group',
                    'alias' => 'AdmincpGroup',
                    'type' => 'INNER',
                    'conditions' => array(
                        'AdmincpMember.groupid = AdmincpGroup.id'
                    )
                )
            ),
            'conditions' => [
                'AdmincpMember.id >' => 1,
            ]
        ];

        $this->set('list_member', $this->Paginator->paginate('AdmincpMember'));
    }

    public function quantri_delete_member($id = null) {
        $this->set('title_for_layout', 'Quản trị thành viên');
        $this->set('activeMenu', 'quantri_list_member');
        $id = $this->request->query('id');

        $this->AdmincpMember->id = $id;
        if (!$this->AdmincpMember->exists()) {
            throw new NotFoundException(__('Không tồn tại'));
        }

        if ($this->AdmincpMember->delete()) {
            $this->Flash->success(__('Xoá nhóm thành công.'));
        } else {
            $this->Flash->error(__('Xoá nhóm không thành công.'));
        }
        return $this->redirect(array('action' => 'quantri_list_member'));

    }
    //------

    public function danh_sach_thanh_vien() {
    }

    public function nhom() {
    }

    public function phan_quyen() {
    }


}
