<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */


class SettingController extends AppController
{

    public function cai_dat_cong_thanh_toan() {
        $this->set('title_for_layout', 'Cài đặt cổng thanh toán');
        $this->set('activeMenu', 'cai_dat_cong_thanh_toan');
    }

    public function cai_dat_phe() {
        $this->set('title_for_layout', 'Cài đặt phế');
        $this->set('activeMenu', 'cai_dat_phe');
    }

    public function cai_dat_nap_the() {
        $this->set('title_for_layout', 'Cài đặt nạp thẻ');
        $this->set('activeMenu', 'cai_dat_nap_the');
    }

    public function tool_chuc_nang() {
        $this->set('title_for_layout', 'Tool chức năng');
        $this->set('activeMenu', 'tool_chuc_nang');
    }

}
