<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */

//commit
class QuanLyDaiLyController extends AppController
{
    public $components = array('Paginator');
    public $uses = [ 'Agency', 'User', 'GiftCode', 'Trade','AgencyBlocks','Agencys'];

    public function danh_sach_dai_ly() {
        $this->set('title_for_layout', 'Danh sách đại lý');
        $this->set('activeMenu', 'danh_sach_dai_ly');

        $dataGet = $this->request->query;

        if (isset( $dataGet["keyword"] ) && strlen($dataGet["keyword"]) > 5) {
            $conditions = [
                "OR" => [
                    'Agency.name' => $dataGet["keyword"],
                    'Agency.displayname' => $dataGet["keyword"]
                ]
            ];

        }else{
            $conditions = [];
        }
        if (isset($dataGet["type"]) && is_array($dataGet["type"])) {
            if (count($dataGet["type"]) == 1) {
                if ($dataGet["type"][0] == 1) {
                    $conditions['Agency.parent'] = 0;
                } else if ($dataGet["type"][0] == 2) {
                    $conditions['Agency.parent <>'] = 0;
                }
            } else {

                $conditions['Agency.parent >'] = -1;
            }
        } else {
            $conditions['Agency.parent >'] = -1;
        }
        if (isset($dataGet["status"]) && is_array($dataGet["status"])) {
            $conditions["Agency.status IN"] = $dataGet["status"];
        }
        $this->paginate = [
            'fields' => ['Agency.*', 'Agency1.displayname'],
            'joins' => array(
                array(
                    'table' => 'agencies',
                    'alias' => 'Agency1',
                    'type' => 'LEFT',
                    'conditions' => array(
                        'Agency.parent = Agency1.userid',
                    )
                )
            ),
            'order' => 'Agency.parent',
            'conditions' => $conditions
        ];
        //xóa khóa khi refresh
        $agency_blocks = $this->AgencyBlocks->find('all');
        foreach ($agency_blocks as $arry) {
          $datebanned = $arry['AgencyBlocks']['block_date'];
          $datenow = date("Y-m-d H:i:s");
            if($datebanned  < $datenow){
              $this->Agency->save(array(
                  'id' => $arry['AgencyBlocks']['agencies_id'],
                  'status' => 0,
                ));
                $this->AgencyBlocks->id = $arry['AgencyBlocks']['id'];
                $this->AgencyBlocks->delete();
              }
          }

        $this->set('data', $this->Paginator->paginate('Agency'));
    }

    public function getUserNameById() {
        $dataGet    = $this->request->query;
        $id       = isset( $dataGet['id'] ) ? trim( $dataGet["id"] ) : null;
        $dataReturn = [
            "status" => false,
            "data"   => null
        ];
        if ( $id ) {
            $user = $this->User->find( 'first', [
                'recursive'  => -1,
                'conditions' => [
                    'id' => $id
                ]
            ] );
            if ( $user ) {
                $dataReturn["status"] = true;
                $dataReturn["data"]   = $user["User"]["displayname"];
            }
        }
        header( "Content-type: application/json" );
        echo json_encode( $dataReturn );
        die;
    }

    public function getUserNameById1($id) {
        $this->User->recursive = -1;
        $user = $this->User->findById($id);
        if ($user) {
            return $user["User"]["displayname"];
        }
        return "";
    }

    public function tao_dai_ly() {
        $this->set('title_for_layout', 'Tạo đại lý');
        $this->set('activeMenu', 'tao_dai_ly');
        if ($this->request->is('post')) {
            $dataPost = $this->request->data;
            CakeLog::write('GameManagerController', $dataPost['Agency']);
            $user = $this->User->find('first', ['fields' => ["User.username"], 'conditions' => ["User.id" => $dataPost['Agency']['userid']]]);
            $dataPost['Agency']['username'] = $user['User']['username'];
            if(isset($user['User']['cid']))
                $dataPost['Agency']['teleid'] = $user['User']['cid'];
            $dataPost['Agency']['password'] = md5($dataPost['Agency']['password']);
            // some missed params
            $dataPost['Agency']['num'] = 0;
            $dataPost['Agency']['level'] = 0;
            $dataPost['Agency']['gold'] = 0;
            $dataPost['Agency']['subgold'] = 0;
            $dataPost['Agency']['created'] = date('Y-m-d h:i:s');
            if ($this->Agency->save($dataPost['Agency'])) {
                $this->Flash->success('Tạo đại lý thành công !');
                $this->User->updateAll([
                    'agency' => 1
                ], [
                    'id' => $dataPost["Agency"]["userid"]
                ]);
            } else {
                $this->Flash->error('Có lỗi xảy ra !');
            }
            return $this->redirect(['action' => 'danh_sach_dai_ly']);
        }
        $options = [];
        $options[0] = "-- Tạo Đại lý cấp 1";
        $listAgency = $this->Agency->find("all",[
            'conditions' => [
                'Agency.parent' => 0,
                'Agency.status <>' => 2,

            ]
        ]);
        for($i = 0; $i < count($listAgency); $i++){
            $options['Cấp 2 của: '][$listAgency[$i]['Agency']['id']] = $listAgency[$i]['Agency']['name'];
        }
        $this->set('options',$options);
    }

    public function sua_dai_ly() {
        $this->set('title_for_layout', 'Sửa đại lý');
        $this->set('activeMenu', 'sua_dai_ly');
        $id = $this->request->query('id');
        if (!$this->Agency->exists($id)) {
            throw new NotFoundException(__('Không tồn tại'));
        }
        $agency = $this->Agency->find("first",[
            'conditions' => [
                'Agency.id' => $id,
            ]
        ]);

        if ($this->request->is('post')) {
            $dataPost = $this->request->data;
            $dataPost['Agency']['id'] = $id;
            if ($dataPost['Agency']['password'] != $agency['Agency']['password']) {
                $dataPost['Agency']['password'] = md5($dataPost['Agency']['password']);
            }
            if ($this->Agency->save($dataPost['Agency'])) {
                $this->Flash->success('Sửa đại lý thành công !');
            } else {
                $this->Flash->error('Có lỗi xảy ra !');
            }
            return $this->redirect(['action' => 'danh_sach_dai_ly']);
        }

        $options = [];
        $options[0] = "Đại lý cấp 1";
        $listAgency = $this->Agency->find("all",[
            'conditions' => [
                'Agency.parent' => 0,
                'Agency.status <>' => 2,

            ]
        ]);
        for($i = 0; $i < count($listAgency); $i++){
            $options['Cấp 2 của: '][$listAgency[$i]['Agency']['id']] = $listAgency[$i]['Agency']['name'];
        }
        $selected = 0;
        for($i = 0; $i < count($listAgency); $i++){
            if($agency['Agency']['parent'] == $listAgency[$i]['Agency']['userid']){
                $selected = $i + 1;
            }

        }
        $this->set('selected',$selected);
        $this->set('options',$options);
        $this->set('agency',$agency);

    }

    public function daily_delete($id = null) {
        $this->set('title_for_layout', 'Danh sách đại lý');
        $this->set('activeMenu', 'danh_sach_dai_ly');
        $id = $this->request->query('id');

        $this->Agency->id = $id;
        $agency = $this->Agency->findById($id);
        if (!$this->Agency->exists()) {
            throw new NotFoundException(__('Không tồn tại'));
        }

        if ($this->Agency->delete()) {
            $this->User->updateAll([
                'agency' => 0
            ], [
                'id' => $agency["Agency"]["userid"]
            ]);
            $this->Flash->success(__('Xoá đại lý thành công.'));
        } else {
            $this->Flash->error(__('Xoá đại lý không thành công.'));
        }
        return $this->redirect(array('action' => 'danh_sach_dai_ly'));

    }

    // public function ban_unban($id = null){
    //     $agency = $this->Agency->find('first', [
    //         'conditions' => [
    //             "Agency.id" => $id
    //         ],
    //     ]);
    //     if (!$agency) {
    //         $this->Flash->error('Không tim thấy tài khoản !');
    //         return $this->redirect($this->referer());
    //     }
    //
    //     if($agency['Agency']['status'] == 0) {
    //         $this->Flash->success("Xử lý thành công.");
    //         $this->Agency->save(array(
    //             'id' => $agency['Agency']['id'],
    //             'status' => 1,
    //         ));
    //     }
    //     else{
    //         $this->Flash->success("Xử lý thành công.");
    //         $this->Agency->save(array(
    //             'id' => $agency['Agency']['id'],
    //             'status' => 0,
    //         ));
    //     }
    //     return $this->redirect(['action' => 'danh_sach_dai_ly']);
    // }

    public function tra_cuu_giftcode() {
        $this->set('title_for_layout', 'Tra cứu GiftCode');
        $this->set('activeMenu', 'tra_cuu_giftcode');

        $dataGet = $this->request->query;

        if (isset($dataGet["keyword"]) && !empty($dataGet["keyword"])) {

            $user = $this->User->find("first",[
                "conditions" => [
                    'displayname' => $dataGet["keyword"]
                ]
            ]);
//            pr($user);
            $id = -1;
            if(count($user) > 0) {
                $id = $user['User']['id'];
                $conditions = [
                    "GiftCode.id in (select user_codes.codeid from user_codes where userid = " . $id . ")"
                ];
            }else{
                $conditions = [
                    "GiftCode.code" => $dataGet["keyword"]
                ];
            }
            $this->paginate = [
                "conditions" => $conditions,
                "order" => 'GiftCode.id desc'
            ];

            $this->set("giftCodes",$this->paginate( "GiftCode" ));
            $this->set("isData",true);
        }else
            $this->set("isData",false);


    }



    public function thong_ke() {
        $this->set('title_for_layout', 'Thống kê');
        $this->set('activeMenu', 'thong_ke');

        $dataGet = $this->request->query;
        $wh = "";
        $conditions = [];
        if ( isset( $dataGet["keyword"] ) && trim( $dataGet["keyword"] ) != "" ) {
            $this->set('isData', true);
            $conditions = [
                'name' => $dataGet["keyword"]
            ];
        }else{
            $this->set('isData', false);
        }
        if (isset($dataGet["start_date"]) && $dataGet["start_date"]) {
            $wh = "DATE(created) >= '".$dataGet["start_date"] . "' and DATE(created) <='".$dataGet["end_date"] . "'";
        } else {
            $wh = "DATE(created) >= '".date("Y-m-01") ."' and DATE(created) <='".date("Y-m-d")."'";
        }

        $agency = $this->Agency->find("all",[
            'fields' => array(
                "Agency.*",
                '(select sum(gold) from trades where '.$wh.' and user = Agency.name and user_target not in (select name from agencies))as tongbankhach',
                '(select sum(gold) from trades where '.$wh.' and user_target = Agency.name and user not in (select name from agencies))as tongmuakhach',
                '(select sum(gold) from trades where '.$wh.' and user = Agency.name and user_target in (select name from agencies where parent = 0))as tongbandl1',
                '(select sum(gold) from trades where '.$wh.' and user_target = Agency.name and user in (select name from agencies where parent = 0))as tongmuadl1',
                '(select sum(gold) from trades where '.$wh.' and user = Agency.name and user_target in (select name from agencies where parent > 0))as tongbandl2',
                '(select sum(gold) from trades where '.$wh.' and user_target = Agency.name and user in (select name from agencies where parent > 0))as tongmuadl2',
                '(select sum(gold) from trades where '.$wh.' and user = Agency.name and user_target in (select name from agencies where parent < 0))as tongbandltong',
                '(select sum(gold) from trades where '.$wh.' and user_target = Agency.name and user in (select name from agencies where parent < 0))as tongmuadltong',
            ),
            "conditions" => $conditions,
            "order" => 'parent asc'
        ]);

        $this->set('agency', $agency);
    }

    public function thongke_tongdat(){
        $this->set( 'title_for_layout', 'Thống kê Luồng' );
        $this->set( 'activeMenu', 'thongke_tongdat' );
        $dataGet = $this->request->query;
        if ( isset( $dataGet["start_date"] ) && $dataGet["start_date"] && isset( $dataGet["end_date"] ) && $dataGet["end_date"] ) {
            $dt = "DATE(created) >= '" . $dataGet["start_date"] . "' and " . "DATE(created) <= '" .$dataGet["end_date"] ."'";
        } else {
            $dt = "DATE(created) >= '" . date( "Y-m-01" ) . "' and " . "DATE(created) <= '" . date( "Y-m-d" )."'";
        }
        $agency = $this->Trade->query('select agencies.displayname,agencies.name,agencies.userid,agencies.parent from agencies');
        for($i = 0; $i < count($agency); $i ++){
            $agency[$i]['agencies']['gold'] = 0;
            $agency[$i]['agencies']['listUser'] = [];

            $listUser = $this->getListUserTradeByAgency($agency[$i]['agencies']['name'], $dt);
            for($j = 0; $j < count($listUser); $j++){
                if($this->getUserTradeMaxByAgency($agency[$i]['agencies']['name'], $listUser[$j], $dt)){
                    $gold = $this->getGoldByUser($listUser[$j], $dt);
                    $agency[$i]['agencies']['gold'] += $gold;
                    $agency[$i]['agencies']['listUser'][] = array($listUser[$j],$gold);
//                    $agency[$i]['agencies']['listUser'][] = $listUser[$j];
                }
            }
        }
        for($i = 0; $i < count($agency); $i ++){
            if($agency[$i]['agencies']['parent'] > 0){
                for($j = 0; $j < count($agency); $j ++){
                    if($agency[$i]['agencies']['parent'] == $agency[$j]['agencies']['userid']){
                        $agency[$j]['agencies']['gold'] += $agency[$i]['agencies']['gold'];
                        for($k = 0; $k < count($agency[$i]['agencies']['listUser']); $k++){
                            $agency[$j]['agencies']['listUser'][] = $agency[$i]['agencies']['listUser'][$k];
                        }

                    }
                }
            }
        }

        //sap xep
        for($i = 0; $i < count($agency) - 1; $i ++){
            for($j = $i + 1; $j < count($agency); $j ++){
                if($agency[$i]['agencies']['parent'] == 0 && $agency[$j]['agencies']['parent'] == 0){
                    if($agency[$j]['agencies']['gold'] > $agency[$i]['agencies']['gold']){
                        $tmp = $agency[$j]['agencies'];
                        $agency[$j]['agencies'] = $agency[$i]['agencies'];;
                        $agency[$i]['agencies'] = $tmp;
                    }
                }
            }
            //Sắp xếp list User
            if($agency[$i]['agencies']['parent'] == 0) {
                for ($j = 0; $j < count($agency[$i]['agencies']['listUser']) - 1; $j++){
                    for ($k = $j + 1; $k < count($agency[$i]['agencies']['listUser']); $k++){
                        if($agency[$i]['agencies']['listUser'][$k][1] > $agency[$i]['agencies']['listUser'][$j][1]){
                            $tmp = $agency[$i]['agencies']['listUser'][$k];
                            $agency[$i]['agencies']['listUser'][$k] = $agency[$i]['agencies']['listUser'][$j];
                            $agency[$i]['agencies']['listUser'][$j] = $tmp;
                        }
                    }
                }

            }
        }

//        pr($agency);
        $this->set("agency", $agency);
    }

    public function getListUserTradeByAgency($agency , $dt){
        $listUser = [];
        $trade1 = $this->Trade->query('select user as displayname from trades where user_target = "'.$agency.'" and '.$dt.' group by displayname');

        for($i = 0; $i< count($trade1); $i++){
            if(!in_array($trade1[$i]['trades']['displayname'], $listUser)){
                $listUser[] = $trade1[$i]['trades']['displayname'];
            }
        }

        $trade2 = $this->Trade->query('select user_target as displayname from trades where user = "'.$agency.'" and '.$dt.' group by displayname');
        for($i = 0; $i< count($trade2); $i++){
            if(!in_array($trade2[$i]['trades']['displayname'], $listUser)){
                $listUser[] = $trade2[$i]['trades']['displayname'];
            }
        }

        return $listUser;
    }

    public function getGoldByUser($user, $dt){
        $u = $this->User->find("first",[
            'conditions' => [
                'displayname' => $user
            ]
        ]);
        if(count($u) == 0)
            return 0;
        $qr = 'select sum(phe) as phe from user_change_golds where userid = '.$u['User']['id'].' and gameid < 100 and '.$dt;
        $gold = $this->Trade->query($qr);
//        pr($gold);
        if(isset($gold[0][0]['phe']))
            return $gold[0][0]['phe'];
        return 0;
    }

    private function getUserTradeMaxByAgency($agency, $user, $dt){
        $qr = '
            select *, sum(gold) as gold , (select sum(gold) from trades where (Trade.user = user and Trade.user_target = user_target) OR (Trade.user = user_target and Trade.user_target = user)) as goldTotal from trades as Trade
            where
            ((user in (select agencies.name from agencies) and user_target not in (select agencies.name from agencies)) or
            (user_target in (select agencies.name from agencies) and user not in (select agencies.name from agencies)))
            and (user = "' . $user .'" or user_target = "' . $user .'")
            and '.$dt.'
            group by user, user_target
            order by gold desc, modified limit 1';

        $tradeGold = $this->Trade->query($qr);
        if(count($tradeGold) == 0)
            return -1;
        if($agency != $tradeGold[0]['Trade']['user'] && $agency != $tradeGold[0]['Trade']['user_target'])
            return 0;
        return 1;
    }

    public function khoa_daily(){
      $this->set( 'title_for_layout', 'Quản lý khóa đại lý' );
      $this->set( 'activeMenu', 'khoa_daily' );

      $search = $this->request->query('keyword');
      $type = $this->request->query('type');
      $conditions = [];
      if (trim($search) != '') {
          if ($type == "agencies_displayname") {
              $conditions['AgencyBlocks.agencies_displayname'] = $search;
          } else if ($type == "agencies_id") {
              $conditions['AgencyBlocks.agencies_id'] = $search;
          }else {
              $conditions['AgencyBlocks.id'] = $search;
          }
      }
      $this->paginate = [
          'conditions' => $conditions,
          'order' => 'AgencyBlocks.id DESC'
      ];

      //xóa khóa khi refresh
      $agency_blocks = $this->AgencyBlocks->find('all');
      foreach ($agency_blocks as $arry) {
        $datebanned = $arry['AgencyBlocks']['block_date'];
        $datenow = date("Y-m-d H:i:s");
          if($datebanned  < $datenow){
            $this->Agency->save(array(
                'id' => $arry['AgencyBlocks']['agencies_id'],
                'status' => 0,
              ));
              $this->AgencyBlocks->id = $arry['AgencyBlocks']['id'];
              $this->AgencyBlocks->delete();
            }
        }

      $this->set('agenciesBlocksSearch', $this->Paginator->paginate('AgencyBlocks'));

    }



    public function ban_daily($id = null){
      $this->set( 'title_for_layout', 'Khóa tài khoản đại lý' );
      $this->set( 'activeMenu', 'ban_daily' );

      $agency = $this->Agencys->find('first', [
          'conditions' => [
              "Agencys.id" => $id
          ],
      ]);
      if (!$agency) {
          $this->Flash->error('Không tim thấy tài khoản !');
          return $this->redirect($this->referer());
      }
      $loginuser = $this->Session->read( 'USER_LOGIN' );
      if($this->request->is('post')){
        $dataPost = $this->request->data;
        $agencies_id = $dataPost['ban_daily']['id'];
        $agencies_displayname = $dataPost['ban_daily']['username'];
        $manager = $dataPost['ban_daily']['manager'];
        $content = $dataPost['ban_daily']['content'];

        $nam = $dataPost['ban_daily']['nam'];
        $thang = $dataPost['ban_daily']['thang'];
        $ngay = $dataPost['ban_daily']['ngay'];
        $gio = $dataPost['ban_daily']['gio'];
        $phut = $dataPost['ban_daily']['phut'];
        $datenow = date("Y-m-d H:i:s");
        $addphut = date('Y-m-d H:i:s', strtotime('+'.$phut.' minutes', strtotime($datenow)));
        $addgio = date('Y-m-d H:i:s', strtotime('+'.$gio.' hours', strtotime($addphut)));
        $addngay = date('Y-m-d H:i:s', strtotime('+'.$ngay.' days', strtotime($addgio)));
        $addthang = date('Y-m-d H:i:s', strtotime('+'.$thang.' months', strtotime($addngay)));
        $addnam = date('Y-m-d H:i:s', strtotime('+'.$nam.' years', strtotime($addthang)));
        $this->Flash->success("Xử lý thành công.");
        $this->AgencyBlocks->save(array(
            'agencies_displayname' => $agencies_displayname,
            'agencies_id' => $agencies_id,
            'manager' => $manager,
            'content' => $content,
            'block_date' => $addnam
        ));
        $this->Agencys->save(array(
        'id' => $agencies_id,
        'status' => 1,
        ));
        $this->Flash->success("Xử lý thành công.");
        return $this->redirect(array('action' => 'khoa_daily'));
      }else{

      }


      $this->set('agency',$agency);
      $this->set('loginuser',$loginuser);
    }

    public function un_banned_dai_ly($id = null){
      $this->set( 'title_for_layout', 'Xóa khóa tài khoản cho đại lý' );
      $this->set( 'activeMenu', 'un_banned_dai_ly' );

      $agencyblocks = $this->AgencyBlocks->find('first', [
          'conditions' => [
              "AgencyBlocks.agencies_id" => $id
          ],
      ]);
      $id_block = $agencyblocks['AgencyBlocks']['id'];
      if (!$agencyblocks) {
          $this->Flash->error('Không tim thấy tài khoản !');
          return $this->redirect($this->referer());
      }
      $id_agencies = $agencyblocks['AgencyBlocks']['agencies_id'];
      echo $id_agencies;
      $agency = $this->Agencys->find('first',[
          'conditions' => [
              "Agencys.id" => $id_agencies
          ],
      ]);
      if($agency['Agencys']['status'] == 1) {
        $this->Flash->success("Thành công");
        $this->Agencys->save(array(
            'id' => $agency['Agencys']['id'],
            'status' => 0,
        ));
        $this->AgencyBlocks->id = $id_block;
        $this->AgencyBlocks->delete();
      }else{
        $this->Flash->error("Xóa khóa không thành công.");
      }
      return $this->redirect($this->referer());
    }
    public function sua_khoa_dai_ly(){
      $this->set( 'title_for_layout', 'Sửa khóa tài khoản người dùng' );
      $this->set( 'activeMenu', 'sua_khoa_member' );

      $id = $this->request->query('id');
      $agencyblock = $this->AgencyBlocks->find("first",[
          'conditions' => [
              'AgencyBlocks.agencies_id' => $id,
          ]
      ]);
      ECHO $agencyblock['AgencyBlocks']['agencies_id'];
      $user = $this->Session->read( 'USER_LOGIN' );
      $manager = $user['AdmincpMember']['username'];
      if($this->request->is('post')){
        $dataPost = $this->request->data;
        $agencies_id = $dataPost['ban_daily']['id'];
        $agencies_displayname = $dataPost['ban_daily']['username'];
        $manager = $dataPost['ban_daily']['manager'];
        $content = $dataPost['ban_daily']['content'];

        $nam = $dataPost['ban_daily']['nam'];
        $thang = $dataPost['ban_daily']['thang'];
        $ngay = $dataPost['ban_daily']['ngay'];
        $gio = $dataPost['ban_daily']['gio'];
        $phut = $dataPost['ban_daily']['phut'];
        $datenow = date("Y-m-d H:i:s");
        $addphut = date('Y-m-d H:i:s', strtotime('+'.$phut.' minutes', strtotime($datenow)));
        $addgio = date('Y-m-d H:i:s', strtotime('+'.$gio.' hours', strtotime($addphut)));
        $addngay = date('Y-m-d H:i:s', strtotime('+'.$ngay.' days', strtotime($addgio)));
        $addthang = date('Y-m-d H:i:s', strtotime('+'.$thang.' months', strtotime($addngay)));
        $addnam = date('Y-m-d H:i:s', strtotime('+'.$nam.' years', strtotime($addthang)));

        $this->AgencyBlocks->save(array(
            'id' => $agencyblock['AgencyBlocks']['id'],
            // 'agencies_displayname' => $agencies_displayname,
            // 'agencies_id' => $agencies_id,
            'manager' => $manager,
            'content' => $content,
            'block_date' => $addnam
        ));
        $this->Agencys->save(array(
        'id' => $agencies_id,
        'status' => 1,
        ));
        $this->Flash->success("Xử lý thành công.");
        return $this->redirect(array('action' => 'khoa_daily'));
      }
      $this->set('agencyblocks',$agencyblock);
    }
}
