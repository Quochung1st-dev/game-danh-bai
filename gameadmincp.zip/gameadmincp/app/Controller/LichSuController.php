<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */


class LichSuController extends AppController
{

    public $uses = ['LogUserUpdateGold', 'AdminChangeGold'];

    public function lich_su_cong_tru_tien() {
        $this->set('title_for_layout', 'Lịch sử cộng trừ tiền');
        $this->set('activeMenu', 'lich_su_cong_tru_tien');

        $conditions = [
            'type' => 0
        ];

        if ($this->request->query('keyword')) {
            $conditions['user_target'] = $this->request->query('keyword');
        }

        $this->paginate = [
            'conditions' => $conditions,
            'order' => 'id desc'
        ];

        $this->set("data",$this->paginate( "AdminChangeGold" ));
    }

    public function lich_su_cong_tru_tien_code() {
        $this->set('title_for_layout', 'Lịch sử cộng trừ tiền Code');
        $this->set('activeMenu', 'lich_su_cong_tru_tien_code');

        $conditions = [
            'type' => 1
        ];

        if ($this->request->query('keyword')) {
            $conditions['user_target'] = $this->request->query('keyword');
        }

        $this->paginate = [
            'conditions' => $conditions,
            'order' => 'id desc'
        ];

        $this->set("data",$this->paginate( "AdminChangeGold" ));
    }


    public function lich_su_thay_doi_tien() {
        $this->set('title_for_layout', 'Lich sử thay đổi tiền');
        $this->set('activeMenu', 'lich_su_thay_doi_tien');

        $conditions = [

        ];

        if ($this->request->query('keyword') && $this->request->query('type')) {
            if ($this->request->query('type') == 'displayname') {
                $conditions['userDisplayname'] = $this->request->query('keyword');
            } else {
                $conditions['userID'] = $this->request->query('keyword');
            }
        }

        $this->paginate = [
            'conditions' => $conditions,
            'order' => 'id desc'
        ];

        $this->set("data",$this->paginate( "LogUserUpdateGold" ));
    }



}
