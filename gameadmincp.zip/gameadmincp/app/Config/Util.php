<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/12/2017
 * Time: 9:43 AM
 */
class Util
{
    public static function getRealIpAddr()
    {
//        CakeLog::write('GameManagerController', "getLocation ".json_encode($_SERVER));
        if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
        {
            $ip=$_SERVER['HTTP_CLIENT_IP'];
        }
        elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
        {
            $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
        }
        else
        {
            $ip=$_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }

    public static function getGoldByID( $id ) {
        if(DEBUG)
            return 0;
        try {
            $bucketName = "casino";

// Establish username and password for bucket-access
            $authenticator = new \Couchbase\PasswordAuthenticator();

            $authenticator->username( '' )->password( '' );

// Connect to Couchbase Server
            $cluster = new CouchbaseCluster( "couchbase://127.0.0.1" );

// Authenticate, then open bucket
//$cluster->authenticate($authenticator);
            $bucket = $cluster->openBucket( $bucketName );

// Query with parameters
            $query = CouchbaseN1qlQuery::fromString( 'SELECT * FROM casino USE KEYS ["casino_data4_s_1_UProfileModel.' . $id . '"];' );

            $rows = $bucket->query( $query );
//            pr($rows);
            if ( isset( $rows->rows[0]->casino ) ) {
                return $rows->rows[0]->casino->gold;
            }

            return 0;
        } catch ( Exception $exception ) {
            return 0;
        }
    }

    public static function random_string($length, $upCase = false) {
        $key = '';
        $keys = array_merge(range(0, 9), range('a', 'z'));
        if($upCase == true){
            $keys = array_merge(range(0, 9), range('a', 'z'),range('A', 'Z') );
        }
        for ($i = 0; $i < $length; $i++) {
            $key .= $keys[array_rand($keys)];
        }

        return $key;
    }
    public static function random_num($length, $upCase = false) {
        $key = '';
        $keys = array_merge(range(0, 9));
        if($upCase == true){
            $keys = array_merge(range(0, 9));
        }
        for ($i = 0; $i < $length; $i++) {
            $key .= $keys[array_rand($keys)];
        }

        return $key;
    }
}