<?php
App::uses('AppModel', 'Model');
/**
 * Agency Model
 *
 */
class ZpDatTaiXiuGame extends AppModel {
    public $useDbConfig = 'casinoLog';
    public $useTable = false;
}
