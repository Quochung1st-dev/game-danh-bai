<?php
App::uses('AppModel', 'Model');
/**
 * Agency Model
 *
 */
class GameSlotResult extends AppModel {
    public $useDbConfig = 'casinoLog';
    public $useTable = 'game_slot_results';
}
