<?php
App::uses('AppModel', 'Model');
/**
 * EventCode Model
 *
 */
class AdmincpMember extends AppModel {
    public $useTable = 'admincp_member';
/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(

	);
}
