<?php
App::uses('AppModel', 'Model');
/**
 * Agency Model
 *
 */
class GameCardInfo extends AppModel {
    public $useDbConfig = 'casinoLog';
    public $useTable = 'game_card_info';
}
