<?php
App::uses('AppModel', 'Model');
/**
 * EventCode Model
 *
 */
class AdmincpGroup extends AppModel {
    public $useTable = 'admincp_group';
/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(

	);
}
