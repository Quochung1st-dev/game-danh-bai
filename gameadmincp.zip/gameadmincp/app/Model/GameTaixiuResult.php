<?php
App::uses('AppModel', 'Model');
/**
 * Agency Model
 *
 */
class GameTaixiuResult extends AppModel {
    public $useDbConfig = 'casinoLog';
    public $useTable = 'game_taixiu_results';
}
