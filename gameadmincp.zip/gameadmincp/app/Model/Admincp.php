<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/6/2017
 * Time: 3:24 PM
 */
App::uses('BlowfishPasswordHasher', 'Controller/Component/Auth');
class Admincp extends AppModel
{
    public $useTable = 'admincp_member';
    public $validate = array(
        'username' => array(
            'required' => array(
                'rule' => 'notBlank',
                'message' => 'A username is required'
            )
        ),
        'password' => array(
            'required' => array(
                'rule' => 'notBlank',
                'message' => 'A password is required'
            )
        ),
        'role' => array(
            'valid' => array(
                'rule' => array('inList', array('admin', 'author')),
                'message' => 'Please enter a valid role',
                'allowEmpty' => false
            )
        )
    );
    public function beforeSave($options = array()) {
        if (isset($this->data[$this->alias]['password'])) {
            $this->data[$this->alias]['password'] = md5($this->data[$this->alias]['password']);
        }
        return true;
    }
}