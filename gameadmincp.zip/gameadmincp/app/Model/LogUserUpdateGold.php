<?php

App::uses('AppModel', 'Model');

class LogUserUpdateGold extends AppModel {
    public $useDbConfig = 'casinoLog';
    public $useTable = 'user_update_golds';
}