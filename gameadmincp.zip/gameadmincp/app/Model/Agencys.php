<?php

class Agencys extends AppModel {

 public $useTable = 'agencies';

}
