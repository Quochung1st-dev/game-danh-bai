<?php
App::uses('AppModel', 'Model');
/**
 * UserCode Model
 *
 */
class Tkdaily extends AppModel {

/**
 * Validation rules
 *
 * @var array
 */
    public $useTable = "tkdailys";
}
