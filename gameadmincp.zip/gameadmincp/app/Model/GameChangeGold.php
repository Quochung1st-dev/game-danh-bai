<?php
App::uses('AppModel', 'Model');
/**
 * GiftCode Model
 *
 */
class GameChangeGold extends AppModel {
}
