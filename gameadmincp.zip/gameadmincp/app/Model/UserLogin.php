<?php
App::uses('AppModel', 'Model');
/**
 * Agency Model
 *
 */
class UserLogin extends AppModel {
    public $useDbConfig = 'casinoLog';
    public $useTable = 'user_logins';
}
