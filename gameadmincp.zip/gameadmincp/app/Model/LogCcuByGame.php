<?php

App::uses('AppModel', 'Model');

class LogCcuByGame extends AppModel {
    public $useDbConfig = 'casinoLog';
    public $useTable = 'kpi_metric_ccu_by_game';
}