<?php
App::uses('AppModel', 'Model');
/**
 * EventCode Model
 *
 */
class EventCode extends AppModel {

/**
 * Validation rules
 *
 * @var array
 */
	public $validate = array(

	);
}
