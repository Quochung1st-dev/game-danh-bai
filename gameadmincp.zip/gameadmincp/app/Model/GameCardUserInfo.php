<?php
App::uses('AppModel', 'Model');
/**
 * Agency Model
 *
 */
class GameCardUserInfo extends AppModel {
    public $useDbConfig = 'casinoLog';
    public $useTable = 'game_card_user_info';
}
