<?php
App::uses('AppModel', 'Model');
/**
 * Agency Model
 *
 */
class GameTaixiuUserResult extends AppModel {
    public $useDbConfig = 'casinoLog';
    public $useTable = 'game_taixiu_user_results';
}
