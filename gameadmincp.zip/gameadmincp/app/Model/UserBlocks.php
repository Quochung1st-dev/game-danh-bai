<?php

class UserBlocks extends AppModel
{
    public $useTable = 'user_blocks';
}
