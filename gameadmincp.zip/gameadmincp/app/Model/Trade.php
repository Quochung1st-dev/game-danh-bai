<?php
App::uses('AppModel', 'Model');
/**
 * Trade Model
 *
 */
class Trade extends AppModel {

	/**
 * Validation rules
 *
 * @var array
 */
	
}
