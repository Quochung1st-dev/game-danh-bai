<?php
App::uses('AppModel', 'Model');
/**
 * GiftCode Model
 *
 */
class UserChangeGold extends AppModel {
}
