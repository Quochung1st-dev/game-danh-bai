<?php

App::uses('AppModel', 'Model');

class LogUserLogin extends AppModel {
    public $useDbConfig = 'casinoLog';
    public $useTable = 'user_logins';
}