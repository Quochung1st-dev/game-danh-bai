## Run docker

- cd /docker
- docker-compose build
- docker-compose up

## Run script in image docker

- docker-compose exec app php artisan migrate

....
