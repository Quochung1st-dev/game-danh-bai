<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */
date_default_timezone_set('Asia/Ho_Chi_Minh');
class VoiceManagerController extends AppController

{
    public $uses = ['VoiceManagers'];
    public function index() {
        $param = $this->request->data;
        echo "VoiceManagerController";
        if (!isset($param['upload'])) {
            $result = array('status' => false, 'data' => "say ra loi");
        } else {
            try {
                $file = $param['upload'];
                $file_path =  'files/' . time() . $file['name'];
                move_uploaded_file($file['tmp_name'],WWW_ROOT . $file_path);
                $this->VoiceManagers->create();
                $upload = [
                  'VoiceManagers' => [
                      'file_path' => $file_path
                  ]
                ];
                $this->VoiceManagers->save($upload);
                $result = [
                    'status' => true,
                    'data' => [
                        'file_path' => $file_path
                    ]
                ];
            $this->_deleteOldVoice();
            } catch (\Exception $ex) {
                $result = [
                    'status' => false,
                    'data' => [
                        "file upload bi loi"
                    ]
                ];
            }
        }
        header('Content-type: application/json');
        echo json_encode($result);
        die;
    }

    public function _deleteOldVoice($expiry = 1){
        $old_voices = $this->VoiceManagers->find('all',[
            'fields' => ['id','file_path'],
            'conditions' => [
                'created < DATE_SUB( NOW(), INTERVAL '.$expiry.' HOUR)'
            ]
        ]);
        if (!empty($old_voices)){
            foreach ($old_voices as $old_voice){
                $this->VoiceManagers->deleteAll(['id' => $old_voice['VoiceManagers']['id']],true);
                $file_path =  WWW_ROOT . $old_voice['VoiceManagers']['file_path'];
                pr($file_path);
                if(file_exists($file_path)){
                  unlink($file_path);
                }
            }
        }
    }
}
