<?php
/**
 * Thư viện tích hợp thẻ cào maxpay.vn
 * Version 1.0
 */

date_default_timezone_set('Asia/Ho_Chi_Minh');
App::uses('OutPacket', 'Model');
App::uses('HttpSocket', 'Network/Http');
class ListCardController extends AppController
{

    public $uses = ['User', 'ListCard', 'Card'];
    private $socket;

    public function addcardall(){
        $param = $this->request->query;

        $rd = rand(1,3);
//        $rd = 3;
        if($rd == 1){
            $this->putCard($param);
        }else if($rd == 2){
            $this->putCardService($param);
        }else{
            $this->putCardEP($param);
        }
    }

    public function putCardService($param){

//        header('Access-Control-Allow-Origin: *');
//        header('Content-type: application/json');
        $param = $this->request->query;
//        http://localhost/casinoService/Listcard/putCardService?card_type=1&card_num=50000&pin=232142141332&seri=1231414332231&userID=123131&displayname=keikanvl&token=12323221

        CakeLog::write('MaxpayController',json_encode( $param));
        if (!isset($param['card_type']) ||
            !isset($param['card_num']) ||
            !isset($param['pin']) ||
            !isset($param['seri']) ||
            !isset($param['userID']) ||
            !isset($param['displayname']) ||
            !isset($param['token'])
        ) {
            $result = array(1);
            echo json_encode($result);

        } else {
            $card_type = $param["card_type"];
            $card_num = $param["card_num"];
            $pin = $param["pin"];
            $seri = $param["seri"];
            $userID = $param["userID"];
            $displayname = $param["displayname"];
            $token = $param['token'];
            $type = "Viettel";
            if ($card_type == 1) {
                $type = "Viettel";
            } else if ($card_type == 2) {
                $type = "Vinaphone";
            } else if ($card_type == 3) {
                $type = "Mobiphone";

            }
            $curDate = date("Y-m-d H:i:s");

            $data = "card_type=" . $card_type . '&card_num=' . $card_num . '&pin=' . $pin . '&seri=' . $seri . '&userID=' . $userID;

            $secret = KEY_ENCODE; //product's secret key (get value from 1Pay product detail)
//            $signature = hash_hmac("sha256", $data, $secret); // create signature to check
            $signature = $token;
            if($signature == $token){

                $url = "https://fconn.club/apiv2/card.php";
                $urlCallback = URL_CALLBACK_FCONN;
                $key = "kBdvqfDuuP0BIbK7uGQE0XUQeoSp7bWZMeA3gCMiqPwFc1cWlp";
                $uid = "109";

                $data = [
                    'uid' => $uid,
                    'key' => $key,
                    'postbackUrl' => $urlCallback,
                    'seri' => $seri,
                    'pin' => $pin,
                    'refValue' => $card_num,
                    'cardName' => $type,
                ];
        //        pr($data);
                $httpSocket = new HttpSocket();
                $response = $httpSocket->post($url, $data);
//                echo $response->message;
                CakeLog::write('MaxpayController', 'putCardService ' . json_encode($response));
                $rs = $response['body'];
                $d = json_decode($rs);
//                echo $d->message;
                $type = "VIETTEL";
                if ($card_type == 1) {
                    $type = "VIETTEL";
                } else if ($card_type == 2) {
                    $type = "VINA";
                } else if ($card_type == 3) {
                    $type = "MOBI";

                }else if ($card_type == 4) {
                    $type = "GARENA";

                }else if ($card_type == 5) {
                    $type = "ZING";

                }
                if($d->code == 200) {
                    $dt = $this->ListCard->save(array(
                        'cardid' => $d->card_id,
                        'card_type' => $type,
                        'card_num' => $card_num,
                        'pin' => $pin,
                        'seri' => $seri,
                        'status' => 0,
                        'userID' => $userID,
                        'khid' => 2,
                        'displayname' => $displayname

                    ));
//                pr($dt);
//                    $result = array("Gửi yêu cầu nạp thẻ thành công. Số serial " . $seri . ", mã thẻ " . $pin . ". Thời gian " . $curDate);
                    echo json_encode(array(0));
//                    echo json_encode($result);
                }else{
                    echo json_encode(array(1));
//                    $result = array($d->message . '. Mã seri ' .$seri.", mã thẻ ".$pin. ". Thời gian ".$curDate);
//                    echo json_encode($result);
                    $dt = $this->ListCard->save(array(
                        'cardid' => -2,
                        'card_type' => $type,
                        'card_num' => $card_num,
                        'pin' => $pin,
                        'seri' => $seri,
                        'status' => 2,
                        'userID' => $userID,
                        'khid' => 2,
                        'ngaytra' => $curDate,
                        'displayname' => $displayname

                    ));
                }
            }else{
                echo json_encode(array(2));
//                $result = array("Có lỗi xảy ra khi nạp thẻ. Số serial ".$seri.", mã thẻ ".$pin. ". Thời gian ".$curDate);
//                echo json_encode($result);
                $dt = $this->ListCard->save(array(
                    'cardid' => -1,
                    'card_type' => $type,
                    'card_num' => $card_num,
                    'pin' => $pin,
                    'seri' => $seri,
                    'status' => 2,
                    'userID' => $userID,
                    'khid' => 2,
                    'ngaytra' => $curDate,
                    'displayname' => $displayname

                ));
            }
        }

        die;
    }

    public function callbackCardService(){
        CakeLog::write('MaxpayController', 'callbackCardService ' . json_encode( $this->request));
        header('Access-Control-Allow-Origin: *');
        header('Content-type: application/json');
        $param = $this->request->query;

        $checkSokcet = false;
        //Open socket to server
        if ($this->socket == null) {
            $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        }
        if ($this->socket === false) {
            $checkSokcet = false;
        } else {
            $checkSokcet = true;
        }

        $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
        if ($result === false) {
            $checkSokcet = false;
        } else {
            $checkSokcet = true;
        }
        $curDate = date("Y-m-d H:i:s");


        if($this->request['data']['error_code'] == 0){
            $pay = $this->ListCard->find("first", [
                'conditions' => [
                    'ListCard.cardid' => $this->request['data']['card_id'],
                    'ListCard.status' => 0
                ]
            ]);

            if (count($pay) > 0) {
//                    if($pay['ListCard']['status'] != 0){
//                        echo 'Thẻ đã xử lý.';
//                        die;
//                    }

                //Lấy về số gold cần trả cho user
                $card = $this->Card->find("first", [
                    'conditions' => [
                        'Card.card' => $this->request['data']['value'],
                        'Card.type' => $pay['ListCard']['card_type'],
                    ]
                ]);
                $gold = $card['Card']['gold'];
                //Event nap the lần đầu.
//                $user_nap = $this->ListCard->find("first", [
//                    'conditions' => [
//                        'ListCard.userID' => $pay['ListCard']['userID'],
//                        'ListCard.status' => 1
//                    ]
//                ]);
//
//
//                if(count($user_nap) == 0){
//                    $gold = ceil($card['Card']['gold'] / 0.8);
//                    CakeLog::write('MaxpayController', 'callbackCardService tang 100% ' . $pay['ListCard']['userID'] . '------ '. $gold);
//                }

                if (count($card) > 0) {
                    $this->ListCard->save(array(
                        'id' => $pay['ListCard']['id'],
                        'status' => 1,
                        'ngaytra' => $curDate,

                    ));
                    $ct = "Nạp thẻ ".$pay['ListCard']['card_type']." mệnh giá ". $this->request['data']['value'] ." thành công nhận được ".$gold." KIM. Số serial ".$pay['ListCard']['seri'].", mã thẻ ".$pay['ListCard']['pin']. " . Thời gian ".$curDate;

                    $p = new OutPacket(1, PAYMENT_MAX_PAY);
                    $p->putInt(CARD_NEW);
                    $p->putInt(0);
                    $p->putString($ct);
                    $p->putString("");
                    $p->putLong($gold);
                    $p->putLong($pay['ListCard']['userID']);
                    $p->putString(php_secret_key);
                    $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                    $pckLen = strlen($packet);
                    socket_write($this->socket, $packet, $pckLen);
                    socket_close($this->socket);

                    echo 'Trả KIM cho user thành công!!';
                }else{
                    echo 'Không tìm thấy mệnh giá thẻ '.$pay['ListCard']['card_num'] . ' cho user '.$pay['ListCard']['userID'];
                }

            }
        }else{
            $pay = $this->ListCard->find("first", [
                'conditions' => [
                    'ListCard.cardid' => $this->request['data']['card_id']
                ]
            ]);
            if (count($pay) > 0) {
                $this->ListCard->save(array(
                    'id' => $pay['ListCard']['id'],
                    'status' => 2,
                    'ngaytra' => $curDate,

                ));
            }

            $ct = $this->request['data']['error_desc'] . ". Số serial ".$pay['ListCard']['seri'].", mã thẻ ".$pay['ListCard']['pin']. " . Thời gian ".$curDate;

            $p = new OutPacket(1, PAYMENT_MAX_PAY);
            $p->putInt(CARD_NEW);
            $p->putInt(0);
            $p->putString($ct);
            $p->putString("");
            $p->putLong(0);
            $p->putLong($pay['ListCard']['userID']);
            $p->putString(php_secret_key);
            $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
            $pckLen = strlen($packet);
            socket_write($this->socket, $packet, $pckLen);
            socket_close($this->socket);
        }

        die;
    }


    // Kênh thẻ 1
    public function putCard($param){
//        $param = $this->request->query;
//        http://localhost/casinoService/Listcard/putCard?card_type=1&card_num=50000&pin=232142141332&seri=1231414332231&userID=123131&displayname=keikanvl&token=12323221

        CakeLog::write('MaxpayController', 'putCard'.json_encode( $param));
        if (!isset($param['card_type']) ||
            !isset($param['card_num']) ||
            !isset($param['pin']) ||
            !isset($param['seri']) ||
            !isset($param['userID']) ||
            !isset($param['displayname']) ||
            !isset($param['token'])
        ) {
            $result = array(1);
            echo json_encode($result);

        } else {
            $card_type = $param["card_type"];
            $card_num = $param["card_num"];
            $pin = $param["pin"];
            $seri = $param["seri"];
            $userID = $param["userID"];
            $displayname = $param["displayname"];
            $token = $param['token'];
            $type = "VTT";
            if ($card_type == 1) {
                $type = "VTT";
            } else if ($card_type == 2) {
                $type = "VNP";
            } else if ($card_type == 3) {
                $type = "VMS";

            }

            $type2 = "VIETTEL";
            if ($card_type == 1) {
                $type2 = "VIETTEL";
            } else if ($card_type == 2) {
                $type2 = "VINA";
            }else if ($card_type == 3) {
                $type2 = "MOBI";

            }

            $curDate = date("Y-m-d H:i:s");

            $data = "card_type=" . $card_type . '&card_num=' . $card_num . '&pin=' . $pin . '&seri=' . $seri . '&userID=' . $userID;

            $secret = KEY_ENCODE; //product's secret key (get value from 1Pay product detail)
//            $signature = hash_hmac("sha256", $data, $secret); // create signature to check
            $signature = $token;
            if($signature == $token){
                $requestid=microtime(true);
                $requestid = str_replace(".","",$requestid);
                $post_field = [
                    'username'=>'f9160519',
                    'password'=>'WRK44cNWbpGR3HCE',
                    'cardCode'=>$pin,
                    'cardSerial'=>$seri,
                    'price'=>$card_num,
                    'issuer'=>$type,
                    'transRef'=>$requestid,
                    'accountId'=>$userID,
                    'userGame'=>$displayname,
                    'signature'=>md5($pin.$seri),
                ];
                $postinfo = json_encode($post_field);

                $URL = 'https://naptiencuoc.com/card/input';
//                $loggerLocal->info("POST : ".$postinfo);
                $ch = curl_init($URL);
                curl_setopt($ch, CURLOPT_POSTFIELDS, $postinfo);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-Type:application/json'));
                curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, 0);
                curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 0);
                curl_setopt($ch, CURLOPT_TIMEOUT, 90);
                curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, 30);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true );
                $ret = curl_exec($ch);
                curl_close($ch);
// response
//                echo $ret;
//                die;
                $dataResponse = json_decode($ret,true);
//                pr($dataResponse);
                CakeLog::write('MaxpayController',json_encode( $dataResponse));

                if($dataResponse['status'] == 100) {
                    $dt = $this->ListCard->save(array(
                        'cardid' => $requestid,
                        'card_type' => $type2,
                        'card_num' => $card_num,
                        'pin' => $pin,
                        'seri' => $seri,
                        'status' => 0,
                        'userID' => $userID,
                        'mess' => $dataResponse['description'],
                        'khid' => 1,
                        'displayname' => $displayname

                    ));
                    echo json_encode(array(0));
                }else{
                    $this->response('Mã seri ' .$seri.", mã thẻ ".$pin. ". Thời gian ".$curDate . ". Nội dung: " . $dataResponse['description'] , $userID ,0 );
                    echo json_encode(array(1));
                    $dt = $this->ListCard->save(array(
                        'cardid' => -2,
                        'card_type' => $type2,
                        'card_num' => $card_num,
                        'pin' => $pin,
                        'seri' => $seri,
                        'status' => 2,
                        'userID' => $userID,
                        'mess' => $dataResponse['description'],
                        'khid' => 1,
                        'ngaytra' => $curDate,
                        'displayname' => $displayname

                    ));
                }
            }else{
                $result = array("Có lỗi xảy ra khi nạp thẻ. Số serial ".$seri.", mã thẻ ".$pin. ". Thời gian ".$curDate);
                echo json_encode(array(2));
                $dt = $this->ListCard->save(array(
                    'cardid' => -1,
                    'card_type' => $type2,
                    'card_num' => $card_num,
                    'pin' => $pin,
                    'seri' => $seri,
                    'status' => 2,
                    'userID' => $userID,
                    'khid' => 1,
                    'ngaytra' => $curDate,
                    'displayname' => $displayname

                ));
            }
        }

        die;
    }

    public function postlbackCard(){

        header('Access-Control-Allow-Origin: *');
        header('Content-type: application/json');
        $param = $this->request->query;
        CakeLog::write('MaxpayController', 'callbackCardService ' . json_encode( $param));
        $card = $this->ListCard->find("first", [
            'conditions' => [
                'ListCard.cardid' => $param['request_id'],
                'ListCard.status' => 0
            ]
        ]);

        CakeLog::write('MaxpayController', 'callbackCardService ' . 'thong tin the '.json_encode( $card));
        if(count($card) > 0) {
            if ($param['status'] == 1) {

                $cd = $this->Card->find("first", [
                    'conditions' => [
                        'Card.card' => $param['amount_real'],
                        'Card.type' => $card['ListCard']['card_type'],
                    ]
                ]);
                $rs = ["status" => 1, "description" => "Thanh cong"];
                $ct = "Nạp thẻ thành công. Số serial " . $card['ListCard']['seri'] . ", mã thẻ " . $card['ListCard']['pin'] . ". Nhận được " . $param['amount_real'];
                $this->response($ct, $card['ListCard']['userID'], $cd['Card']['gold']);
                $dt = $this->ListCard->save(array(
                    'id' => $card['ListCard']['id'],
                    'mess' => $param['status'],
                    'read_value' => $param['amount_real'],
                    'ngaytra' => date("Y-m-d H:i:s"),
                    'status' => 1,

                ));

            } else {
                $rs = ["status" => -2, "description" => ""];
                $ct = "Nạp thẻ không thành công. Số serial " . $card['ListCard']['seri'] . ", mã thẻ " . $card['ListCard']['pin'] . ".";
                $this->response($ct, $card['ListCard']['userID'], 0);
                $dt = $this->ListCard->save(array(
                    'id' => $card['ListCard']['id'],
                    'mess' => $param['status'],
                    'read_value' => $param['amount_real'],
                    'ngaytra' => date("Y-m-d H:i:s"),
                    'status' => 2,

                ));
            }
        }
        echo json_encode($rs);
        die;
    }

    // Kênh thẻ 2
    function endcodeData($requestId, $nccCode, $gameCode, $account, $cardNumber, $serialNumber, $cardValue, $provider, $type, $accessKey)
    {
        $secretKey = "7kcanf952yrd7d0ngytogn73";
        $plainText = $requestId . '|' . $nccCode . '|' . $gameCode . '|' . $account . '|' . $cardNumber . '|' . $serialNumber . '|' . $cardValue . '|' . $provider . '|' . $type . '|' . $accessKey;
        $signature = hash_hmac('sha256', $plainText, $secretKey, true);
        $signature = base64_encode($signature);

        return base64_encode($plainText . '|' . $signature);
    }

    function decodeData($textEncode = null)
    {
        $textDecode = base64_decode($textEncode);
        return $dataDecode = explode('|', $textDecode);
        array_pop($dataDecode);

        return implode('|', $dataDecode);

    }
    public function putCardEP($param){

//        http://localhost/casinoService/Listcard/putCard?card_type=1&card_num=50000&pin=232142141332&seri=1231414332231&userID=123131&displayname=keikanvl&token=12323221

        CakeLog::write('MaxpayController',json_encode( $param));
        if (!isset($param['card_type']) ||
            !isset($param['card_num']) ||
            !isset($param['pin']) ||
            !isset($param['seri']) ||
            !isset($param['userID']) ||
            !isset($param['displayname']) ||
            !isset($param['token'])
        ) {
            $result = array(1);
            echo json_encode($result);

        } else {
            $card_type = $param["card_type"];
            $card_num = $param["card_num"];
            $pin = $param["pin"];
            $seri = $param["seri"];
            $userID = $param["userID"];
            $displayname = $param["displayname"];
            $token = $param['token'];
            $type = "VTT";
            if ($card_type == 1) {
                $type = "VTT";
            } else if ($card_type == 2) {
                $type = "VNP";
            } else if ($card_type == 3) {
                $type = "VMS";

            }

            $type2 = "VIETTEL";
            if ($card_type == 1) {
                $type2 = "VIETTEL";
            } else if ($card_type == 2) {
                $type2 = "VINA";
            } else if ($card_type == 3) {
                $type2 = "MOBI";

            }

            $curDate = date("Y-m-d H:i:s");

            $data = "card_type=" . $card_type . '&card_num=' . $card_num . '&pin=' . $pin . '&seri=' . $seri . '&userID=' . $userID;

            $secret = KEY_ENCODE; //product's secret key (get value from 1Pay product detail)
//            $signature = hash_hmac("sha256", $data, $secret); // create signature to check
            $signature = $token;
            if($signature == $token){
                $requestid=microtime(true);
                $requestid = str_replace(".","",$requestid);
                $nccCode = '5c94b490c59cd27b856d78b7';
                $gameCode = '5c94b490c59cd27b856d78b7';
                $type1 = '1';
                $accessKey = 'gbsu1tmvl0397lo5j6lpps42';
                $url = "https://chutich-api.easypay.live/api/CardCallBack/CreateCardRequest/?data=";


                $strEncode = $this->endcodeData($requestid, $nccCode, $gameCode, $userID, $pin, $seri, $card_num, $type, $type1, $accessKey);
                $url .= $strEncode;
                $httpSocket = new HttpSocket();
                $response = $httpSocket->get($url);
                $rs = json_decode($response);
//                pr($rs);
                CakeLog::write('MaxpayController', 'putCardEP-----' .( $response));
                if($rs->ErrorCode == "00") {
                    $dt = $this->ListCard->save(array(
                        'cardid' => $requestid,
                        'card_type' => $type2,
                        'card_num' => $card_num,
                        'pin' => $pin,
                        'seri' => $seri,
                        'status' => 0,
                        'khid' => 3,
                        'userID' => $userID,
                        'displayname' => $displayname

                    ));
//                pr($dt);
//                    $result = array("Gửi yêu cầu nạp thẻ thành công. Số serial " . $seri . ", mã thẻ " . $pin . ". Thời gian " . $curDate);
//                    echo json_encode($result);
                    echo json_encode(array(0));
                }else{
                    $result = array("" . '. Mã seri ' .$seri.", mã thẻ ".$pin. ". Thời gian ".$curDate);
                    echo json_encode(array(1));
                    $dt = $this->ListCard->save(array(
                        'cardid' => -2,
                        'card_type' => $type2,
                        'card_num' => $card_num,
                        'pin' => $pin,
                        'seri' => $seri,
                        'status' => 2,
                        'userID' => $userID,
                        'khid' => 3,
                        'ngaytra' => date("Y-m-d H:i:s"),
                        'displayname' => $displayname

                    ));
                }

            }else{
//                $result = array("Có lỗi xảy ra khi nạp thẻ. Số serial ".$seri.", mã thẻ ".$pin. ". Thời gian ".$curDate);
                echo json_encode(array(2));
                $dt = $this->ListCard->save(array(
                    'cardid' => -1,
                    'card_type' => $type2,
                    'card_num' => $card_num,
                    'pin' => $pin,
                    'seri' => $seri,
                    'status' => 2,
                    'userID' => $userID,
                    'khid' => 3,
                    'ngaytra' => date("Y-m-d H:i:s"),
                    'displayname' => $displayname

                ));
            }

        }

        die;
    }

    public function postlbackCardEP(){
        CakeLog::write('MaxpayController', 'callbackCardService ' . json_encode( $this->request));
        header('Access-Control-Allow-Origin: *');
        header('Content-type: application/json');
        $param = $this->request->query;
        CakeLog::write('MaxpayController','postlbackCardEP'.$param['data']);
        $data = $this->decodeData($param['data']);
        $card = $this->ListCard->find("first", [
            'conditions' => [
                'ListCard.cardid' => $data[0],
                'ListCard.status' => 0
            ]
        ]);
        CakeLog::write('MaxpayController', 'callbackCardService ' . 'thong tin the '.json_encode( $card) . $data[0]);
        if(count($card) > 0) {
            if ($data[3] == '00') {

                $cd = $this->Card->find("first", [
                    'conditions' => [
                        'Card.card' => $data[2],
                        'Card.type' => $card['ListCard']['card_type'],
                    ]
                ]);

                $rs = ["status" => 1, "description" => "Thanh cong"];
                $ct = "Nạp thẻ thành công. Số serial " . $card['ListCard']['seri'] . ", mã thẻ " . $card['ListCard']['pin'] . ". Nhận được " . $data[2];
                $this->response($ct, $card['ListCard']['userID'], $cd['Card']['gold']);
                $dt = $this->ListCard->save(array(
                    'id' => $card['ListCard']['id'],
                    'mess' => $data[3],
                    'read_value' => $data[2],
                    'ngaytra' => date("Y-m-d H:i:s"),
                    'status' => 1,

                ));

            } else {
                $rs = ["status" => -2, "description" => ""];
                $ct = "Nạp thẻ không thành công. Số serial " . $card['ListCard']['seri'] . ", mã thẻ " . $card['ListCard']['pin'] . ".";
                $this->response($ct, $card['ListCard']['userID'], 0);
                $dt = $this->ListCard->save(array(
                    'id' => $card['ListCard']['id'],
                    'mess' => $data[3],
                    'read_value' => $data[2],
                    'ngaytra' => date("Y-m-d H:i:s"),
                    'status' => 2,

                ));
                echo "00|Thanh cong";

            }
        }

        die;
    }


    public function getCardDetails(){
        $url = "https://fconn.club/apiv2/card.php";
        $key = "Bv2KtO1KqfkOvyny4gTCt7JW6lHNPGJ9ipkkLyvlg2n8XOIYeA";
        $uid = "091";
        $cardid = "2524805";
        CakeLog::write('MaxpayController', 'getCardDetails ');
        $data = [
            'uid' => $uid,
            'key' => $key,
            'cardid' => $cardid,
        ];

        $httpSocket = new HttpSocket();
        $response = $httpSocket->post($url, $data);

        pr($response);
        die;
    }


    public function addcardnew(){
        die;
        header('Access-Control-Allow-Origin: *');
        header('Content-type: application/json');
        $param = $this->request->query;

        CakeLog::write('MaxpayController',json_encode( $param));
        $merchant_txn_id = Util::random_string(12) . time();
        if (!isset($param['card_type']) ||
            !isset($param['card_num']) ||
            !isset($param['pin']) ||
            !isset($param['seri']) ||
            !isset($param['userID']) ||
            !isset($param['displayname']) ||
            !isset($param['token'])
        ) {
            $result = array(1);
            echo json_encode($result);

        } else {
            $card_type = $param["card_type"];
            $card_num = $param["card_num"];
            $pin = $param["pin"];
            $seri = $param["seri"];
            $userID = $param["userID"];
            $displayname = $param["displayname"];
            $token = $param['token'];
            $type = "VIETTEL";
            if ($card_type == 1) {
                $type = "VIETTEL";
            } else if ($card_type == 2) {
                $type = "VINA";
            } else if ($card_type == 3) {
                $type = "MOBI";

            }else if ($card_type == 4) {
                $type = "GARENA";

            }else if ($card_type == 5) {
                $type = "ZING";

            }
            $curDate = date("Y-m-d H:i:s");

            $data = "card_type=" . $card_type . '&card_num=' . $card_num . '&pin=' . $pin . '&seri=' . $seri . '&userID=' . $userID;

            $secret = KEY_ENCODE; //product's secret key (get value from 1Pay product detail)
//            $signature = hash_hmac("sha256", $data, $secret); // create signature to check
            $signature = $token;
            if($signature == $token){

                $rs = $this->ListCard->find("first", [
                    'conditions' => [
                        'ListCard.pin' => $pin,
                        'ListCard.seri' => $seri,
                    ]
                ]);

//                $rs1 = $this->ListCard->find("first", [
//                    'conditions' => [
//                        'ListCard.seri' => $seri,
//                    ]
//                ]);
                if(count($rs) > 0){
                    $result = array("Số serial hoặc mã thẻ đã được sử dụng. Số serial ".$seri.", mã thẻ ".$pin. ". Thời gian ".$curDate);
                    echo json_encode($result);
                    die;
                }

                $dt = $this->ListCard->save(array(
                    'card_type' => $type,
                    'card_num' => $card_num,
                    'pin' => $pin,
                    'seri' => $seri,
                    'status' => 0,
                    'userID' => $userID,
                    'displayname' => $displayname

                ));
//                pr($dt);
                $result = array("Gửi yêu cầu nạp thẻ thành công. Số serial ".$seri.", mã thẻ ".$pin. ". Thời gian ".$curDate);
                echo json_encode($result);
            }else{
                $result = array("Có lỗi xảy ra khi nạp thẻ. Số serial ".$seri.", mã thẻ ".$pin. ". Thời gian ".$curDate);
                echo json_encode($result);
            }
        }
        die;
    }

    public function response($ct, $userID, $gold)
    {


        $checkSokcet = false;
        //Open socket to server
        if ($this->socket == null) {
            $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        }
        if ($this->socket === false) {
            $checkSokcet = false;
        } else {
            $checkSokcet = true;
        }

        $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
        if ($result === false) {
            $checkSokcet = false;
        } else {
            $checkSokcet = true;
        }
        $p = new OutPacket(1, PAYMENT_MAX_PAY);
        $p->putInt(CARD_NEW);
        $p->putInt(0);
        $p->putString($ct);
        $p->putString("");
        $p->putLong($gold);
        $p->putLong($userID);
        $p->putString(php_secret_key);
        $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
        $pckLen = strlen($packet);
        socket_write($this->socket, $packet, $pckLen);
        socket_close($this->socket);

    }

}