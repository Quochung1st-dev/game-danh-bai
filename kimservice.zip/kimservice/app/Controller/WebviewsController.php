<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */

class WebviewsController extends AppController
{
    public $uses = ['index', 'listTopPlayers'];

    function  index(){

    }
    function listTopPlayers(){
        $this->layout="ajax";
        $this->loadModel(ZpResultGameUser);
        $today = date('Y-m-d');
        $conditions = ['userid >' => 0];
        if (false){
            $conditions['date_create'] = $today;
        }
        $this->paginate = array(
            'paramType' => 'querystring',
            'recursive' => -1,
            'fields' => [
                'ZpResultGameUser.userid',
                'ZpResultGameUser.username',
                'ZpResultGameUser.level',
                'SUM(gold_change) as totalGold',
                'DATE(create_date) as date_create'
            ],
            'conditions' => $conditions,
            'group' => [
                'userid',
                'date_create'
            ],
            'order' => 'date_create DESC, totalGold DESC',
            'limit' => 10
        );

        $listUser = $this->paginate('ZpResultGameUser');
        pr($listUser);die();
        $this->set([
            'zpTopGoldUserDay' => $listUser
        ]);
    }
}
