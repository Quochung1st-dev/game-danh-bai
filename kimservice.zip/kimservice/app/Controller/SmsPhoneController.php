<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */
date_default_timezone_set('Asia/Ho_Chi_Minh');
App::uses('OutPacket', 'Model');


class SmsPhoneController extends AppController
{
    public $uses = ['User', 'SmsPhone'];


    public function sendSMSPhone(){
        for ($i = 0; $i< 5; $i++){
            $code = $sid = Util::random_num(6);
            $this->requestsms($code, "01649651932", 1);
        }
        die;
    }
    private function requestsms($code, $phone, $event){
        $Content="Ma OTP cua ban la: ".$code.", thoi han su dung 5 phut";

        $SendContent=urlencode($Content);
        $data="http://rest.esms.vn/MainService.svc/json/SendMultipleMessage_V4_get?Phone=".$phone."&ApiKey=".APIKey."&SecretKey=".SecretKey."&Content=".$SendContent."&SmsType=2&Brandname=QCAO_ONLINE";

        $curl = curl_init($data);
        curl_setopt($curl, CURLOPT_FAILONERROR, true);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($curl);
        CakeLog::write('UserController', "requestsms result ".$result);
        $obj = json_decode($result,true);
        $curDate = date("Y-m-d H:i:s");

        if($obj['CodeResult']==100)
        {
            $curDate = date("Y-m-d H:i:s");
            $this->SmsPhone->create();
            $this->SmsPhone->save(array(
                'code' => $code,
                'phone' => $phone,
                'content' => $Content,
                'created' => $curDate,
                'event' => $event
            ));

        }else{
            $this->SmsPhone->create();
            $this->SmsPhone->save(array(
                'code' => $code,
                'phone' => $phone,
                'content' => "ERROR!!!",
                'created' => $curDate,
                'event' => $event
            ));
        }


    }


}
