<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */
date_default_timezone_set('Asia/Ho_Chi_Minh');
App::uses('Captcha', 'Model');

class CaptchaController extends AppController
{
    public $uses = ['Captchas'];
    public function genCaptcha(){
        header('Content-type: application/json');
        header("Access-Control-Allow-Origin: *");
        header("Access-Control-Allow-Headers: Origin, X-Requested-With, Content-Type, Accept");
        $config = array();
        $captcha = new Captcha($config);
        $captcha->build();
        $requestid = Util::random_string(32);
        $code = $captcha->getCode();
        $rs = array(md5($captcha->getCode().KEY_ENCODE),$captcha->base64(), $requestid);
//        echo "<img src='data:image/jpeg;base64,".$captcha->base64()."' />";
        $ip = $this->requestAction(['controller' => 'GameManager', 'action' => 'getRealIpAddr']);

        $this->Captchas->save(array(
            'requestid' => $requestid,
            'ipaddress' => $ip,
            'code' => $code,
            'verify' => md5($captcha->getCode().KEY_ENCODE),
            'status' => 0,
            'created' => date("Y-m-d H:i:s")
        ));

        echo json_encode($rs);
        die;
    }

    public static function checkCaptcha($sell, $captcha, $verify, $requestid){

        //check captcha
        if (md5($captcha . KEY_ENCODE) != $verify) {
            return 1;
        }

        $rs = $sell->Captchas->find("first", [
            'conditions' => [
                'requestid' => $requestid,
                'verify' => $verify,
                'status' => 0,
            ]
        ]);

        if(count($rs) > 0){
            $sell->Captchas->save(array(
                'id' => $rs['Captchas']['id'],
                'status' => 1,
            ));
            return 0;
        }
        return 2;
    }

    function b64img( $str, $fs=10, $w=250, $h=200, $b=array( 'r'=>255, 'g'=>255, 'b'=>255 ), $t=array('r'=>0, 'g'=>0, 'b'=>0) ){
        $tmp=tempnam( sys_get_temp_dir(), 'img' );

        $image = imagecreate( $w, $h );
        $bck = imagecolorallocate( $image, $b['r'], $b['g'], $b['b'] );
        $txt = imagecolorallocate( $image, $t['r'], $t['g'], $t['b'] );

        imagestring( $image, $fs, 0, 0, $str, $txt );
        imagepng( $image, $tmp );
        imagedestroy( $image );

        $data=base64_encode( file_get_contents( $tmp ) );
        @unlink( $tmp );
        return $data;
    }
}
