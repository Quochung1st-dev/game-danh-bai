<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 6/27/2017
 * Time: 5:12 PM
 */
App::import('Vendor', '1pay_topup/Crypt/RSA');
App::import('Vendor', '1pay_topup/Math/BigInteger');
App::import('Vendor', 'topupepay/services');
date_default_timezone_set('Asia/Ho_Chi_Minh');
App::uses('OutPacket', 'Model');
App::uses('Security', 'Utility');
class TopupController extends AppController
{
    public $uses = ['User', 'DataCard', 'PaymentTopup', 'UserBlock'];

    private $TOPUP_SUCCESS = 7;
    private $TOPUP_REQUEST_ALREADY = 8;
    private $TOPUP_REQUEST_LIMIT = 9;
    private $TOPUP_REQUEST_REFUSE = 10;

    private $TOPUP_STATUS_PROCESSING_OK = 100;
    private $TOPUP_STATUS_PROCESSING = 1;
    private $TOPUP_STATUS_PROCESSED = 2;
    private $TOPUP_STATUS_ERROR = 3;


    private $DT_SUCCESS = 1;
    private $DT_ERROR_RETURN_MONEY = 21;
    private $DT_ERROR_NOT_RETURN_MONEY = 22;
    private $DT_ERROR_PROVIDER = 23;
    private $DT_ERROR_USER_CHEAT = 24;
    private $DT_ERROR_UNDEFINE = 25;
    private $DT_ERROR_SV_MAINTAIN = 26;

    private $SEND_MAIL_FOR_USER = 17;
    private $SET_GOLD_FOR_USER = 18;

    private $socket;

    public function requesttopupnew()
    {
        header('Content-type: application/json');
        $param = $this->request->query;
        CakeLog::write('TopupController', json_encode($param));
        $arr = array($this->TOPUP_SUCCESS, '');

        $curDate = date("Y-m-d H:i:s");
        if (!isset($param['price']) ||
            !isset($param['userID']) ||
            !isset($param['type'])
        ) {
            $kq = array("code" => 1, "mess" => "Du lieu sai", "data" => []);
            echo json_encode($kq);
            die;
        } else {

            $type = $param['type'];
            $dt = explode("_", $type);
            $t = "VIETTEL";
            if ($dt[0] == "VT") {
                $t = "VIETTEL";
            } else if ($dt[0] == "VN") {
                $t = "VINAPHONE";
            } else if ($dt[0] == "MB") {
                $t = "MOBIPHONE";
            }

            $rs = $this->DataCard->find("first",[
                'conditions' => [
                    'status' => 0,
                    'card_num' => $param['price'],
                    'type' => $t
                ]
            ]);
            if(count($rs) == 0){
                $kq = array("code" => 1, "mess" => "Kho hết thẻ, vui lòng giao dịch sau ít phút", "data" => []);
                echo json_encode($kq);
                die;
            }else{
                $this->DataCard->save(array(
                    'id' => $rs['DataCard']['id'],
                    'status' => 1,
                    'displayname' => $param['userID'],
                    'created' => $curDate,
                ));
                $kq = array("code" => 0, "mess" => "Bạn đã đổi thẻ thành công", "data" => ["seri" => $rs['DataCard']['seri'],"pin" => $rs['DataCard']['pin'],"card_num" => $rs['DataCard']['card_num'],"type" => $rs['DataCard']['type']]);
                echo json_encode($kq);
                die;
            }


        }
        die;
    }


    public function requesttopup()
    {
//        header('Content-type: application/json');
        $param = $this->request->query;
        CakeLog::write('TopupController', json_encode($param));

        $date = new DateTime();
        $pID =  $date->getTimestamp()%100000000;
        $curDate = date("Y-m-d H:i:s");
        if (!isset($param['price']) ||
            !isset($param['userID']) ||
            !isset($param['type'])
        ) {
            $kq = array("code" => 1, "mess" => "Du lieu sai", "data" => []);
            echo json_encode($kq);
            die;
        } else {

            $type = $param['type'];
            $dt = explode("_", $type);
            $t = "VIETTEL";
            if ($dt[0] == "VT") {
                $t = "VTT";
            } else if ($dt[0] == "VN") {
                $t = "VNP";
            } else if ($dt[0] == "MB") {
                $t = "VMS";
            }

            $rsCheckBlock = $this->UserBlock->find("first",[ 'conditions' => [
                'UserBlock.user_id' => $param["userID"]
            ]]);
            if(count($rsCheckBlock) > 0){
                $kq = array("code" => 1, "mess" => "Bạn đổi thẻ không thành công.", "data" => []);
                echo json_encode($kq);
                die;
            }

            $SECKEY = TOPUP_API_PASS;
            $data = ['function' => 'BuyCardCode', 'telco'=> $t, 'amount' => $param['price'], 'quantity' => '1', 'partner_rid'=> $pID];
            $data = json_encode($data);
            $data = $this->Encrypt ($data, $SECKEY);
            $data = urlencode($data);

            $data = file_get_contents( "http://gw.santhecao.com/api/user/sync?partner=".TOPUP_API_CODE."&info=" . $data);
            $data = $this->Decrypt ($data, $SECKEY);

//            $data = '{"status":1,"desc":"Th\u00e0nh c\u00f4ng","trans_id":6815818,"response_status":1,"cards":[{"code":"011353922234360","serial":"10001810636051","expired_date":1574220206,"price":"50000","type":"VNP","telco":"VNP"}]}';
//            $data = json_decode($data, true);

            $checkSokcet = false;
            //Open socket to server
            if ($this->socket == null) {
                $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
            }
            if ($this->socket === false) {
                $checkSokcet = false;
            } else {
                $checkSokcet = true;
            }

            $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
            if ($result === false) {
                $checkSokcet = false;
            } else {
                $checkSokcet = true;
            }

            if($data['status'] == 1 && $data['response_status'] == 1){
                $card = $data['cards'][0]['type'].'|'.$data['cards'][0]['price'].'|'.$data['cards'][0]['code'].'|'.$data['cards'][0]['serial'].'|'.$data['cards'][0]['expired_date'];
                $this->PaymentTopup->save(array(
                    'status' => $data['status'],
                    'userid' => $param['userID'],
                    'transactionid' => $pID,
                    'card_des' => $card,
                    'des' => $data['desc'],
                    'created' => $curDate,
                ));

                $p = new OutPacket(1, GAME_EXTENSION_RUT_THUONG_KQ);
                $p->putInt($this->DT_SUCCESS);//Loai the card thanh cong
                $p->putInt($param['userID']);
                $p->putString($type);
                $p->putString($card);
                $p->putString(php_secret_key);
                CakeLog::write('MaxpayController', 'Topup OutPacket '.json_encode( $p));

                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);

                $kq = array("code" => 0, "mess" => "Bạn đã đổi thẻ thành công", "data" => []);
                echo json_encode($kq);
                die;
            }else{
                $this->PaymentTopup->save(array(
                    'status' => $data['status'],
                    'userid' => $param['userID'],
                    'transactionid' => $pID,
                    'card_des' => "",
                    'des' => $data['desc'] != null ?  $data['desc'] : "",
                    'created' => $curDate,
                ));
                $p = new OutPacket(1, GAME_EXTENSION_RUT_THUONG_KQ);
                $p->putInt($this->DT_ERROR_PROVIDER);//Loai the card that bai
                $p->putInt($param['userID']);
                $p->putString($type);
                $p->putString("");
                $p->putString(php_secret_key);
                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);

                $kq = array("code" => 1, "mess" => "Kho hết thẻ, vui lòng giao dịch sau ít phút", "data" => []);
                echo json_encode($kq);
                die;
            }


        }
        die;
    }

    function Encrypt($data, $secret) {
        //Generate a key from a hash
        $key = md5(utf8_encode($secret), true);

        //Take first 8 bytes of $key and append them to the end of $key.
        $key .= substr($key, 0, 8);

        //Pad for PKCS7
        $blockSize = mcrypt_get_block_size('tripledes', 'ecb');
        $len = strlen($data);
        $pad = $blockSize - ($len % $blockSize);
        $data .= str_repeat(chr($pad), $pad);

        //Encrypt data
        $encData = mcrypt_encrypt('tripledes', $key, $data, 'ecb');

        return base64_encode($encData);
    }

    function Decrypt($data, $secret)
    {

        //Generate a key from a hash
        $key = md5(utf8_encode($secret), true);

        //Take first 8 bytes of $key and append them to the end of $key.
        $key .= substr($key, 0, 8);

        $data = base64_decode($data);

        $data = mcrypt_decrypt('tripledes', $key, $data, 'ecb');

        $block = mcrypt_get_block_size('tripledes', 'ecb');
        $len = strlen($data);
        $pad = ord($data[$len - 1]);

        return substr($data, 0, strlen($data) - $pad);

    }

    public function requesttopup1()
    {
        header('Content-type: application/json');
        $param = $this->request->query;
        CakeLog::write('TopupController', json_encode($param));
        $arr = array($this->TOPUP_SUCCESS, '');

        $curDate = date("Y-m-d H:i:s");
        if (!isset($param['price']) ||
            !isset($param['userID']) ||
            !isset($param['type'])
        ) {
            $arr = array($this->TOPUP_STATUS_ERROR, '');
        } else {
            $request = $this->UserTopup->find("first", [
                'conditions' => [
                    'UserTopup.userid' => $param['userID'],
                    'UserTopup.status' => $this->TOPUP_STATUS_PROCESSING,
                ]
            ]);
            if (count($request) > 0) {
                if ($request['UserTopup']['status'] == $this->TOPUP_STATUS_PROCESSING) {
                    $arr = array($this->TOPUP_REQUEST_ALREADY, '');
                }else {
                    $this->UserTopup->save(array(
                        'id' => $request['UserTopup']['id'],
                        'amount' => $param['price'],
                        'card_type' => $param['type'],
                        'status' => $this->TOPUP_STATUS_PROCESSING,
//                        'modified' => date("Y-m-d H:i:s"),
                        'created' => $curDate,
                    ));
                }
            } else {
                $this->UserTopup->save(array(
                    'userid' => $param['userID'],
                    'amount' => $param['price'],
                    'card_type' => $param['type'],
                    'status' => $this->TOPUP_STATUS_PROCESSING,
//                    'date_request' => $curDate,
//                    'modified' => date("Y-m-d H:i:s"),
                    'created' => $curDate,


                ));
            }
        }
        echo json_encode($arr);
        die;
    }

    public function event(){
        header('Content-type: application/json');
        $param = $this->request->query;
        CakeLog::write('TopupController', "event --- ".json_encode($param));
        if (!isset($param['userid']) ||
            !isset($param['service']) ||
            !isset($param['gold']) ||
            !isset($param['token'])
        ) {

        } else {
            if ($param['service'] == "sendevent") {

                $d = Security::hash($param['service']."+".$param['userid']."+".$param['gold'].'+'. KEY_ENCODE ,"sha256");
//                echo $d;
                if($d == $param['token']){
                    echo $param['userid'];
                    $checkSokcet = false;
                    //Open socket to server
                    if ($this->socket == null) {
                        $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    }
                    if ($this->socket === false) {
                        $checkSokcet = false;
                    } else {
                        $checkSokcet = true;
                    }

                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                    if ($result === false) {
                        $checkSokcet = false;
                    } else {
                        $checkSokcet = true;
                    }
                    $p = new OutPacket(1, GAME_EXTENSION_RUT_THUONG_KQ);
                    $p->putInt(5);//Loáº¡i tháº» card
                    $p->putInt($param['userid']);
                    $p->putString($param['gold']);
                    $p->putString("");
                    $p->putString(php_secret_key);
                    $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                    $pckLen = strlen($packet);
                    socket_write($this->socket, $packet, $pckLen);
                    socket_close($this->socket);


                    die;
                }
            }

        }
        echo 0;
        die;

    }

}