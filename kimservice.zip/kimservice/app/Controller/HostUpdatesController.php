<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */
date_default_timezone_set('Asia/Ho_Chi_Minh');
App::import('Vendor', 'autoload');
use GeoIp2\Database\Reader;

class HostUpdatesController extends AppController

{

    public $uses = ['HostUpdates'];

    public function getHostUpdate(){
        header('Access-Control-Allow-Origin: *');
        $param = $this->request->query;

        $result = [
            'status' => false,
            'data' => [
                'is_force_update' => false,
                'url' => null
            ]
        ];
        if (!isset($param['game']) ||
            !isset($param['version_code']) ||
            !isset($param['store_type'])
        ) {
            $result = array('status' => false, 'data' => "Thieu param");
        } else {
            $check_version = $this->HostUpdates->find('first',[
                'fields' => ['version_code'],
                'conditions' => [
                    'version_code > ' => $param['version_code'],
                    'game' => $param['game'],
                    'store_type' => $param['store_type'],
                    'force_update' => true,
                ],
                'order' => [ 'version_code' => 'DESC']
            ]);
//            pr($check_version);

            if ($check_version){
                $get_url  = $this->HostUpdates->find('first',[
                    'fields' => ['version_code','url','review'],
                    'conditions' => [
                        'version_code > ' => $param['version_code'],
                        'game' => $param['game'],
                        'store_type' => $param['store_type'],
                    ],
                    'order' => [ 'version_code' => 'DESC']
                ]);
            }
            $get_url1  = $this->HostUpdates->find('first',[
                'fields' => ['version_code','url','review'],
                'conditions' => [
                    'version_code' => $param['version_code'],
                    'game' => $param['game'],
                    'store_type' => $param['store_type'],
                ],
                'order' => [ 'version_code' => 'DESC']
            ]);
//            pr($get_url1);
            $temp = 0;
            if(count($get_url1) > 0){
                $temp = $get_url1['HostUpdates']['review'];
            }
            $result = [
                'status' => true,
                'data' => [
                    'is_force_update' => $check_version ? true : false,
                    'url' => isset($get_url) ? $get_url['HostUpdates']['url'] : null,
                    'isreview' => isset($get_url1) && $temp == 1 ? true : false
                ]
            ];
//            $location = $this->requestAction(['controller' => 'GameManager', 'action' => 'getLocation']);
////            echo $location;
//            if($location == "VN") {
//                $result = [
//                    'status' => true,
//                    'data' => [
//                        'is_force_update' => $check_version ? true : false,
//                        'url' => isset($get_url) ? $get_url['HostUpdates']['url'] : null,
//                        'isreview' => isset($get_url1) && $get_url1['HostUpdates']['review'] == 1 ? true : false
//                    ]
//                ];
//            }else{
//                $result = [
//                    'status' => true,
//                    'data' => [
//                        'is_force_update' => $check_version ? true : false,
//                        'url' => isset($get_url) ? $get_url['HostUpdates']['url'] : null,
//                        'isreview' => true
//                    ]
//                ];
//            }
        }
        header('Content-type: application/json');
        echo json_encode($result);
        die;
    }
    public function getHostUpdate1(){
        $reader = new Reader(APP.'/webroot/data/GeoIP2-City.mmdb');

// Replace "city" with the appropriate method for your database, e.g.,
// "country".
        $ip = $this->requestAction(['controller' => 'GameManager', 'action' => 'getRealIpAddr']);
        $ip = "123.16.64.140";
        $record = $reader->city($ip);

        print($record->country->isoCode . "\n"); // 'US'
        print($record->country->name . "\n"); // 'United States'
        print($record->country->names['zh-CN'] . "\n"); // '美国'

        print($record->mostSpecificSubdivision->name . "\n"); // 'Minnesota'
        print($record->mostSpecificSubdivision->isoCode . "\n"); // 'MN'

        print($record->city->name . "\n"); // 'Minneapolis'

        print($record->postal->code . "\n"); // '55455'

        print($record->location->latitude . "\n"); // 44.9733
        print($record->location->longitude . "\n"); // -93.2323
        die;
    }
}