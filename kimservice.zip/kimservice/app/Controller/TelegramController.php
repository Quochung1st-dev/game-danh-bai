<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */
date_default_timezone_set('Asia/Ho_Chi_Minh');
App::uses('OutPacket', 'Model');


class TelegramController extends AppController
{

    public $uses = ['User', 'UserVerifiled', 'Agency'];

    //TODO telegram
//    private $token = "";
    private $website = "https://api.telegram.org/bot" . "";

    public function index(){

        $updates = file_get_contents("php://input");
        $updates = json_decode($updates, TRUE);
        CakeLog::write('UserController', 'TelegramController ---- 1 '.json_encode($updates));

        $text = $updates["message"]["text"];
        $chatID = $updates["message"]["chat"]["id"];
        $phone_number = $updates["message"]["contact"]["phone_number"];

        if ($text == "/start") {
            $this->replyStart($chatID);
        }
        else if (strtolower($text) == "otp") {
            $this->replyOTP($chatID);
        }
        else {
            if (isset($phone_number) ) {
                $this->replyTakePhoneNumber($chatID, $phone_number);
            }
            else {
//                $this->sendMessage($chatID, $text);
            }
        }
        die;
    }

    function sendMessage($cid, $message) {
        $url = $this->website."/sendMessage?chat_id=".$cid."&text=".urlencode($message);
        file_get_contents($url);
//        die;
    }

    function replyStart($cid) {
        $message = "Đây là lần đầu tiên bạn sử dụng KimVipAutoBot. Vui lòng ấn CHIA SẺ SỐ ĐIỆN THOẠI để sử dụng hệ thống.";
        $keyboard = [
            'keyboard' => [
                [['text' => 'CHIA SẺ SỐ ĐIỆN THOẠI',
                    'request_contact' => true]]
            ],
            'resize_keyboard' => true,
            'one_time_keyboard' => false
        ];
        $reply = json_encode($keyboard);

        $url = $this->website."/sendMessage?chat_id=".$cid."&text=".urlencode($message)."&reply_markup=".urlencode($reply);
        file_get_contents($url);
//        die;
    }

    function replyOTP($cid) {
        $user = $this->User->find("first",[
            'conditions' => [
                'cid' => $cid,
            ]
        ]);

        if(count($user) > 0 ) {
            $rs1 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $user['User']['id'],
                    'UserVerifiled.status' => 1,

                ]
            ]);
            if(count($rs1) > 0 ) {
                $curDate = date("Y-m-d H:i:s");
                $code = $sid = Util::random_num(6);
                $this->UserVerifiled->save(array(
                    'id' => $rs1['UserVerifiled']['id'],
                    'created' => $curDate,
                    'code' => $code));
                $message = "Mã OTP của bạn là " . $code . ". Thời gian sử dụng 5 phút.";
            }else{
                $message = "Bạn cần xác thực tài khoản để dùng chức năng này!!! Vui lòng liên hệ trên fanpage để được giúp đỡ.";
            }
        }else{
            $message = "Bạn cần xác thực tài khoản để dùng chức năng này! Vui lòng liên hệ trên fanpage để được giúp đỡ.";
        }

        $url = $this->website."/sendMessage?chat_id=".$cid."&text=".urlencode($message);
        file_get_contents($url);
//        die;
    }

    function replyTakePhoneNumber($cid, $phone_number) {
        $phone_number = str_replace("+","",$phone_number);
        $phone_number = str_replace(" ","",$phone_number);
        if(substr($phone_number, 0, 2) == "84"){
            $phone_number = "0".substr($phone_number, 2, strlen($phone_number));
        }

        $user_vr = $this->UserVerifiled->find("first",[
            'conditions' => [
                'UserVerifiled.phone' => $phone_number,
            ]
        ]);
        if(count($user_vr) == 0){
            $message = "Số điện thoại " . $phone_number . " chưa được đăng ký bảo mật cho bất kỳ tài khoản nào. Vui lòng liên hệ trên fanpage để được giúp đỡ.";
            //Tim thang co cid roi, va xoa no di
            $user = $this->User->find("first",[
                'cid' => $cid,
            ]);
            if(count($user) > 0){
                $this->User->save(array(
                    'id' => $user['User']['id'],
                    'cid' => ""));
            }
        }else {
            $message = "Số phone của bạn là: " . $phone_number . ". Bạn đã đăng ký thành công. Sau đây bạn nhập OTP để lấy mã OTP qua Telegram.";

            //Tim thang co cid roi, va xoa no di
            $user = $this->User->find("first",[
                'conditions' => [
                    'cid' => $cid,
                    'id <>' =>  $user_vr['UserVerifiled']['user_id']
                ]
            ]);
            if(count($user) > 0){
                $this->User->save(array(
                    'id' => $user['User']['id'],
                    'cid' => ""));
            }

            $this->User->save(array(
                'id' => $user_vr['UserVerifiled']['user_id'],
                'cid' => $cid));

            //Update cho đại lý
            $agency = $this->Agency->find("first",[
                'conditions' => [
                    'userid' => $user_vr['UserVerifiled']['user_id'],
                ]
            ]);
            if(count($agency) > 0){
                $this->Agency->save(array(
                    'id' => $agency['Agency']['id'],
                    'teleid' => $cid));
            }
        }

        $url = $this->website."/sendMessage?chat_id=".$cid."&text=".urlencode($message);
        file_get_contents($url);
//        die;
    }

}
