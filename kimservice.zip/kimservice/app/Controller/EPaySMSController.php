<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */

App::uses('PaymentPack', 'Model');
App::uses('OutPacket', 'Model');
App::uses('HttpSocket', 'Network/Http');

class EPaySMSController extends AppController
{
    private $SMS_1PAY = 1;
    private $SMS_EPAY = 2;
    public $uses = ['User', 'Payment', 'PaymentEpaySMS', 'PaymentManager' , 'UserVerifiled'];

    public function smspayment()
    {
        $param = $this->request->query;
        CakeLog::write('EPaySMSController',json_encode( $param));
        // url demo: http://localhost/zpService/web/index.php/epaysms/smspaymentmain?partnerid=10306&userid=841649651932&moid=12800062&shortcode=9029&keyword=BAIVIP&subkeyword=&transdate=20170821165945&telcocode=VTT&&content=BAIVIP+NAP5+20170818100104&checksum=5f6baef172b9003097faa5db20fd3274&amount=5000
        // url demo: http://localhost/zpService/web/index.php/epaysms/smspayment?partnerid=10306&userid=841649651932&moid=12800062&shortcode=9029&keyword=BAIVIP&content=BAIVIP+NAP5+20170818100104&checksum=48a9aa433f2b84e74305d91e7a9dd3f6&amount=1000

        if ($this->checkSyntax($param['content'])) {
            http_response_code(200);
            echo '1|noi dung hop le';
            CakeLog::write('EPaySMSController',"1|noi dung hop le");
        }else{
            http_response_code(400);
            echo '0|noi dung khong hop le';
            CakeLog::write('EPaySMSController',"0|noi dung khong hop le");
        }

        die;
    }

    private function checkSyntax($content){
        $pay = $this->PaymentManager->find("all", [
            'conditions' => [
                'PaymentManager.type' => $this->SMS_EPAY
            ]
        ]);
        for ($i = 0; $i < count($pay); $i++){
            $sms =  $pay[$i]["PaymentManager"]["sms_syntax"];
            $sms = str_replace("REF", "", $sms);

            $pos = strrpos($content, $sms);
            if ($pos >= 0){
                return true;
            }

        }
        return false;
    }

    public function smspaymentmain()
    {

        $param = $this->request->query;
        CakeLog::write('EPaySMSController',json_encode( $param) . ' checksum:'. $this->get_checksum($param['moid'] .  $param['shortcode'].$param['keyword'] . $param['content'].$param['transdate']. SMSP_PARTNER_PASSWORD));
        if(!empty($param)){
            if(!empty($param['partnerid']) && $param['partnerid'] == SMSP_PARTNER_ID
                && !empty($param['checksum']) && ($param['checksum'] == $this->get_checksum($param['moid'] .  $param['shortcode'].$param['keyword'] . $param['content'].$param['transdate']. SMSP_PARTNER_PASSWORD))){

                $pay = $this->PaymentEpaySMS->find("first", [
                    'conditions' => [
                        'PaymentEpaySMS.moid' => $param['moid'],
                    ]
                ]);
                if(count($pay) > 0) {
                    http_response_code(400);
                    echo 'requeststatus=2';
                    CakeLog::write('EPaySMSController','requeststatus=2');
                    die;
                }

                $arrSMS = explode(" ", $param['content']);
                $userID = substr($arrSMS[count($arrSMS) - 1], 8, strlen($arrSMS[count($arrSMS) - 1]) - 8);
                //nếu chưa tồn tại MoID thì chèn dữ liệu mới nhận vào db
                $this->PaymentEpaySMS->save(array(
                    'moid' => $param['moid'],
                    'transdate' => $param['transdate'],
                    'phone_number' => $param['userid'],
                    'partnerid' => $param['partnerid'],
                    'userid' => $userID,
                    'amount' => $param['amount'],
                    'shortcode' => $param['shortcode'],
                    'content' => $param['content'],
                    'card_type' => $param['telcocode'],
                    'status' => 0,
                    'created' => date("Y-m-d"),

                ));


                $mtid = $param['partnerid']. date("YmdHis") . rand(1,99999);

                $url = "http://sms.megapayment.net.vn:9099/smsApi?";
                $url .= 'partnerid='.$param['partnerid'];
                $url .= '&moid='.$param['moid'];
                $url .= '&mtid='.$mtid;
                $url .= '&userid='.$param['userid'];
                $url .= '&shortcode='.$param['shortcode'];
                $url .= '&keyword='.$param['keyword'];
                $checkPhone = false;
                if($param['keyword'] != "BAIVIP") {
                    $phoneData = $this->UserVerifiled->find("count", [
                        'conditions' => [
                            'UserVerifiled.phone' => $param['userid'],
                        ]
                    ]);
                    if($phoneData >= NUMBER_PHONE_VERIFILED){
                        $checkPhone = true;
                        $content = urlencode('So dien thoai de xac thuc da duoc su dung qua so lan quy dinh. CSKH: 0967582955. Chuc ban choi game vui ve!');
                    }else{
                        $content = urlencode('Ban da xac thuc TK co UID:' . $userID . ' thanh cong. Ma giao dich ' . $arrSMS[count($arrSMS) - 1] . '. CSKH: 0967582955. Chuc ban choi game vui ve!');
                    }

                }
                $checsum = $mtid . $param['moid'] . $param['shortcode'] . $param['keyword'] . $content . $param['transdate'] . SMSP_PARTNER_PASSWORD;
                $checsum = $this->get_checksum($checsum);
                $url .= '&content='.$content;

                if($this->checkSyntax($param['content']) && $checkPhone == false)
                    $url .= '&messagetype='. 1;
                else
                    $url .= '&messagetype='. 0;
                $url .= '&transdate='.$param['transdate'];
                $url .= '&checksum='. $checsum;
                $url .= '&amount='.$param['amount'];

                $HttpSocket = new HttpSocket();
                // string query
                $results = $HttpSocket->get($url);
                CakeLog::write('EPaySMSController',$url);
                CakeLog::write('EPaySMSController',json_encode($results));

                if($results->code == 200 && $checkPhone == false) {
                    $this->UserVerifiled->save(array(
                        'user_id' => $userID,
                        'phone' => $param['userid'],
                        'created' => date("Y-m-d"),
                    ));
                    $checkSokcet = false;
                    //Open socket to server
                    if ($this->socket == null) {
                        $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    }
                    if ($this->socket === false) {
                        $checkSokcet = false;
                    } else {
                        $checkSokcet = true;
                    }

                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                    if ($result === false) {
                        $checkSokcet = false;
                    } else {
                        $checkSokcet = true;
                    }

                    $amount = $param['amount'];
                    $p = new OutPacket(1, PAYMENT_1_PAY_SMS);
                    $p->putInt(SMS);
                    if($param['keyword'] == "BAIVIP") {
                        $p->putInt(-1);
                    } else {
                        $p->putInt(0);
                    }
                    $p->putString("sms");
                    $p->putString("sms");
                    $p->putLong($amount);
                    $p->putLong($userID);
                    $p->putString(php_secret_key);
                    $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                    $pckLen = strlen($packet);
                    socket_write($this->socket, $packet, $pckLen);
                    socket_close($this->socket);

                    http_response_code(200);
                    echo 'requeststatus=200';
                    CakeLog::write('EPaySMSController','requeststatus=200');
                    die;
                }else{
                    CakeLog::write('EPaySMSController','requeststatus=200-----------------------------');
                }

            }
        }

        http_response_code(400);
        echo 'requeststatus=1';
        CakeLog::write('EPaySMSController','requeststatus=1');
        die;
    }
    /*
     * function get check sum response
     * author: Nguyen Tat Loi
     * date: 12/2/2015
     */

    private function get_checksum($str)
    {
        $str = str_replace(" ","+", $str);
        return md5($str);
    }

    private function get_checksum_reponse($get)
    {
        pr($get);
        return md5($get['moid'].$get['shortcode'].$get['keyword'].str_replace(' ', '+', $get['content']).$get['transdate'].SMSP_PARTNER_PASSWORD);
    }

    /*
     * function get curl
     * author: Nguyen Tat Loi
     * date: 26/03/2014
     */
    public function get_curl($url)
    {
        $curl = curl_init();

        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 10);

        $str = curl_exec($curl);
        if(empty($str)) $str = $this->curl_exec_follow($curl);
        curl_close($curl);

        return $str;
    }
    /*
     * function dùng curl gọi đến link
     * author: Nguyen Tat Loi
     * date: 26/03/2014
     */
    private function curl_exec_follow($ch, &$maxredirect = null)
    {
        $user_agent = "Mozilla/5.0 (Windows; U; Windows NT 5.1; en-US; rv:1.7.5)".
            " Gecko/20041107 Firefox/1.0";
        curl_setopt($ch, CURLOPT_USERAGENT, $user_agent );

        $mr = $maxredirect === null ? 5 : intval($maxredirect);

        if (ini_get('open_basedir') == '' && ini_get('safe_mode' == 'Off')) {

            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, $mr > 0);
            curl_setopt($ch, CURLOPT_MAXREDIRS, $mr);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

        } else {

            curl_setopt($ch, CURLOPT_FOLLOWLOCATION, false);

            if ($mr > 0)
            {
                $original_url = curl_getinfo($ch, CURLINFO_EFFECTIVE_URL);
                $newurl = $original_url;

                $rch = curl_copy_handle($ch);

                curl_setopt($rch, CURLOPT_HEADER, true);
                curl_setopt($rch, CURLOPT_NOBODY, true);
                curl_setopt($rch, CURLOPT_FORBID_REUSE, false);
                do
                {
                    curl_setopt($rch, CURLOPT_URL, $newurl);
                    $header = curl_exec($rch);
                    if (curl_errno($rch)) {
                        $code = 0;
                    } else {
                        $code = curl_getinfo($rch, CURLINFO_HTTP_CODE);
                        if ($code == 301 || $code == 302) {
                            preg_match('/Location:(.*?)\n/', $header, $matches);
                            $newurl = trim(array_pop($matches));

                            if(!preg_match("/^https?:/i", $newurl)){
                                $newurl = $original_url . $newurl;
                            }
                        } else {
                            $code = 0;
                        }
                    }
                } while ($code && --$mr);

                curl_close($rch);

                if (!$mr)
                {
                    if ($maxredirect === null)
                        trigger_error('Too many redirects.', E_USER_WARNING);
                    else
                        $maxredirect = 0;

                    return false;
                }
                curl_setopt($ch, CURLOPT_URL, $newurl);
            }
        }
        return curl_exec($ch);
    }
}
