<?php

date_default_timezone_set('Asia/Ho_Chi_Minh');
App::import('Vendor', 'epay/libs/nusoap');
App::uses('OutPacket', 'Model');

class VippayController extends AppController
{

    public $uses = ['User', 'PaymentMaxpay', 'PaymentManager'];
    private $socket;
    /**
     * Hàm thực hiện gọi sang maxpay.vn để gạch thẻ
     * @param $merchant_txn_id mã giao dịch duy nhất của merchant
     * @param $cardType loại thẻ
     * @param $pin mã thẻ (pin)
     * @param $serial số seri
     * @return mixed
     */

    function test(){
        header('Content-type: application/json');
        $param = $this->request->query;
        CakeLog::write('VippayController',json_encode( $param));
        $merchant_txn_id = Util::random_string(12) . time();
        if (!isset($param['card_type']) ||
            !isset($param['pin']) ||
            !isset($param['seri']) ||
            !isset($param['userID'])
        ) {
            $result = array('status' => 1, 'data' => "Thieu param");
            echo json_encode($result);

        } else {
            $card_type = $param["card_type"];
            $pin = $param["pin"];
            $seri = $param["seri"];
            $userID = $param["userID"];
            $type = "VTT";
            if ($card_type == 1) {
                $type = "VTT";
            } else if ($card_type == 2) {
                $type = "VNP";
            } else {
                $type = "VMS";

            }
            $result = $this->cashin19($card_type,$seri,$pin,$userID);
            pr($result);
            echo "thanh cong";
        }
        die;
    }
    function cashin19($telco,$serial,$pin,$transid){
        $arrayTelco = array(
            '1'=>'VTT',
            '2'=>'VNP',
            '3'=>'VMS'
        );

        $arrayTelcoLink = array(
            '1'=>'http://210.211.99.139:8183/vcard/cardService?wsdl',
            '2'=>'http://210.211.99.139:8183/vcard/cardService?wsdl',
            '3'=>'http://210.211.99.139:8183/vcard/cardService?wsdl',
        );
        $authorization = "5A09EA8EE797E089";
        $keyUI = "A1733B72AC749E85FDE94037";
        $cardtype = $arrayTelco[$telco];

        $eSerial = $this->encrypt($serial, $keyUI);

        $ePin = $this->encrypt($pin, $keyUI);

        $eSignature = $serial . $pin . $cardtype . $transid;

        $eSignature = $this->encrypt($eSignature,$keyUI);

        $params = array(
            'type'      => $cardtype,
            'serial'    => $eSerial,
            'pin'       => $ePin,
            'transid'   => $transid,
            'signature' => $eSignature,
        );

        $client = new SoapClient($arrayTelcoLink[$telco], [
            'stream_context' => stream_context_create([
                'http'=> [
                    'header' => "Authorization: $authorization",
                    'user_agent' => 'PHP/SOAP',
                ]
            ])
        ]);

        $value = $client->gachthe($params);
        return $value;
    }

    function encrypt($str, $key) {
        $cipher = mcrypt_module_open(MCRYPT_3DES, '', 'ecb', '');
        $iv = mcrypt_create_iv(mcrypt_enc_get_iv_size($cipher), MCRYPT_DEV_RANDOM);
        mcrypt_generic_init($cipher, $key, $iv);
        $encrypted_text = mcrypt_generic($cipher, $str);
        $encrypted = bin2hex($encrypted_text);
        mcrypt_generic_deinit($cipher);
        mcrypt_module_close($cipher);
        return strtoupper($encrypted);
    }

    public function addcard()
    {
        header('Content-type: application/json');
        $param = $this->request->query;
        CakeLog::write('VippayController',json_encode( $param));
        $merchant_txn_id = Util::random_string(12) . time();
        if (!isset($param['card_type']) ||
            !isset($param['pin']) ||
            !isset($param['seri']) ||
            !isset($param['userID'])
        ) {
            $result = array('status' => 1, 'data' => "Thieu param");

        } else {
            $card_type = $param["card_type"];
            $pin = $param["pin"];
            $seri = $param["seri"];
            $userID = $param["userID"];
            $type = "VTT";
            if($card_type == 1){
                $type = "VTT";
            }else if($card_type == 2){
                $type = "VNP";
            }else{
                $type = "VMS";

            }

            $code = 1;

            $transaction = array(
                "cardCode"=>$pin,
                'cardSerial'=>$seri,
                'issuer'=>$type,
                'transRef'=>uniqid()."_".rand(0,100), // duy nhat tren moi gd nap the
                'accountId'=>$userID, // account user su dung de nap the
                'username'=>'x',
                'password'=>'y');


            $response = curl_rest('http://gatecard.dcloud.co:40181/api/card',$transaction);
            if(!empty($response)){
                $status = $response['status'];
                $amount = intval($response['amount']);
                CakeLog::write(" reqid  status  :".$status. "- amount :" .$amount);
                if($response['status']=='01'){
                    // Giao dịch thành công
                    $code = 1;
                } else  if($response['status']=='24'){
                    // serial và mã nạp tiền k đúng
                    $code = 2;
                } else  if($response['status']=='00' ||$response['status']=='03' ){
                    $code = 3;
                    // thể đã sử dung
                } else  if($response['status']=='20' || $response['status']=='23'  || $response['status']=='28'){
                    // serial hoặc mã thẻ k đúng
                    $code = 4;
                } else {
                    // xem them mã lỗi  trong tài liêu
                    $code = 5;
                }
            } else {
                // không có kết quả trả về , giao dịch lỗi
                $code = 6;
            }



            $checkSokcet = false;
            //Open socket to server
            if ($this->socket == null) {
                $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
            }
            if ($this->socket === false) {
                $checkSokcet = false;
            } else {
                $checkSokcet = true;
            }

            $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
            if ($result === false) {
                $checkSokcet = false;
            } else {
                $checkSokcet = true;
            }


            if ($code ==1) {
                $this->PaymentMaxpay->save(array(
                    'userid' => $userID,
                    'merchanttxnid' => $merchant_txn_id,
                    'card_type' => $card_type,
                    'seri' => $seri,
                    'pin' => $pin,

                ));

                //TODO: xử lý thẻ đúng
                $pay = $this->PaymentMaxpay->find("first", [
                    'conditions' => [
                        'PaymentMaxpay.merchanttxnid' => $merchant_txn_id,
                    ]
                ]);
                if (count($pay) > 0) {
                    $this->PaymentMaxpay->save(array(
                        'id' => $pay['PaymentMaxpay']['id'],
                        'code' => $code,
                        'card_amount' => $rs['card_amount'],
                        'net_amount' => $rs['net_amount'],

                    ));
                }
                $arr =  array(1, 'Thanh cong');

                echo json_encode($arr);

                //The OK Array ( [code] => 1 [message] => Náº¡p tháº» thÃ nh cÃ´ng [txn_id] => ac4qmetbbsv61498533575 [card_amount] => 10000 [net_amount] => 7800 )
                $p = new OutPacket(1, PAYMENT_MAX_PAY);
                $p->putInt(CARD);
                $p->putInt($card_type);
                $p->putString("mcard");
                $p->putString("mcard");
                $p->putLong($rs['card_amount']);
                $p->putLong($userID);
                $p->putString(php_secret_key);
                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);

            } else {
                //TODO: xử lý thẻ lỗi
                $arr =  array(-1, 'Thanh cong');

                echo json_encode($arr);

                $p = new OutPacket(1, PAYMENT_MAX_PAY);
                $p->putInt(-1);
                $p->putInt(-1);
                $p->putString("mcard");
                $p->putString("mcard");
                $p->putLong($code);
                $p->putLong($userID);
                $p->putString(php_secret_key);
                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
            }
        }
        die;
    }
    function curl_rest($url, $data){
        $curl = curl_init($url);
        $fields_string = json_encode($data);
        curl_setopt($curl, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($curl, CURLOPT_POSTFIELDS, $fields_string);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, TRUE);
        curl_setopt($curl, CURLOPT_TIMEOUT, 90);
        curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 30);
        curl_setopt($curl, CURLOPT_HTTPHEADER, array(
                'Content-Type: application/json',
                'Content-Length: ' . strlen($fields_string))
        );
        $json = array();
        try{
            $result = curl_exec($curl);
        }catch(Exception $e){
            echo $e->getMessage();
            return null;
        }
        $json = json_decode($result,true);
        curl_close($curl);
        return $json;
    }



}