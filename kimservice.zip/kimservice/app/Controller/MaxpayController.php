<?php
/**
 * Thư viện tích hợp thẻ cào maxpay.vn
 * Version 1.0
 */

date_default_timezone_set('Asia/Ho_Chi_Minh');
App::uses('OutPacket', 'Model');

class MaxpayController extends AppController
{

    public $uses = ['User', 'PaymentMaxpay', 'PaymentManager'];
    private $socket;
    /**
     * Hàm thực hiện gọi sang maxpay.vn để gạch thẻ
     * @param $merchant_txn_id mã giao dịch duy nhất của merchant
     * @param $cardType loại thẻ
     * @param $pin mã thẻ (pin)
     * @param $serial số seri
     * @return mixed
     */
    public function charge($merchant_txn_id, $cardType, $pin, $serial)
    {
        $args = array('merchant_id' => MERCHANT_ID, 'pin' => $pin,
            'seri' => $serial, 'card_type' => $cardType, 'merchant_txn_id' => $merchant_txn_id);
        CakeLog::write('MaxpayController', json_encode($args));
        //Create checksum security code
        $args['checksum'] = $this->_createChecksum($args);

        //Build request url
        $requestUrl = CHARGE_SERVICE_URL . http_build_query($args);

        //Call maxpay.vn's web service
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $requestUrl);
        curl_setopt($ch, CURLOPT_CAINFO, VENDORS . "maxpay/ca.crt");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        $output = curl_exec($ch);

        //If curl error?
        if ($output === false) {
            $response = array(
                'code' => 99,
                'message' => 'Your curl error: ' . curl_error($ch)
            );
            curl_close($ch);
            return $response;
        }

        curl_close($ch);

        $response = json_decode($output, true);
        //If json format error?
        if ($response === false) {
            return array(
                'code' => 99,
                'message' => $output
            );
        }

        return $response;
    }

    /**
     * Hàm thực hiện gọi sang maxpay.vn để kiểm tra tình trạng của một giao dịch thẻ
     * @param $merchant_txn_id mã giao dịch duy nhất của merchant
     * @return mixed
     */
    public function recheck($merchant_txn_id)
    {
        $args = array('merchant_id' => MERCHANT_ID, 'merchant_txn_id' => $merchant_txn_id);

        //Create checksum security code
        $args['checksum'] = $this->_createChecksum($args);

        //Build request url
        $requestUrl = RECHECK_SERVICE_URL . http_build_query($args);

        //Call maxpay.vn's web service
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $requestUrl);
        curl_setopt($ch, CURLOPT_CAINFO, VENDORS . "maxpay/ca.crt");
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_TIMEOUT, 60);
        $output = curl_exec($ch);

        //If curl error?
        if ($output === false) {
            $response = array(
                'code' => 99,
                'message' => 'Your curl error: ' . curl_error($ch)
            );
            curl_close($ch);
            return $response;
        }

        curl_close($ch);

        $response = json_decode($output, true);
        //If json format error?
        if ($response === false) {
            return array(
                'code' => 99,
                'message' => $output
            );
        }

        return $response;
    }

    /**
     * Hàm thực hiện tạo mã bảo mật checksum
     * @param $args
     * @return string
     */
    private function _createChecksum($args)
    {
        ksort($args);
        return hash_hmac('SHA1', implode('|', $args), SECRET_KEY);
    }


    public function addcard()
    {
        header('Content-type: application/json');
        $param = $this->request->query;
        CakeLog::write('MaxpayController',json_encode( $param));
        $merchant_txn_id = Util::random_string(12) . time();
        if (!isset($param['card_type']) ||
            !isset($param['pin']) ||
            !isset($param['seri']) ||
            !isset($param['userID'])
        ) {
            $result = array('status' => 1, 'data' => "Thieu param");

        } else {
            $card_type = $param["card_type"];
            $pin = $param["pin"];
            $seri = $param["seri"];
            $userID = $param["userID"];
            $type = "VTE";
            if($card_type == 1){
                $type = "VTE";
            }else if($card_type == 2){
                $type = "VNP";
            }else{
                $type = "VMS";

            }

            $rs = $this->charge($merchant_txn_id, $type, $pin, $seri);

            $checkSokcet = false;
            //Open socket to server
            if ($this->socket == null) {
                $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
            }
            if ($this->socket === false) {
                $checkSokcet = false;
            } else {
                $checkSokcet = true;
            }

            $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
            if ($result === false) {
                $checkSokcet = false;
            } else {
                $checkSokcet = true;
            }


            if (isset($rs['code']) && $rs['code'] == 1) {
                $this->PaymentMaxpay->save(array(
                    'userid' => $userID,
                    'merchanttxnid' => $merchant_txn_id,
                    'card_type' => $card_type,
                    'seri' => $seri,
                    'pin' => $pin,

                ));

                //TODO: xử lý thẻ đúng
                $pay = $this->PaymentMaxpay->find("first", [
                    'conditions' => [
                        'PaymentMaxpay.merchanttxnid' => $merchant_txn_id,
                    ]
                ]);
                if (count($pay) > 0) {
                    $this->PaymentMaxpay->save(array(
                        'id' => $pay['PaymentMaxpay']['id'],
                        'code' => $rs['code'],
                        'card_amount' => $rs['card_amount'],
                        'net_amount' => $rs['net_amount'],

                    ));
                }
                $arr =  array(1, 'Thanh cong');

                echo json_encode($arr);

                //The OK Array ( [code] => 1 [message] => Náº¡p tháº» thÃ nh cÃ´ng [txn_id] => ac4qmetbbsv61498533575 [card_amount] => 10000 [net_amount] => 7800 )
                $p = new OutPacket(1, PAYMENT_MAX_PAY);
                $p->putInt(CARD);
                $p->putInt($card_type);
                $p->putString("mcard");
                $p->putString("mcard");
                $p->putLong($rs['card_amount']);
                $p->putLong($userID);
                $p->putString(php_secret_key);
                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);

            } else {
                //TODO: xử lý thẻ lỗi
                $arr =  array(-1, 'Thanh cong');

                echo json_encode($arr);

                $p = new OutPacket(1, PAYMENT_MAX_PAY);
                $p->putInt(-1);
                $p->putInt(-1);
                $p->putString("mcard");
                $p->putString("mcard");
                $p->putLong(0);
                $p->putLong($userID);
                $p->putString(php_secret_key);
                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
            }
        }
        die;
    }

    public function callbackmaxpay()
    {

        $param = $this->request->data;
        CakeLog::write('MaxpayController', json_encode($param));
        if (!isset($param['merchant_txn_id']) ||
            !isset($param['code']) ||
            !isset($param['seri']) ||
            !isset($param['checksum']) ||
            !isset($param['net_amount'])
        ) {

        } else {


            $pay = $this->PaymentMaxpay->find("first", [
                'conditions' => [
                    'PaymentMaxpay.merchanttxnid' => $param['merchant_txn_id'],
                ]
            ]);
            if (count($pay) > 0) {
                $this->PaymentMaxpay->save(array(
                    'id' => $pay['PaymentMaxpay']['id'],
                    'code' => $param['code'],
                    'card_amount' => $param['card_amount'],
                    'net_amount' => $param['net_amount'],
                ));

                echo "ok";
            }
//            $this->Payment->save(array(
//                'description' => $param,
//            ));

        }
        die;
    }

}