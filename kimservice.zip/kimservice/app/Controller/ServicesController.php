<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */
date_default_timezone_set('Asia/Ho_Chi_Minh');
class ServicesController extends AppController

{

    public $uses = ['HostUpdates'];

    public function getService(){
        header('Access-Control-Allow-Origin: *');
        $param = $this->request->query;
        $result = [
            'status' => false,
            'data' => [
                'is_force_update' => false,
                'url' => null
            ]
        ];
        if (!isset($param['game']) ||
            !isset($param['version_code']) ||
            !isset($param['store_type'])
        ) {
            $result = array('status' => false, 'data' => "Thieu param");
        } else {
            $check_version = $this->HostUpdates->find('first',[
                'fields' => ['version_code'],
                'conditions' => [
                    'version_code > ' => $param['version_code'],
                    'game' => $param['game'],
                    'store_type' => $param['store_type'],
                    'force_update' => true,
                ],
                'order' => [ 'version_code' => 'DESC']
            ]);
//            pr($check_version);
            if ($check_version){
                $get_url  = $this->HostUpdates->find('first',[
                    'fields' => ['version_code','url','review'],
                    'conditions' => [
                        'version_code > ' => $param['version_code'],
                        'game' => $param['game'],
                        'store_type' => $param['store_type'],
                    ],
                    'order' => [ 'version_code' => 'DESC']
                ]);
            }
            $get_url1  = $this->HostUpdates->find('first',[
                'fields' => ['version_code','url','review'],
                'conditions' => [
                    'version_code' => $param['version_code'],
                    'game' => $param['game'],
                    'store_type' => $param['store_type'],
                ],
                'order' => [ 'version_code' => 'DESC']
            ]);
//            pr($get_url);
            $result = [
                'status' => true,
                'data' => [
                    'is_force_update' => $check_version ? true : false,
                    'url' => isset($get_url) ? $get_url['HostUpdates']['url'] : null,
                    'isreview' => isset($get_url1) && $get_url1['HostUpdates']['review'] == 1 ? true : false
                ]
            ];
        }
        header('Content-type: application/json');
        echo json_encode($result);
        die;
    }

}