<?php
/**
 * Thư viện tích hợp thẻ cào maxpay.vn
 * Version 1.0
 */

date_default_timezone_set('Asia/Ho_Chi_Minh');
App::uses('OutPacket', 'Model');
App::uses('Security', 'Utility');
class UserSendGoldController extends AppController
{

    public $uses = ['User', 'Trade', 'Agency', 'UserBlock'];
    private $socket;
    private $CODE_ADD_GOLD = 3;
    private $CODE_DL_NHAN_HEY = 41;
    private $CODE_THU_HOI_GOLD = 40;


    private $STATUS_NHAN_CHUA_XLY = 3;
    private $STATUS_NHAN_DA_XLY = 4;
    private $STATUS_NHAN_TAM_HOAN = 5;
    private $STATUS_NHAN_HOAN_TRA = 6;
    private $STATUS_CHUYEN_THANH_CONG = 1;
    private $STATUS_CHUYEN_THU_HOI = 2;

    public function gethistorysend(){

        $param = $this->request->query;
        if (!isset($param['userId'])
        ) {
            $result = array(1);
            echo json_encode($result);

        }else{
            $rs1 = $this->Trade->find("all", [
                'conditions' => [
                    'Trade.user' => $param['userId']
                ]
            ]);
            echo json_encode($rs1);
        }
        die;
    }

    public function gethistoryreceive(){
        header('Content-type: application/json');
        header('Access-Control-Allow-Origin: *');
        $param = $this->request->query;
        if (!isset($param['userId'])
        ) {
            $result = array(1);
            echo json_encode($result);

        }else{
            $rs1 = $this->Trade->find("all", [
                'conditions' => [
                    'Trade.user_target' => $param['userId']
                ]
            ]);
            echo json_encode($rs1);
        }
        die;
    }


    public function agencysendgold()
    {

        $param = $this->request->query;
//        http://localhost/casinoService/UserSendGold/sendgold?userCurren=1005&userTarget=1&gold=113&mess=abcvvv&token=20c06a0c477de25a0b204ed10c09ebc5af126421d3c8204a5640189299dd3cac
        CakeLog::write('MaxpayController', "agencysendogld ".json_encode( $param));
        if (!isset($param['userCurren']) ||
            !isset($param['userTarget']) ||
            !isset($param['gold']) ||
            !isset($param['mess']) ||
            !isset($param['token'])
        ) {
            echo "Thiếu thông tin khi chuyển ";

        } else {
            $userCurren = $this->getIDbyName($param["userCurren"]);
            $userTarget = $this->getIDbyName($param["userTarget"]);
            if($userCurren == 0 || $userTarget == 0){
                echo "Sai thông tin người chuyển";
                die;
            }
            $gold = $param["gold"];
            $mess = $param['mess'];
            $token = $param['token'];

            $rs1 = $this->Agency->find("first", [
                'conditions' => [
                    'Agency.userid' => $userCurren
                ]
            ]);

            $data = "userCurren=" . $param["userCurren"] . '&userTarget=' . $param["userTarget"] . '&gold=' . $gold;

            $secret = KEY_ENCODE; //product's secret key (get value from 1Pay product detail)
            $signature = hash_hmac("sha256", $data, $secret); // create signature to check
            if($signature == $token){


                //Gui du lieu sang sv Java
                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }

                $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                if($checkSokcet){
                    $p = new OutPacket(1, USER_TRADE_GOLD);
                    $p->putLong($gold);//Loai the card thanh cong
                    $p->putLong($param["goldsub"]);
                    $p->putString($mess);
                    $p->putInt($userCurren);
                    $p->putInt($userTarget);
                    $p->putString($param["userCurren"]);
                    $p->putString($param["userTarget"]);
                    $p->putString(php_secret_key);
                    CakeLog::write('MaxpayController', 'agencysendogld '.json_encode( $p));

                    $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                    $pckLen = strlen($packet);
                    socket_write($this->socket, $packet, $pckLen);
                    socket_close($this->socket);

                    //------------------------
                    echo "Chuyển gold thành công";
//                    $this->Trade->save(array(
//                        'user' => $param["userCurren"],
//                        'user_target' => $param["userTarget"],
//                        'gold' => $gold,
//                        'mess' => $mess
//
//                    ));
                }else{
                    echo "Có lỗi khi chuyển gold";
                }

            }else{
                echo "Đã Có lỗi khi chuyển gold";
            }
        }
        die;
    }

    public function returngold(){
        $param = $this->request->query;
        CakeLog::write('MaxpayController', "returngold " . json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (!isset($param['id_trade']) ||
            !isset($param['content']) ||
            !isset($param['token'])
        ) {

            echo "thieu param";
        }else {

            $d = Security::hash($param['id_trade'] . "+" . $param['content']. KEY_ENCODE, "sha256");
            if ($d == $param['token']) {
                echo $param['id_trade'];
                $trade = $this->Trade->find("first",[
                    'conditions' =>[
                        'id' => $param['id_trade']
                    ]
                ]);

                if(count($trade) == 0){
                    echo "Không tồn tại mã giao dịch";
                    die;
                }


                $curID = 21;//$this->getIDbyN`ame($trade['Trade']['user']);
                $curTg = 22;//$this->getIDbyName($trade['Trade']['user_target']);

                $gold = $trade['Trade']['gold'];

                $this->Trade->save(array(
                    'id' => $trade['Trade']['id'],
                    'status' => 2,
                    'note' => $trade['Trade']['user']." Thu hồi " . $gold ." của User " . $trade['Trade']['user_target'].'.  '.$param['content']

                ));


                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt($curID);//Loai the card thanh cong
                $p->putInt($this->CODE_ADD_GOLD);//code
                $p->putInt($gold);//gold
                $p->putString("Thu hồi " . $gold . " của User " . $trade['Trade']['user_target']);
                $p->putString("Thu hồi " . $gold . " của User " . $trade['Trade']['user_target']);
                $p->putString(php_secret_key);

                $p1 = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p1->putInt($curTg);//Loai the card thanh cong
                $p1->putInt($this->CODE_ADD_GOLD);//code
                $p1->putInt(-$gold);//gold
                $p1->putString("Thu hồi " . $gold . " từ " . $trade['Trade']['user']);
                $p1->putString("Thu hồi " . $gold . " từ " . $trade['Trade']['user']);
                $p1->putString(php_secret_key);


                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);

                $packet1 = pack("c*", -112, $p1->_size / 256, $p1->_size % 256, ...$p1->_pack);
                $pckLen1 = strlen($packet1);
                socket_write($this->socket, $packet1, $pckLen1);
                socket_close($this->socket);
                $this->socket = null;

                echo "thanh cong";
            }
        }

        die;
    }


    public function getIDbyDisplayname(){
        $param = $this->request->query;
//        http://localhost/casinoService/UserSendGold/sendgold?userCurren=1005&userTarget=1&gold=113&mess=abcvvv&token=20c06a0c477de25a0b204ed10c09ebc5af126421d3c8204a5640189299dd3cac
        CakeLog::write('MaxpayController', "getIDbyDisplayname" . json_encode( $param));
        if (!isset($param['displayname'])
        ) {
            $result = array("code" => 1, "data" => 0);
            echo json_encode($result);

        } else {
            $id = $this->getIDbyName($param['displayname']);
            if($id != 0){
                $result = array("code" => 0, "data" => $id);
                echo json_encode($result);
            }else{
                $result = array("code" => 2, "data" => $id);
                echo json_encode($result);
            }
        }
        die;
    }

    public function testBlock(){
        $param = $this->request->query;
        $rsCheckBlock = $this->UserBlock->find("first",[ 'conditions' => [
            'UserBlock.user_displayname' => $param['disname']
        ]]);
        pr($rsCheckBlock);
    }

    private function getIDbyName($displayname){
        $rs1 = $this->User->find("first", [
            'conditions' => [
                'User.displayname' => $displayname
            ]
        ]);

        if(count($rs1) > 0){
            return $rs1['User']['id'];
        }
        return 0;
    }

    public function dlNhanHey(){
        $param = $this->request->query;
        CakeLog::write('MaxpayController', 'dlNhanHey'.json_encode( $param));
        if (!isset($param['id']) ||
            !isset($param['name']) ||
            !isset($param['token'])
        ) {
            $res = array("status" => 1, "mess" => "Sai thông tin");
            echo json_encode($res);
            die;
        }else{
            $id = $param["id"];

            $trade = $this->Trade->find("first",[
                'conditions' => [
                    'id' => $id,
                ]]);
            if(count($trade) == 0){
                $res = array("status" => 1, "mess" => "Giao dịch lỗi");
                echo json_encode($res);
                die;
            }

            if(!in_array($trade['Trade']['status'], [$this->STATUS_NHAN_CHUA_XLY, $this->STATUS_NHAN_TAM_HOAN])){
                $res = array("status" => 1, "mess" => "Giao dịch đã xử lý");
                echo json_encode($res);
                die;
            }

            $userTarget = $this->getIDbyName($trade['Trade']['user_target']);
            $dlCurr = $this->Agency->find("first",[
                'conditions' => [
                    'name' => $trade['Trade']['user'],
                ]
            ]);

            $dlTarget = $this->Agency->find("first",[
                'conditions' => [
                    'name' => $trade['Trade']['user_target'],
                ]
            ]);

            $gold = $trade['Trade']['gold'];
            $note = "Số KIM thực nhận ". $gold . " (phí giao dịch 0%).";
            //Neu nhan tien tu C1 se khong bi tinh phi. Con lai se bi tinh phi 1%
            if((count($dlCurr) == 0 || $dlCurr['Agency']['parent'] != 0) && $dlTarget['Agency']['parent'] > 0) {
                $phi = $gold * 0.02;
                $gold = $gold - $gold * 0.02;
                $note = "Số KIM thực nhận ". $gold . " (phí giao dịch 2% : ". $phi ." KIM).";
            }

            $token = $param['token'];
            $data = 'id=' . $param["id"]. '&name='.$param['name'];

            $secret = KEY_ENCODE; //product's secret key (get value from 1Pay product detail)
            $signature = hash_hmac("sha256", $data, $secret); // create signature to check
            if($signature == $token) {
                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                //TODO xử lý trừ 1% của C2 mua KIM từ user.
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt($userTarget);//Loai the card thanh cong
                $p->putInt($this->CODE_DL_NHAN_HEY);//code
                $p->putInt($gold);//gold
                $p->putString("Xử lý thành công giao dich #".$id);
                $p->putString("Xử lý thành công giao dich #".$id);
                $p->putString(php_secret_key);

                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
                $this->socket = null;

                //Update status trade
                $curDate = date("Y-m-d H:i:s");
                $this->Trade->save(array(
                    'id' => $id,
                    'status' => $this->STATUS_NHAN_DA_XLY,
                    'modified' => $curDate,
                    'note' => $note,
                ));

//                $rs1 = $this->Agency->find("first", [
//                    'conditions' => [
//                        'Agency.userid' => $userTarget
//                    ]
//                ]);
//
//                $this->Agency->save(array(
//                    'id' => $rs1['Agency']['id'],
//                    'gold' => $rs1['Agency']['gold'] + $gold,
//                ));

                $res = array("status" => 0, "mess" => "Xử lý thành công");
                echo json_encode($res);
            }else{
                $res = array("status" => 1, "mess" => "Lỗi xác thực dữ liệu");
                echo json_encode($res);
            }
        }
        die;
    }

    public function dlTraHey(){
        $param = $this->request->query;
        CakeLog::write('MaxpayController', 'dlTraHey'.json_encode( $param));
        if (!isset($param['id']) ||
            !isset($param['note']) ||
            !isset($param['name']) ||
            !isset($param['token'])
        ) {
            $res = array("status" => 1, "mess" => "Sai thông tin");
            echo json_encode($res);
            die;
        }else{
            $id = $param["id"];
            $note = $param["note"];
            $trade = $this->Trade->find("first",[
                'conditions' => [
                    'id' => $id,
                ]]);
            if(count($trade) == 0){
                $res = array("status" => 1, "mess" => "Giao dịch lỗi");
                echo json_encode($res);
                die;
            }

            if(!in_array($trade['Trade']['status'], [$this->STATUS_NHAN_CHUA_XLY, $this->STATUS_NHAN_TAM_HOAN])){
                $res = array("status" => 1, "mess" => "Giao dịch đã xử lý");
                echo json_encode($res);
                die;
            }

            $userCurr = $this->getIDbyName($trade['Trade']['user']);
            $gold = $trade['Trade']['gold'];
            $token = $param['token'];
            $data = 'id=' . $param["id"] . '&name='.$param['name'] .'&note='.$param["note"];

            $secret = KEY_ENCODE; //product's secret key (get value from 1Pay product detail)
            $signature = hash_hmac("sha256", $data, $secret); // create signature to check
            if($signature == $token) {
                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt($userCurr);//Loai the card thanh cong
                $p->putInt($this->CODE_ADD_GOLD);//code
                $p->putInt($gold);//gold
                $p->putString("Giao dịch #".$id." bị từ chối bởi đại lý. Bạn được hoàn lại ".$gold." KIM");
                $p->putString("Giao dịch #".$id." bị từ chối bởi đại lý. Bạn được hoàn lại ".$gold." KIM");
                $p->putString(php_secret_key);

                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
                $this->socket = null;

                //Update status trade
                $curDate = date("Y-m-d H:i:s");
                $this->Trade->save(array(
                    'id' => $id,
                    'status' => $this->STATUS_NHAN_HOAN_TRA,
                    'note' => $note,
                    'modified' => $curDate,
                ));
                $res = array("status" => 0, "mess" => "Xử lý thành công");
                echo json_encode($res);
            }else{
                $res = array("status" => 1, "mess" => "Lỗi xác thực dữ liệu");
                echo json_encode($res);
            }
        }
        die;
    }

    public function dlThuHoiHey(){
        $param = $this->request->query;
        CakeLog::write('MaxpayController', 'dlThuHoiHey'.json_encode( $param));
        if (!isset($param['id']) ||
            !isset($param['name']) ||
            !isset($param['token'])
        ) {
            $res = array("status" => 1, "mess" => "Sai thông tin");
            echo json_encode($res);
            die;
        }else{
            $id = $param["id"];
            $trade = $this->Trade->find("first",[
                'conditions' => [
                    'id' => $id,
                ]]);
            if(count($trade) == 0){
                $res = array("status" => 1, "mess" => "Giao dịch lỗi");
                echo json_encode($res);
                die;
            }

            if($trade['Trade']['status'] != $this->STATUS_CHUYEN_THANH_CONG){
                $res = array("status" => 1, "mess" => "Giao dịch đã xử lý");
                echo json_encode($res);
                die;
            }

            $userCurr = $this->getIDbyName($trade['Trade']['user']);
            $userTg = $this->getIDbyName($trade['Trade']['user_target']);
            $gold = $trade['Trade']['gold'];
            $token = $param['token'];
            $data = 'id=' . $param["id"] . '&name='.$param['name'];

            $secret = KEY_ENCODE; //product's secret key (get value from 1Pay product detail)
            $signature = hash_hmac("sha256", $data, $secret); // create signature to check
            if($signature == $token) {
                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt($userCurr);//Loai the card thanh cong
                $p->putInt($this->CODE_THU_HOI_GOLD);//code
                $p->putInt($gold);//gold
                $p->putString("Giao dịch #".$id." bị thu hồi bởi đại lý. Bạn bị thu hồi ".$gold." KIM");
                $p->putString("Giao dịch #".$id." bị thu hồi bởi đại lý. Bạn bị thu hồi ".$gold." KIM");
                $p->putString(php_secret_key);
                $p->putInt($userTg);//userTarget
                $p->putInt($trade['Trade']['id']);//id


                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
                $this->socket = null;

                //Update status trade
                $curDate = date("Y-m-d H:i:s");
                $this->Trade->save(array(
                    'id' => $id,
                    'status' => $this->STATUS_CHUYEN_THU_HOI,
                    'modified' => $curDate,
                ));
                $res = array("status" => 0, "mess" => "Xử lý thành công");
                echo json_encode($res);
            }else{
                $res = array("status" => 1, "mess" => "Lỗi xác thực dữ liệu");
                echo json_encode($res);
            }
        }
        die;
//
//        
    }

    public function sendgold(){

        $param = $this->request->query;
//        http://localhost/casinoService/UserSendGold/sendgold?userCurren=1005&userTarget=1&gold=113&mess=abcvvv&token=20c06a0c477de25a0b204ed10c09ebc5af126421d3c8204a5640189299dd3cac
        CakeLog::write('MaxpayController', 'sendgold'.json_encode( $param));
        if (!isset($param['userCurren']) ||
            !isset($param['userTarget']) ||
            !isset($param['gold']) ||
            !isset($param['mess']) ||
            !isset($param['token'])
        ) {
            $result = array(2);
            echo json_encode($result);

        } else {
            $userCurren = $this->getIDbyName($param["userCurren"]);
            $userTarget = $this->getIDbyName($param["userTarget"]);
            $gold = $param["gold"];
            $mess = $param['mess'];
            $token = $param['token'];

//            $rs1 = $this->Agency->find("first", [
//                'conditions' => [
//                    'Agency.userid' => $userTarget
//                ]
//            ]);
            $status = $this->STATUS_CHUYEN_THANH_CONG;
//            if($rs1 != null){
//                $status = $this->STATUS_NHAN_CHUA_XLY;
//            }

            $data = "userCurren=" . $param["userCurren"] . '&userTarget=' . $param["userTarget"] . '&gold=' . $gold.'&mess='.$mess;

            $secret = KEY_ENCODE; //product's secret key (get value from 1Pay product detail)
            $signature = hash_hmac("sha256", $data, $secret); // create signature to check
            if($signature == $token){

                //Check User bi block hay khong

                $rsCheckBlock = $this->UserBlock->find("first",[ 'conditions' => [
                    'UserBlock.user_displayname' => $param["userCurren"]
                ]]);
                if(count($rsCheckBlock) > 0){
                    $result = array(4);
                    echo json_encode($result);
                    die;
                }else{

                    $this->Trade->save(array(
                        'user' => $param["userCurren"],
                        'user_target' => $param["userTarget"],
                        'gold' => $gold,
                        'status' => $status,
                        'mess' => $mess

                    ));
                    $result = array(0);
                    echo json_encode($result);
                }
            }else{

                $result = array(4);
                echo json_encode($result);
            }
        }
        die;

    }


}