<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/16/2017
 * Time: 9:13 AM
 */
date_default_timezone_set('Asia/Ho_Chi_Minh');

App::uses('Games', 'Model');
include("Component/geoip/geoip.inc");
class GameManagerController extends AppController
{
    public $uses = ['GameManager', 'DeviceManager', 'PaymentMethod', 'UserTopup', 'User', 'Agency', 'UserBigwin', 'Card', 'KpiUserChat'];

    public $listParam = ["game", "os", "versionCode", "mode", "versionName", "deviceId", "installDate"];
    private $gi;
    public function beforeFilter()
    {
        parent::beforeFilter();
        $this->loadModel('Games');
    }


    public function paymentcard()
    {
        $param = $this->request->query;
        $result = [
            0,
            'that bai'
        ];
        if (!isset($param['card_type']) ||
            !isset($param['pin']) ||
            !isset($param['seri']) ||
            !isset($param['userID'])
        ) {
            $result = array('status' => 1, 'data' => "Thieu param");
        } else {
            $method = $this->PaymentMethod->find("first");
            if ($method['PaymentMethod']['method_card'] == "epay") {
                $result = $this->requestAction(['controller' => 'EPayCard', 'action' => 'requestcard', '?' => $param]);
            } else if ($method['PaymentMethod']['method_card'] == "maxpay") {
                $result = $this->requestAction(['controller' => 'Maxpay', 'action' => 'addcard', '?' => $param]);
            }
        }
        header('Content-type: application/json');
        echo json_encode($result);
        die;
    }

    public function get_user_doi_thuong(){
        $rs = $this->UserTopup->find('all',[
            'fields' => [
                'UserTopup.card_type',
                'User.displayname',
                'User.username'
            ],
            'joins' =>[
                [
                    'table' => 'users',
                    'alias' => 'User',
                    'type' => 'inner',
                    'conditions' => [
                       'UserTopup.userid = User.id'
                    ]
                ]
            ],
            'conditions' => [
                'UserTopup.status' => '2'
            ],
            'order' => 'UserTopup.modified DESC',
            'limit' => 10
        ]);
        $result = [];
        foreach ($rs as $data){
            $result[] = [
               'card_type' => $data['UserTopup']['card_type'] ? $data['UserTopup']['card_type'] : '' ,
               'displayname' => $data['User']['displayname'] ? $data['User']['displayname'] : $data['User']['username']
            ];
        }
//        $result[0] = $this->SUCCESS;
//        $result[1] = (object)$temp;
//        pr($result);
        echo json_encode($result);

        die;
    }

    public function getbigwin(){
        $rs = $this->UserBigwin->find('all',[
            'order' => 'UserBigwin.created DESC',
            'limit' => 10
        ]);

        $result = [];
        foreach ($rs as $data){
            $result[] = [
                'mess' => $data['UserBigwin']['mess']
            ];
        }
        header('Content-type: application/json');
        echo json_encode($result);

        die;
    }

    public function paymentsms()
    {

    }
    function getData(){
        if($this->gi == null) {
            $this->gi = geoip_open(APP . "webroot/data/GeoIP.dat", GEOIP_STANDARD);
        }
    }


    function getRealIpAddr()
    {
//        CakeLog::write('GameManagerController', "getLocation ".json_encode($_SERVER));
        if (!empty($_SERVER['HTTP_CLIENT_IP']))   //check ip from share internet
        {
            $ip=$_SERVER['HTTP_CLIENT_IP'];
        }
        elseif (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))   //to check ip is pass from proxy
        {
            $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
        }
        else
        {
            $ip=$_SERVER['REMOTE_ADDR'];
        }
        return $ip;
    }

    function getLocation(){
        try{
            $ip = $this->getRealIpAddr();

//            echo $ip;
            $this->getData();
            return geoip_country_code_by_addr($this->gi, $ip);
        }catch (Exception $e){
            CakeLog::write('GameManagerController', "getLocation ".json_encode($e));
            return "";
        }
    }

    public function getagency(){

        $rsGame = $this->Agency->find("all", [
            'fields' => [
                'id',
                'name',
                'userid',
                'address',
                'phone',
                'face',
                'num',
                'displayname',
                'parent'
            ],
            'conditions' => [
                'Agency.status' => 0,
//                'Agency.id not in (1,17,19,20,21,22,26,12,28,31,32,35,36,37,39,40,46)',
            ],
        ]);
        for($i = 0; $i < count($rsGame); $i++){
            $rsGame[$i]['Agency']['id'] = $i + 1;
        }
//        shuffle($rsGame);
        echo json_encode($rsGame);
        die;
    }
    public function getcard(){

        $rsGame = $this->Card->find("all", [
            'order' => 'gold',
        ]);

        echo json_encode($rsGame);
        die;
    }

    public function getChat(){
        header('Content-type: application/json');
        header('Access-Control-Allow-Origin: *');

        $rsGame = $this->KpiUserChat->find("all",[
            'fields' => [
                // 'username'
                'playerid'
            ],
            'conditions' => [
                'id >' => 29302,
            ],
        ]);
        pr($rsGame);
        $rsGame = $this->Agency->find("all", [
            'fields' => [
                'id',
                'name',
                'userid',
                'address',
                'phone',
                'face',
                'num',
                'displayname',
                'parent'
            ],
            'conditions' => [
                'Agency.id not in (1,17,19,20,21,22,26,12,28,31,32,35,36,37,39,40,46)',
            ],
        ]);
        pr($rsGame);
//        for($i = 0; $i < count($rsGame); $i++){
//            $rs[$i] =   $rsGame[$i]['kpi_user_chats']['chat'];
//        }

        echo json_encode($rsGame);

        die;
    }

    public function getTopTX(){

        $param = $this->request->query;
        if (!isset($param['day'])){
            $result = array('error' => 1, 'mess' => "Thieu param", 'data' => []);
            echo json_encode($result);
            die;
        }
        $day = $param['day'];

        $rsGame = $this->Card->query("select id, displayname as displayName, rank, value as goldWin from taixiu_ranking_by_day where type_rank = 3 and day = '". addslashes($day)."' order by rank");
        $result = array('error' => 0, 'mess' => "Thanh cong", 'data' => $rsGame);
        echo json_encode($result);
        die;
    }
    public function gameInfo()
    {
        $param = $this->request->query;
        CakeLog::write('GameManagerController', 'game info: ' . json_encode($param));
        if (
            !isset($param['game']) ||
            !isset($param['os']) ||
            !isset($param['versionCode']) ||
            !isset($param['mode']) ||
            !isset($param['versionName']) ||
            !isset($param['deviceId']) ||
            !isset($param['installDate']) ||
            !isset($param['osVersion']) ||
            !isset($param['gameVersion'])
        ) {

            $result = array('error' => 1, 'mess' => "Game không tồn tại ---- !");
            CakeLog::write('GameManagerController', 'Retrn Error miss some param');
            echo json_encode($result);
            die;
        }

        $game = $param["game"];
        $os = $param["os"];
        $versionCode = $param["versionCode"];
        $mode = $param["mode"];
        $versionName = $param["versionName"];
        $deviceId = $param["deviceId"];
        $installDate = $param["installDate"];
        $osVersion = $param['osVersion'];
        $gameVersion = $param['gameVersion'];

        if($os == "ios" || $os == "android") {
            $rsGame = $this->GameManager->find("first", [
                'conditions' => [
                    'GameManager.game' => $game,
                    'GameManager.mode' => $mode,
                    'GameManager.gameversion' => $gameVersion,
                    'GameManager.typeOS' => $os,
                ]
            ]);
        }else{
            $rsGame = $this->GameManager->find("first", [
                'conditions' => [
                    'GameManager.game' => $game,
                    'GameManager.mode' => $mode,
//                'GameManager.gameVersion' => $gameVersion,
//                    'GameManager.typeOS' => $os,
                ]
            ]);
        }


        //Nếu không có game tương ứng thì thông báo lỗi.
        if (count($rsGame) == 0) {
            $result = array('error' => 1, 'mess' => "Game không tồn tại!--");
            CakeLog::write('GameManagerController', 'Return Error game ko ton tai');
            echo json_encode($result);
            die;
        }

        $rsDevice = $this->DeviceManager->find("first", [
            'conditions' => [
                'DeviceManager.game' => $game,
                'DeviceManager.deviceid' => $deviceId,
            ]
        ]);

        //Nếu đã có rồi thì update. Không thì thêm mới.
        if (count($rsDevice) > 0) {
            $this->DeviceManager->save([
                'id' => $rsDevice['DeviceManager']['id'],
                'versioncode' => $versionCode,
                'versionname' => $versionName,
                'osversion' => $osVersion,
                'installdate' => date('Y-m-d h:i:s', $installDate),
            ]);
        } else {
            $this->DeviceManager->save(array('game' => $game, 'deviceid' => $deviceId, 'os' => $os,
                'gameversion' => $gameVersion,
                'versioncode' => $versionCode, 'versionname' => $versionName,
                'osversion' => $osVersion, 'installdate' => date('Y-m-d h:i:s', $installDate)));
        }

        $games = new Games();

        //Dữ liệu trả về
        //Nếu versionGame hiện tại của game nhỏ hơn versionGame trên server thì update
        if ($gameVersion < $rsGame['GameManager']['gameversion'])
            $games->update = 1;

        $games->ipServer = $rsGame['GameManager']['ipserver'];
        $games->portServer = $rsGame['GameManager']['portserver'];
        $games->location = $rsGame['GameManager']['location'];
        $games->maintain = $rsGame['GameManager']['maintain'];
        $games->maintainMessage = $rsGame['GameManager']['maintainmessage'];
        $games->support = $rsGame['GameManager']['support'];
        $games->forumUrl = $rsGame['GameManager']['forumurl'];
        $games->urlnews = $rsGame['GameManager']['urlnews'];
        $games->linkStore = $rsGame['GameManager']['linkstore'];
        $games->hasTournament = $rsGame['GameManager']['hastournament'];
        $games->canLikePage = $rsGame['GameManager']['canlikepage'];
        $games->canRegister = $rsGame['GameManager']['canregister'];
        $games->isReview = $rsGame['GameManager']['isreview'];
        $games->typeOS = $os;
        $games->login = explode(",", $rsGame['GameManager']['login']);
//        $location = $this->getLocation();
//        echo $location;
        $location = "VN";
        if($location == "VN") {
            $games->payment = $rsGame['GameManager']['payment'];
        }else{
            $games->payment = "iap";
        }
        $games->canRateGame = $rsGame['GameManager']['canrategame'];

        echo json_encode($games);
        die;

    }
}

