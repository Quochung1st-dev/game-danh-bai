<?php

/**
 * User: ChungPD
 * Date: 9/6/16
 * Time: 14:19
 */
App::uses("Component", "Component");

class PushNotificationComponent extends Component
{
    public function pushIos($arr_token, $data)
    {
        $msg = [
            "type" => 0,
            "msg" => "System Error",
            "id" => ""
        ];

        $ctx = stream_context_create();
        stream_context_set_option($ctx, 'ssl', 'local_cert', APP . "Vendor" . DS . "ios_key" . DS . "hv_pro.pem");
        stream_context_set_option($ctx, 'ssl', 'passphrase', '123456');
        stream_context_set_option($ctx, 'ssl', 'cafile', APP . "Vendor" . DS . "ios_key" . DS . "entrust_2048_ca.cer");


//        $urlServer = 'ssl://gateway.sandbox.push.apple.com:2195';
        $urlServer = 'ssl://gateway.push.apple.com:2195';

        // Open a connection to the APNS server
        $fp = stream_socket_client($urlServer, $err, $errstr, 60, STREAM_CLIENT_CONNECT | STREAM_CLIENT_PERSISTENT, $ctx);
        stream_set_blocking($fp, 0); //This allows fread() to return right away when there are no errors. But it can also miss errors during last seconds of sending, as there is a delay before error is returned. Workaround is to pause briefly AFTER sending last notification, and then do one more fread() to see if anything else is there.

        if (!$fp) {
            return $msg;
        }

        // Create the payload body
        $body['aps'] = array(
            "content-available" => 0,
            'alert' => [
                "title" => $data["msg"],
                "body" => $data["body"]
            ],
            "type" => $data["type"],
            "parent_id" => $data["parent_id"],
            "created" => date("d/m/Y")
//            "badge" => 1
        );

        $apple_expiry = time() + (90 * 24 * 60 * 60); //Keep push alive (waiting for delivery) for 90 days

        foreach ($arr_token as $key => $value) {
            $apple_identifier = 'com.gamebai.heyvip';
            $deviceToken = trim($value);
            // Encode the payload as JSON
            $payload = json_encode($body);
            // Build the binary notification
            $msg1 = pack("C", 1) . pack("N", $apple_identifier) . pack("N", $apple_expiry) . pack('n', 32) . pack('H*', $deviceToken) . pack('n', strlen($payload)) . $payload;
            // Send it to the server
            fwrite($fp, $msg1, strlen($msg1));
            //We can check if an error has been returned while we are sending, but we also need to check once more after we are done sending in case there was a delay with error response.
            if ($this->checkAppleErrorResponse($fp)) {
                break;
            }
        }

        //Workaround to check if there were any errors during the last seconds of sending.
        sleep(1); //Pause for half a second. Note I tested this with up to a 5 minute pause, and the error message was still available to be retrieved
        $errorId = $this->checkAppleErrorResponse($fp);

        // Close the connection to the server
        fclose($fp);
        if ($errorId){
            return [
                "type" => 0,
                "msg" => "Invalid Token",
                "id" => $errorId
            ];
        }
        return [
            "type" => 1,
            "msg" => "Success",
            "id" => ""
        ];
    }

    function base64($data) {
        return rtrim(strtr(base64_encode(json_encode($data)), '+/', '-_'), '=');
    }

    function pushIOSNew($arr_token, $data){

        $a = gmp_init(123456);
        echo $a;
        $msg = [
            "type" => 0,
            "msg" => "System Error",
            "id" => ""
        ];

        $keyfile =  APP . "Vendor" . DS . "ios_key" . DS . "AuthKey_ZU2Q9YAJDP.p8";               # <- Your AuthKey file
        $keyid = 'ZU2Q9YAJDP';                            # <- Your Key ID
        $teamid = 'C5XU2UY8UR';                           # <- Your Team ID (see Developer Portal)
        $bundleid = 'com.hey.club';                # <- Your Bundle ID
        $url = 'https://api.development.push.apple.com';  # <- development url https://api.development.push.apple.com, or use http://api.push.apple.com for production environment

        // Create the payload body
        $message['aps'] = '{"aps":{"alert":"Hi there!","sound":"default"}}';



        $key = openssl_pkey_get_private('file://'.$keyfile);

        $header = ['alg'=>'ES256','kid'=>$keyid];
        $claims = ['iss'=>$teamid,'iat'=>time()];

        $header_encoded = $this->base64($header);
        $claims_encoded = $this->base64($claims);

        $signature = '';
        openssl_sign($header_encoded . '.' . $claims_encoded, $signature, $key, 'sha256');
        $jwt = $header_encoded . '.' . $claims_encoded . '.' . base64_encode($signature);

        // only needed for PHP prior to 5.5.24
        if (!defined('CURL_HTTP_VERSION_2_0')) {
            define('CURL_HTTP_VERSION_2_0', 3);
        }
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_HTTP_VERSION, CURL_HTTP_VERSION_2_0);
        $url = "https://api.development.push.apple.com/3/device/c66af3cbfa06f057fa908390e6130e25009446f10c8123999c6bb7acbcce0166";

        curl_setopt_array($ch, array(
            CURLOPT_URL => $url,
            CURLOPT_PORT => 443,
            CURLOPT_HTTPHEADER => array(
                "apns-topic: {$bundleid}",
                "authorization: Bearer $jwt"
            ),
            CURLOPT_POST => TRUE,
            CURLOPT_POSTFIELDS => $message,
            CURLOPT_RETURNTRANSFER => TRUE,
            CURLOPT_TIMEOUT => 30,
            CURLOPT_HEADER => 1
        ));


        $result = curl_exec($ch);
        pr(curl_error($ch));
        if ($result === FALSE) {
            throw new Exception("Curl failed: ".curl_error($ch));
        }
        $status = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        echo $status;
        foreach ($arr_token as $key => $value) {


            break;
        }
        curl_close($ch);
//
//        if ($errorId){
//            return [
//                "type" => 0,
//                "msg" => "Invalid Token",
//                "id" => $errorId
//            ];
//        }
        return [
            "type" => 1,
            "msg" => "Success",
            "id" => ""
        ];
    }

    //FUNCTION to check if there is an error response from Apple
//         Returns TRUE if there was and FALSE if there was not
    function checkAppleErrorResponse($fp)
    {

        //byte1=always 8, byte2=StatusCode, bytes3,4,5,6=identifier(rowID). Should return nothing if OK.
        $apple_error_response = fread($fp, 6);
        //NOTE: Make sure you set stream_set_blocking($fp, 0) or else fread will pause your script and wait forever when there is no response to be sent.

        if ($apple_error_response) {
            //unpack the error response (first byte 'command" should always be 8)
            $error_response = unpack('Ccommand/Cstatus_code/Nidentifier', $apple_error_response);

            if ($error_response['status_code'] == '0') {
                $error_response['status_code'] = '0-No errors encountered';
            } else if ($error_response['status_code'] == '1') {
                $error_response['status_code'] = '1-Processing error';
            } else if ($error_response['status_code'] == '2') {
                $error_response['status_code'] = '2-Missing device token';
            } else if ($error_response['status_code'] == '3') {
                $error_response['status_code'] = '3-Missing topic';
            } else if ($error_response['status_code'] == '4') {
                $error_response['status_code'] = '4-Missing payload';
            } else if ($error_response['status_code'] == '5') {
                $error_response['status_code'] = '5-Invalid token size';
            } else if ($error_response['status_code'] == '6') {
                $error_response['status_code'] = '6-Invalid topic size';
            } else if ($error_response['status_code'] == '7') {
                $error_response['status_code'] = '7-Invalid payload size';
            } else if ($error_response['status_code'] == '8') {
                $error_response['status_code'] = '8-Invalid token';
            } else if ($error_response['status_code'] == '255') {
                $error_response['status_code'] = '255-None (unknown)';
            } else {
                $error_response['status_code'] = $error_response['status_code'] . '-Not listed';
            }

//            echo '<br><b>+ + + + + + ERROR</b> Response Command:<b>' . $error_response['command'] . '</b>&nbsp;&nbsp;&nbsp;Identifier:<b>' . $error_response['identifier'] . '</b>&nbsp;&nbsp;&nbsp;Status:<b>' . $error_response['status_code'] . '</b><br>';
//            echo 'Identifier is the rowID (index) in the database that caused the problem, and Apple will disconnect you from server. To continue sending Push Notifications, just start at the next rowID after this Identifier.<br>';

            return $error_response['identifier'];
        }
        return false;
    }

    public  function pushAndroid($arr_token, $data)
    {
        $msg = [
            "type" => 0,
            "msg" => "System Error"
        ];

        // Set POST variables
        //$url = 'https://android.googleapis.com/gcm/send';
        $url = 'https://android.googleapis.com/gcm/send';

        $result = array();

        // Open connection

        foreach ($arr_token as $value) {
            $ch = curl_init();
            $fields = array(
                'registration_ids' => array($value),
                'notification' => array(
                    'message' => $data["msg"],
                    "body" => $data["body"],
                    "type" => "0",
                    "parent_id" => "0",
                    "created" => ""
                ),
            );

            $headers = array('Authorization: key=' . GOOGLE_GCM_KEY, 'Content-Type: application/json');

            // Set the url, number of POST vars, POST data
            curl_setopt($ch, CURLOPT_URL, $url);

            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);

            // Disabling SSL Certificate support temporarly
            curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);

            curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($fields));

            // Execute post
            $result[] = curl_exec($ch);
            echo $value;
            pr($result);
            // Close connection
            curl_close($ch);
            sleep(1);
        }

        foreach ($result as $key => $value) {
            if ($value) {
                $arr_res = json_decode($value, true);
                if ($arr_res["success"] > 0) {
                    $msg["type"] = 1;
                    $msg["msg"] = 'Success!';
                }
            }
        }
        return $msg;
    }
}