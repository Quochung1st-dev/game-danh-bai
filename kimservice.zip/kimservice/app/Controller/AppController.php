<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

App::uses('Controller', 'Controller');

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {

    private $HTTP_ORIGIN = ['https://kimvip.org','https://www.kimvip.org','https://taikim.net', 'http://sill.vip', 'http://sub.sill.vip'];
    public function beforeFilter()
    {
        parent::beforeFilter();
        if (!in_array($this->request->params['controller'], ['Listcard', 'HostUpdates', 'Telegram', 'adminmanager'])
            && !in_array($this->request->params['action'], ['getDLotp', 'verifyDLcode', 'admin_send_gold', 'adminconfig',
                'admin_maintain', 'checkThenAdd', 'checkthenadd', 'agencysendgold','dlTraHey','dlThuHoiHey', 'dlNhanHey', 'returngold',
                'sendgold','checkThenAddSpecial','admin_ban_user', 'admin_kick_user',
                ]
            )) {
            if ($this->request->is('mobile') == false)
            $this->header_request();
        }
    }
    public function header_request(){
        header('Content-type: application/json');
        if (!isset($_SERVER['HTTP_ORIGIN'])) {
            die;
        }
        $http_origin = $_SERVER['HTTP_ORIGIN'];
        if (in_array($http_origin, $this->HTTP_ORIGIN)) {
            header("Access-Control-Allow-Origin: $http_origin");
        }
        else {
            die;
        }
        header('Access-control-allow-credentials: true');
        header('Access-control-allow-headers: Content-Type, Authorization, Accept');
        header('Access-control-allow-methods: POST,GET,OPTIONS,PUT,DELETE');
    }
}
