<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */

App::uses('PaymentPack', 'Model');
App::uses('OutPacket', 'Model');
App::import('Vendor', 'epay/Entries');
//App::import('Vendor', 'epay/libs/nusoap');
ini_set('display_errors', '1');

class EPayCardController extends AppController
{
    public $uses = ['User', 'PaymentEpay'];

    function requestcard(){
        $param = $this->request->query;
        CakeLog::write('EPayCardController', json_encode($param));
        if (!isset($param['card_type']) ||
            !isset($param['pin']) ||
            !isset($param['seri']) ||
            !isset($param['userID'])
        ) {
            return array('status' => 1, 'data' => "Thieu param");
        } else {
            $webservice = E_webservice;
            $soapClient = new SoapClient(null, array('location' => $webservice, 'uri' => E_webservice_uri));

            $card_type = $param["card_type"];
            $pin = $param["pin"];
            $seri = $param["seri"];
            $userID = $param["userID"];
//            $this->CardCharging($soapClient, "9555105814645", "58240601618", "VTT", "Username123");
            return $this->CardCharging($soapClient, $seri, $pin, $card_type, $userID);
        }
    }

    private function CardCharging($soapClient, $serial, $pin, $card_type, $userID)
    {
//        echo $card_type;
        $serviceProvider = "VTT";
        if($card_type == 1){
            $serviceProvider = "VTT";
        }else if($card_type == 2){
            $serviceProvider = "VNP";
        }else{
            $serviceProvider = "VMS";
        }
        //if($CardCharging == null)
        //$CardCharging = new CardCharging();
        $m_PartnerID = E_PartnerID;
        $m_MPIN = E_MPIN;
        $m_UserName = E_UserName;
        $m_Pass = E_Pass;
        $m_PartnerCode = E_PartnerCode;
        //Ten tai khoan nguoi dung tren he thong doi tac
        $m_Target = E_Target;

        $CardCharging = new CardCharging();
        $CardCharging->m_UserName = $m_UserName;
        $CardCharging->m_PartnerID = $m_PartnerID;
        $CardCharging->m_MPIN = $m_MPIN;
        $CardCharging->m_Target = $m_Target;
        $CardCharging->m_Card_DATA = $serial.":".$pin.":"."0".":".$serviceProvider;
        $CardCharging->m_SessionID = "";
        $CardCharging->m_Pass  = $m_Pass;
        $CardCharging->soapClient = $soapClient;

        $transid = $m_PartnerCode.date("YmdHms");//gen transaction id

        $CardCharging -> m_TransID = $transid;
//        echo "<br/>Transaction id: ".$transid."<br/>";
//        var_dump($CardCharging);
//        print_r($CardCharging -> m_SessionID);
        $CardChargingResponse = new CardChargingResponse();
        $CardChargingResponse = $CardCharging->CardCharging_();
//        print_r($CardChargingResponse);
        //Xu ly cong tien
        CakeLog::write('EPayCardController', json_encode($CardChargingResponse));
        $this->PaymentEpay->save(array(
            'userid' => $userID,
            'card_type' => $serviceProvider,
            'seri' => $serial,
            'pin' => $pin,
            'code' => $CardChargingResponse->m_Status,
            'transaction' => $CardChargingResponse->m_TRANSID,
            'mess' => $CardChargingResponse->m_Message,
            'card_amount' => $CardChargingResponse->m_RESPONSEAMOUNT,
            'created' => date("Y-m-d"),

        ));

        $checkSokcet = false;
        //Open socket to server
        if ($this->socket == null) {
            $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        }
        if ($this->socket === false) {
            $checkSokcet = false;
        } else {
            $checkSokcet = true;
        }

        $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
        if ($result === false) {
            $checkSokcet = false;
        } else {
            $checkSokcet = true;
        }

//    $CardChargingResponse->m_Status = 1;
//    $CardChargingResponse->m_RESPONSEAMOUNT = 10000;
        $isTest = false;
        if($CardChargingResponse->m_Status == 1 || $isTest)
        {
            $arr =  array(1, 'Thanh cong1');
            //The OK Array ( [code] => 1 [message] => Náº¡p tháº» thÃ nh cÃ´ng [txn_id] => ac4qmetbbsv61498533575 [card_amount] => 10000 [net_amount] => 7800 )
            $p = new OutPacket(1, PAYMENT_MAX_PAY);
            $p->putInt(CARD);
            $p->putInt($card_type);
            $p->putString("ecard");
            $p->putString("ecard");
            $p->putLong($CardChargingResponse->m_RESPONSEAMOUNT);
            $p->putLong($userID);
            $p->putString(php_secret_key);
            $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
            $pckLen = strlen($packet);
            socket_write($this->socket, $packet, $pckLen);
            socket_close($this->socket);
            CakeLog::write('EPayCardController', $card_type . '|'. $CardChargingResponse->m_RESPONSEAMOUNT. '|'. $userID);
        }else{
            $arr =  array(1, 'Thanh cong2');
            $p = new OutPacket(1, PAYMENT_MAX_PAY);
            $p->putInt(-1);
            $p->putInt(-1);
            $p->putString("ecard");
            $p->putString("ecard");
            $p->putLong(0);
            $p->putLong($userID);
            $p->putString(php_secret_key);
            $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
            $pckLen = strlen($packet);
            socket_write($this->socket, $packet, $pckLen);
            socket_close($this->socket);
            CakeLog::write('EPayCardController', -1 . '|'. 0 . '|'. $userID);
        }


        return $arr;

//        print_r("Ket qua thuc hien giao dich-Transaction result: ");
//        echo "</br>";
//        print_r("Transaction status: ".$CardChargingResponse->m_Status);
//        echo "</br>";
//        print_r("Menh gia tra ve-response amount: ".$CardChargingResponse->m_RESPONSEAMOUNT);
//        echo "</br>";
//        print_r("Transaction ID: ".$CardChargingResponse->m_TRANSID);
//        echo "<br/>----------------Charging finish-----------------------<br/>";

    }
}
