<?php
App::uses('AppController', 'Controller');
/**
 * BotGames Controller
 *
 * @property BotGame $BotGame
 * @property PaginatorComponent $Paginator
 */
date_default_timezone_set('Asia/Ho_Chi_Minh');
class BotGamesController extends AppController {


    public function genBotGame(){
        $bot = $this->BotGame->find("all", [
            'fields'=>array('BotGame.user_name'=>'user_name', 'BotGame.avatar'=>'avatar'),
            'order' => 'rand()',
            'limit' => 1000

        ]);

        echo json_encode($bot);

        die;

    }

    public function genAvatar($url){
        $user_details = $url."&redirect=false";
        $response = file_get_contents($user_details);
        $response = json_decode($response);
        if(!empty($response->data->url)){
            echo $response->data->url;
            return $response->data->url;
        }
        return "";

    }

    function addBot(){
        $row = 1;

        if (($handle = fopen(APP . "webroot/users.csv", "r")) !== FALSE) {
            while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
                $num = count($data);
                $row++;
                $pos = strpos($data[7], "graph.facebook.com");
                if($pos != null) {
                    $urlAvatar = $this->genAvatar($data[7]);
                    if(!empty($urlAvatar)) {
                        $this->BotGame->create();
                        $this->BotGame->save(array(
                            "fbid" => $data[1],
                            "user_name" => $data[3],
                            "avatar" => $urlAvatar,
                            "avatar_default" => $data[7],
                            "created" => time()
                        ));
                    }
                }
                echo $row;
                echo "<br />";
            }
            fclose($handle);
        }
        die;
    }
}
