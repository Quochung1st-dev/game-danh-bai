<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 6/27/2017
 * Time: 5:12 PM
 */

date_default_timezone_set('Asia/Ho_Chi_Minh');
App::uses('OutPacket', 'Model');
App::uses('Security', 'Utility');
class AdminManagerController extends AppController
{
    public $uses = ['User', 'SendMail', 'SendGold', 'SendBan'];
    public $components = ['PushNotification'];
    private $socket;

    private $CODE_SEND_MAIL_FOR_USER = 1;
    private $CODE_SEND_MAIL_FOR_ALL_USER = 2;
    private $CODE_ADD_GOLD = 3;
    private $CODE_BAN_USER_BY_USERNAME = 4;
    private $CODE_BAN_USER_BY_IP = 5;
    private $CODE_UNBAN_USER_BY_USERNAME = 6;
    private $CODE_UNBAN_USER_BY_IP = 7;
    private $CODE_UPDATE_GOLD = 8;
    private $CODE_SEND_NOTIFICATION = 9;
    private $CODE_SERVER_MAINTAIN = 10;
    private $CODE_KICK_USER = 11;
    private $CODE_KICK_ALL_USER = 12;
    private $CODE_RELOAD_CONFIG = 13;
    private $CODE_BOT_JACKPOT_BROKEN = 14;
    private $CODE_DIAMOND_BOT_JACKPOT_BROKEN = 15;
    private $CODE_DIAMOND_NEW_BOT_JACKPOT_BROKEN = 17;
    private $CODE_TAI_XIU_BOT_CONFIG = 18;
    private $CODE_SEND_MAIL_CODE = 31;

    private $debug = true;



    public function pushNotification(){

        $param = $this->request->query;
        CakeLog::write('MaxpayController', "pushNotification " . json_encode($param));
        if (!isset($param['content']) ||
            !isset($param['title']) ||
            !isset($param['token'])
        ) {

        }else {
            $d = Security::hash( $param['title'] . "+" . $param['content'] . "+" . KEY_ENCODE, "sha256");
            if ($d == $param['token'] || $this->debug) {
                $data['msg'] = $param['title'];
                $data['body'] = $param['content'];
                $data['type'] = '';
                $data['parent_id'] = '';
                $data['d/m/Y'] = '';


                $IOS = 1;
                $ANDROID = 2;

                //push android
                $user = $this->User->find("all", [
                    'conditions' => [
                        'User.typeOS' => $ANDROID,
                        'char_length(User.deviceToken) >' => 10,

                    ]
                ]);

                $arrToken = null;
                for($i = 0; $i< count($user); $i++){
                    $arrToken[$i] = $user[$i]['User']['deviceToken'];

                }
                if($arrToken != null)
                    $this->PushNotification->pushAndroid($arrToken, $data);


                //push ios
                $userIOS = $this->User->find("all", [
                    'conditions' => [
                        'User.typeOS' => $IOS,
                        'char_length(User.deviceToken) >' => 10,

                    ]
                ]);
                $arrToken = null;
                for($i = 0; $i< count($userIOS); $i++){
                    $arrToken[$i] = $userIOS[$i]['User']['deviceToken'];
                }
                if($arrToken != null)
                    $this->PushNotification->pushIos($arrToken, $data);
            }
        }
        echo 'Thanh cong';

        die;

    }

    public function adminconfig(){
        $param = $this->request->query;
        CakeLog::write('MaxpayController', 'admin_jackpot OutPacket ' . json_encode($param));
        if (
            !isset($param['content']) ||
            !isset($param['code']) ||
            !isset($param['token'])
        ) {
            echo "vai dai";
        }
        else{
            $d = Security::hash( $param['content'] . "+" . $param['code'] . "+" . KEY_ENCODE, "sha256");
            if ($d == $param['token'] || $this->debug) {
                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }

                if ($param['code'] == 1) {//admin_jackpot
                    $data = json_decode(urldecode($param['content']), true);

                    $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                    $p->putInt("");//Loai the card thanh cong
                    if ($data['gameid'] == 13) {
                        $p->putInt($this->CODE_BOT_JACKPOT_BROKEN);//code
                    } else if ($data['gameid'] == 14) {
                        $p->putInt($this->CODE_DIAMOND_BOT_JACKPOT_BROKEN);//code
                    } else if ($data['gameid'] == 16) {
                        $p->putInt($this->CODE_DIAMOND_NEW_BOT_JACKPOT_BROKEN);//code
                    }
                    $p->putInt($data['spinfe']);//gold
                    $p->putString($data['displayname']);
                    $p->putString("");
                    $p->putString(php_secret_key);
                    $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                    $pckLen = strlen($packet);
                    socket_write($this->socket, $packet, $pckLen);

                } else if ($param['code'] == 2) {//admin_reload_config_slot 19

                    $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                    $p->putInt("");//Loai the card thanh cong
                    $p->putInt(19);//code
                    $p->putInt(0);//gold
                    $p->putString("");
                    $p->putString(urldecode($param['content']));
                    $p->putString(php_secret_key);
                    $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                    $pckLen = strlen($packet);
                    socket_write($this->socket, $packet, $pckLen);

                } else if ($param['code'] == 3) {//admin_reload_config_slot 20
                    $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                    $p->putInt("");//Loai the card thanh cong
                    $p->putInt(20);//code
                    $p->putInt(0);//gold
                    $p->putString("");
                    $p->putString(urldecode($param['content']));
                    $p->putString(php_secret_key);
                    $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                    $pckLen = strlen($packet);
                    socket_write($this->socket, $packet, $pckLen);
                } else if ($param['code'] == 4) {//admin_reload_config_slot 21
                    $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                    $p->putInt("");//Loai the card thanh cong
                    $p->putInt(21);//code
                    $p->putInt(0);//gold
                    $p->putString("");
                    $p->putString(urldecode($param['content']));
                    $p->putString(php_secret_key);
                    $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                    $pckLen = strlen($packet);
                    socket_write($this->socket, $packet, $pckLen);
                } else if ($param['code'] == 5) {//Mini slot
                    $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                    $p->putInt("");//Loai the card thanh cong
                    $p->putInt($this->CODE_RELOAD_CONFIG);//code

                    $p->putInt(0);//gold
                    $p->putString("");
                    $p->putString(urldecode($param['content']));
                    $p->putString(php_secret_key);

                    $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                    $pckLen = strlen($packet);
                    socket_write($this->socket, $packet, $pckLen);
                } else if ($param['code'] == 6) {//tai xiu con fig
                    $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                    $p->putInt("");//Loai the card thanh cong
                    $p->putInt($this->CODE_TAI_XIU_BOT_CONFIG);//code

                    $p->putInt(0);//gold
                    $p->putString("");
                    $p->putString(($param['content']));
                    $p->putString(php_secret_key);

                    CakeLog::write('MaxpayController', 'admin_reload_config_taixiu OutPacket ' . json_encode($p));

                    $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                    $pckLen = strlen($packet);
                    socket_write($this->socket, $packet, $pckLen);
                }
                socket_close($this->socket);
                $this->socket = null;
                echo "thanhh cong";
            }else{
                echo "Loi bao mat";
            }

        }
        die;

    }

    public function send_mail_code(){
        $param = $this->request->query;
        CakeLog::write('MaxpayController', "send_mail_code " . json_encode($param));
        $envet = $param['event'];
        $checkSokcet = false;
        //Open socket to server
        if ($this->socket == null) {
            $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
            $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
        }
        if ($this->socket === false) {
            $checkSokcet = false;

        } else {
            $checkSokcet = true;
        }

        if ($result === false) {
            $checkSokcet = false;
        } else {
            $checkSokcet = true;
        }
        $p = new OutPacket(1, GAME_ADMIN_REQUEST);
        $p->putInt($envet);//Loai the card thanh cong
        $p->putInt($this->CODE_SEND_MAIL_CODE);//code

        $p->putInt(0);//gold
        $p->putString("");
        $p->putString("");
        $p->putString(php_secret_key);

//        CakeLog::write('MaxpayController', 'send_mail_code OutPacket ' . json_encode($p));

        $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
        $pckLen = strlen($packet);
        socket_write($this->socket, $packet, $pckLen);
        socket_close($this->socket);
        $this->socket = null;

        echo "thanh cong";
        die;
    }

    public function admin_jackpot(){

        $param = $this->request->query;
        CakeLog::write('MaxpayController', "admin_jackpot " . json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (!isset($param['gold']) ||
            !isset($param['username']) ||
            !isset($param['type']) ||
            !isset($param['token'])
        ) {

        }else {
            $d = Security::hash( $param['gold'] . "+" . $param['username'] . "+" .$param['username'] . "+" . KEY_ENCODE, "sha256");
            if ($d == $param['token'] || $this->debug) {

                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt("");//Loai the card thanh cong
                if($param['type'] == 1) {
                    $p->putInt($this->CODE_BOT_JACKPOT_BROKEN);//code
                }else if($param['type'] == 2){
                    $p->putInt($this->CODE_DIAMOND_BOT_JACKPOT_BROKEN);//code
                }else if($param['type'] == 3){
                    $p->putInt($this->CODE_DIAMOND_NEW_BOT_JACKPOT_BROKEN);//code
                }

                $p->putInt($param['gold']);//gold
                $p->putString($param['username']);
                $p->putString("");
                $p->putString(php_secret_key);

                CakeLog::write('MaxpayController', 'admin_jackpot OutPacket ' . json_encode($p));

                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
                $this->socket = null;

                echo "thanh cong";
            }
        }

        die;
    }

    public function admin_reload_config_slot(){

        $param = $this->request->query;
        CakeLog::write('MaxpayController', "admin_reload_config_taixiu " . json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (
            !isset($param['content']) ||
            !isset($param['code']) ||
            !isset($param['token'])
        ) {

        }else {
            $d = Security::hash($param['content'] . "+" . "+" . KEY_ENCODE, "sha256");
            if ($d == $param['token'] || $this->debug) {

                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt("");//Loai the card thanh cong
                $p->putInt($param['code']);//code

                $p->putInt(0);//gold
                $p->putString("");
                $p->putString($param['content']);
                $p->putString(php_secret_key);

                CakeLog::write('MaxpayController', 'admin_reload_config_slot OutPacket ' . json_encode($p));

                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
                $this->socket = null;

                echo "thanh cong";
            }
        }

        die;
    }

    public function admin_reload_config_taixiu(){

        $param = $this->request->query;
        CakeLog::write('MaxpayController', "admin_reload_config_taixiu " . json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (
            !isset($param['content']) ||
            !isset($param['token'])
        ) {

        }else {
            $d = Security::hash($param['content'] . "+" . "+" . KEY_ENCODE, "sha256");
            if ($d == $param['token'] || $this->debug) {

                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt("");//Loai the card thanh cong
                $p->putInt($this->CODE_TAI_XIU_BOT_CONFIG);//code

                $p->putInt(0);//gold
                $p->putString("");
                $p->putString($param['content']);
                $p->putString(php_secret_key);

                CakeLog::write('MaxpayController', 'admin_reload_config_taixiu OutPacket ' . json_encode($p));

                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
                $this->socket = null;

                echo "thanh cong";
            }
        }

        die;
    }

    public function admin_reload_config(){

        $param = $this->request->query;
        CakeLog::write('MaxpayController', "admin_send_gold " . json_encode($param));
        if (
            !isset($param['content']) ||
            !isset($param['token'])
        ) {

        }else {
            $d = Security::hash($param['content'] . "+" . KEY_ENCODE, "sha256");
            if ($d == $param['token'] || $this->debug) {
                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt("");//Loai the card thanh cong
                $p->putInt($this->CODE_RELOAD_CONFIG);//code

                $p->putInt(0);//gold
                $p->putString("");
                $p->putString($param['content']);
                $p->putString(php_secret_key);

                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
                $this->socket = null;

                echo "thanh cong";
            }
        }

        die;
    }


    public function admin_ban_user(){

        $param = $this->request->query;
        CakeLog::write('MaxpayController', "admin_send_gold " . json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (!isset($param['userid']) ||
            !isset($param['time']) ||
            !isset($param['content']) ||
            !isset($param['type']) ||
            !isset($param['token'])
        ) {

        }else {
            $d = Security::hash($param['userid'] . "+" . $param['time'] .  "+" . $param['content'] . "+" . $param['type'] . "+" . KEY_ENCODE, "sha256");
            if ($d == $param['token'] || $this->debug) {

                //Update database
                $this->SendBan->save(array(
                    'user' => $param['userid'],
                    'time' => $param['time'],
                    'content' => $param['content'],
                    'type' => $param['type'],

                ));
                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt("");//Loai the card thanh cong
                if($param['type'] == 1) {// Ban user
                    $p->putInt($this->CODE_BAN_USER_BY_USERNAME);//code
                }else if($param['type'] == 2){// Ban Ip
                    $p->putInt($this->CODE_BAN_USER_BY_IP);//code
                }else if($param['type'] == 3){//un Ban username
                    $p->putInt($this->CODE_UNBAN_USER_BY_USERNAME);//code
                }else if($param['type'] == 4){// unBan Ip
                    $p->putInt($this->CODE_UNBAN_USER_BY_IP);//code
                }

                $p->putInt($param['time']);//gold
                $p->putString($param['userid']);
                $p->putString($param['content']);
                $p->putString(php_secret_key);

                CakeLog::write('MaxpayController', 'admin_send_gold OutPacket ' . json_encode($p));

                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
                $this->socket = null;

                echo "thanh cong";
            }
        }

        die;
    }


    public function admin_send_gold(){
        $param = $this->request->query;
        CakeLog::write('MaxpayController', "admin_send_gold " . json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (!isset($param['userid']) ||
            !isset($param['gold']) ||
            !isset($param['title']) ||
            !isset($param['content']) ||
            !isset($param['token'])
        ) {
            echo "thieu param";
        }else {
            $d = Security::hash($param['userid'] . "+" . $param['title'] .  "+" . $param['gold'] . "+" . $param['content'] . "+" . KEY_ENCODE, "sha256");
            if ($d == $param['token'] || $this->debug) {

                //Update database
                $this->SendGold->save(array(
                    'user_id' => $param['userid'],
                    'gold' => $param['gold'],
                    'title' => $param['title'],
                    'content' => $param['content'],

                ));
                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt($param['userid']);//Loai the card thanh cong
                if($param['type'] == 1)
                    $p->putInt($this->CODE_ADD_GOLD);//code
                else
                    $p->putInt($this->CODE_UPDATE_GOLD);//code
                $p->putInt($param['gold']);//gold
                $p->putString($param['title']);
                $p->putString($param['content']);
                $p->putString(php_secret_key);

                CakeLog::write('MaxpayController', 'admin_send_gold OutPacket ' . json_encode($p));

                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
                $this->socket = null;

                echo "thanh cong";
            }
        }

        die;
    }

    public function admin_maintain(){

        $param = $this->request->query;
        CakeLog::write('MaxpayController', "admin_maintain " . json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (
            !isset($param['time']) ||
            !isset($param['content']) ||
            !isset($param['token'])
        ) {

        }else {
            $d = Security::hash($param['time'] . "+" . $param['content'] . "+" . KEY_ENCODE, "sha256");
            if ($d == $param['token'] || $this->debug) {

                //Update database
//                $this->SendGold->save(array(
//                    'user_id' => $param['userid'],
//                    'gold' => $param['gold'],
//                    'title' => $param['title'],
//                    'content' => $param['content'],
//
//                ));
                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt(0);
                $p->putInt($this->CODE_SERVER_MAINTAIN);//code
                $p->putInt($param['time']);//gold
                $p->putString("");
                $p->putString($param['content']);
                $p->putString(php_secret_key);

                CakeLog::write('MaxpayController', 'admin_maintain OutPacket ' . json_encode($p));

                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
                $this->socket = null;

                echo "thanh cong";
            }
        }

        die;
    }

    public function admin_kick_all_user(){

        $param = $this->request->query;
        CakeLog::write('MaxpayController', "admin_kick_all_user " . json_encode($param));

        $curDate = date("Y-m-d H:i:s");
//        if (
//            !isset($param['content']) ||
//            !isset($param['token'])
//        ) {
//            echo "thieu param";
//        }else {
//            $d = Security::hash($param['userID'] . "+" . $param['content'] . "+" . KEY_ENCODE, "sha256");
//            if ($d == $param['token'] || $this->debug) {

                //Update database
//                $this->SendGold->save(array(
//                    'user_id' => $param['userid'],
//                    'gold' => $param['gold'],
//                    'title' => $param['title'],
//                    'content' => $param['content'],
//
//                ));
                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt(0);
                $p->putInt($this->CODE_KICK_ALL_USER);//code
                $p->putInt(0);//gold
                $p->putString(HOST_SERVER);
                $p->putString(PORT_SERVER);
                $p->putString(php_secret_key . ".".portal_secret_key. ".".KEY_ENCODE);

                CakeLog::write('MaxpayController', 'admin_kick_user OutPacket ' . json_encode($p));

                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
                $this->socket = null;
                echo json_encode($p);
                echo "thanh cong";
                die;
//            }
//            echo "sai token";
//            die;
//        }

        die;
    }

    public function admin_kick_user(){

        $param = $this->request->query;
        CakeLog::write('MaxpayController', "admin_kick_user " . json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (
            !isset($param['userID']) ||
            !isset($param['content']) ||
            !isset($param['token'])
        ) {

        }else {
            $d = Security::hash($param['userID'] . "+" . $param['content'] . "+" . KEY_ENCODE, "sha256");
            if ($d == $param['token'] || $this->debug) {

                //Update database
//                $this->SendGold->save(array(
//                    'user_id' => $param['userid'],
//                    'gold' => $param['gold'],
//                    'title' => $param['title'],
//                    'content' => $param['content'],
//
//                ));
                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt($param['userID']);
                $p->putInt($this->CODE_KICK_USER);//code
                $p->putInt(0);//gold
                $p->putString("");
                $p->putString($param['content']);
                $p->putString(php_secret_key);

                CakeLog::write('MaxpayController', 'admin_kick_user OutPacket ' . json_encode($p));

                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
                $this->socket = null;

                echo "thanh cong";
            }
        }

        die;
    }

    public function admin_send_mail(){
        $param = $this->request->query;
        CakeLog::write('MaxpayController', "admin_send_mail " . json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (!isset($param['userid']) ||
            !isset($param['title']) ||
            !isset($param['content']) ||
            !isset($param['token'])
        ) {

        }else {
            $d = Security::hash($param['userid'] . "+" . $param['title'] . "+" . $param['content'] . "+" . KEY_ENCODE, "sha256");
            if ($d == $param['token'] || $this->debug) {

                //Update database
                $this->SendMail->save(array(
                    'user_id' => $param['userid'],
                    'title' => $param['title'],
                    'content' => $param['content'],

                ));
                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt($param['userid']);
                $p->putInt($this->CODE_SEND_MAIL_FOR_USER);//code
                $p->putInt(0);//gold
                $p->putString($param['title']);
                $p->putString($param['content']);
                $p->putString(php_secret_key);

                CakeLog::write('MaxpayController', 'admin_send_mail OutPacket ' . json_encode($p));

                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
                $this->socket = null;

                echo "thanh cong";
            }
        }

        die;
    }

    public function admin_send_mail_all_user(){
        $param = $this->request->query;
        CakeLog::write('MaxpayController', "admin_send_mail " . json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (
            !isset($param['title']) ||
            !isset($param['content']) ||
            !isset($param['token'])
        ) {

        }else {
            $d = Security::hash( $param['title'] . "+" . $param['content'] . "+" . KEY_ENCODE, "sha256");
            if ($d == $param['token'] || $this->debug) {

                //Update database
                $this->SendMail->save(array(
                    'user_id' => -1,
                    'title' => $param['title'],
                    'content' => $param['content'],

                ));
                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt(0);
                $p->putInt($this->CODE_SEND_MAIL_FOR_ALL_USER);//code
                $p->putInt(0);//gold
                $p->putString($param['title']);
                $p->putString($param['content']);
                $p->putString(php_secret_key);

                CakeLog::write('MaxpayController', 'admin_send_mail OutPacket ' . json_encode($p));

                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
                $this->socket = null;

                echo "thanh cong";
            }
        }

        die;
    }

    public function admin_send_notification(){
        $param = $this->request->query;
        CakeLog::write('MaxpayController', "admin_send_notification " . json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (!isset($param['title']) ||
            !isset($param['time']) ||
            !isset($param['content']) ||
            !isset($param['token'])
        ) {
            echo "Thieu param";
        }else {
            $d = Security::hash( $param['time']  . '+' .$param['title'] . "+" . $param['content'] . "+" . KEY_ENCODE, "sha256");
            if ($d == $param['token'] || $this->debug) {

                //Update database
//                $this->SendNoti->save(array(
//                    'title' => $param['title'],
//                    'content' => $param['content'],
//
//                ));
                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                    $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;

                } else {
                    $checkSokcet = true;
                }

                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }
                $p = new OutPacket(1, GAME_ADMIN_REQUEST);
                $p->putInt(0);
                $p->putInt($this->CODE_SEND_NOTIFICATION);//code
                $p->putInt($param['time']);//gold
                $p->putString($param['title']);
                $p->putString($param['content']);
                $p->putString(php_secret_key);

                CakeLog::write('MaxpayController', 'admin_send_mail OutPacket ' . json_encode($p));

                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
                $this->socket = null;

                echo "thanh cong";
            }
        }

        die;
    }

}