<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */
date_default_timezone_set('Asia/Ho_Chi_Minh');
class GiftcodeController extends AppController

{

    public $uses = ['GiftCode', 'UserCode', 'EventCode', 'UserVerifiled', 'SpecialCode', 'UserSpecialCode'];


    private static $SERVICE_ERROR = -1;

    private $SUCCESS = 0;
    private $UNAUTHORIZED = 1;

    private $GIFT_CODE_NOT_EXIST = 21;
    private $GIFT_CODE_IS_USED = 22;
    private $GIFT_CODE_EXPIRED = 23;
    private $USER_USED_CODE_IN_SAME_EVENT = 24;
    private $INVALID_CODE_OWNER = 25;

    private $STATUS_NOT_USED = 0;
    private $STATUS_USED = 1;

    private $GIFT_CODE_SECRET_KEY = "1bCFH3f5z9qlBHj1LPKx";

    public function getUserCode(){
        $param = $this->request->query;
        CakeLog::write('GiftcodeController',json_encode( $param));
        $secure_code =  $param["secure_code"];
        $gameID = $param["gameID"];
        $uID = $param["uID"];

        $rs = $this->GiftCode->find('all',[
            'recursive' => -1,
            'joins' =>[
                [
                    'table' => 'user_codes',
                    'alias' => 'UserCodes',
                    'type' => 'inner',
                    'conditions' => [
                        'GiftCode.id = UserCodes.codeid'
                    ]
                ]
            ],
            'conditions' => [
                'UserCodes.userid' => $uID,
                'UserCodes.status' => $this->STATUS_NOT_USED
            ]
        ]);
        //pr($rs);
        $temp = [];
        foreach ($rs as $value){
            $temp[$value['GiftCode']['code']] = $value['GiftCode']['code'];
        }

        $result = [];
        $result[0] = $this->SUCCESS;
        $result[1] = (object)$temp;

        echo json_encode($result);

        die;
    }

    public function checkThenAddSpecial(){
        $param = $this->request->query;
        CakeLog::write('GiftcodeController',json_encode($param));

        $uID = intval($param["uID"]);
        $code = addslashes($param["code"]);

        $result = [];



        //get code_id from gift_codes table
        $gift_codes = $this->SpecialCode->find("first",[
            'conditions' => [
                'SpecialCode.code' => $code,
            ]
        ]);

        if (count($gift_codes) <= 0) {
            $result[0] = $this->GIFT_CODE_NOT_EXIST;
            $result[1] = (object)array('mess' => 'error');
            echo json_encode($result);
            die;
        }

        //Neu la code dac biet
        $uservr = $this->UserVerifiled->find("first", [
            'conditions' => [
                'UserVerifiled.status' => 1,
                'UserVerifiled.user_id' => $uID
            ]
        ]);

        if (count($uservr) < 1) {
            $result[0] = $this->INVALID_CODE_OWNER;
            $result[1] = (object)array('mess' => 'error');
            echo json_encode($result);
            die;
        }

        //1 User chi duoc dung 1 lan
        $user_code = $this->UserSpecialCode->find("first", [
            'conditions' => [
                'UserSpecialCode.special_id' => $gift_codes['SpecialCode']['id'],
                'UserSpecialCode.userid' => $uID
            ]
        ]);
        if (count($user_code) >= 1) {
            $result[0] = $this->USER_USED_CODE_IN_SAME_EVENT;
            $result[1] = (object)array('mess' => 'error');
            echo json_encode($result);
            die;
        }

        //1 Phone chi duoc dung 1 lan
        $user_code = $this->UserSpecialCode->find("first", [
            'conditions' => [
                'UserSpecialCode.special_id' => $gift_codes['SpecialCode']['id'],
                'UserSpecialCode.phone' => $uservr['UserVerifiled']['phone']
            ]
        ]);
        if (count($user_code) >= 1) {
            $result[0] = $this->USER_USED_CODE_IN_SAME_EVENT;
            $result[1] = (object)array('mess' => 'error');
            echo json_encode($result);
            die;
        }
        $this->UserSpecialCode->create();
        $this->UserSpecialCode->save(array('userid' => $uID, 'special_id' => $gift_codes['SpecialCode']['id'], 'phone' => $uservr['UserVerifiled']['phone']));

        $result = [];

        $result[0] = $this->SUCCESS;
        $result[1] = (object)array('gold' => $gift_codes['SpecialCode']['gold'], 'vpoint' => 0);

        header('Content-type: application/json');
        echo json_encode($result);

        die;

    }

    public function checkThenAdd(){
        $param = $this->request->query;
        CakeLog::write('GiftcodeController',json_encode($param));

        $uID = intval($param["uID"]);
        $code = addslashes($param["code"]);

        $result = [];



        //get code_id from gift_codes table
        $gift_codes = $this->GiftCode->find("first",[
            'conditions' => [
                'GiftCode.code' => $code,
            ]
        ]);

        if (count($gift_codes) <= 0) {
            $result[0] = $this->GIFT_CODE_NOT_EXIST;
            $result[1] = (object)array('mess' => 'error');
            echo json_encode($result);
            die;
        }
        //Lay Event code
        $event = $this->EventCode->find("first",[
            'conditions' => [
                'EventCode.id' => $gift_codes['GiftCode']['eventid']
            ]
        ]);


        //pr($gift_codes);
        //Check code used
        $user_code = $this->UserCode->find("first", [
            'conditions' => [
                'UserCode.codeid' => $gift_codes['GiftCode']['id']
            ]
        ]);
        if (count($user_code) >= 1) {
            $result[0] = $this->GIFT_CODE_IS_USED;
            $result[1] = (object)array('mess' => 'error');
            echo json_encode($result);
            die;
        }

//        pr($gift_codes);
        //check gameId
//        if($gameID != $gift_codes['EventCode']['gameid']){
//            $result[0] = $this->INVALID_CODE_OWNER;
//            $result[1] = (object)array('mess'=>'error');
//            echo json_encode($result);
//            die;
//        }
        //check date time (start_date -> expired_date)
        $curDate = date("Y-m-d H:i:s");
        if ($curDate < $event['EventCode']['start_date'] || $curDate > $event['EventCode']['expired_date']) {
            $result[0] = $this->GIFT_CODE_EXPIRED;
            $result[1] = (object)array('mess' => 'error');
            echo json_encode($result);
            die;
        }

        //Check loai code chi duoc dung 1 lan

        //Neu type_code = 2 - la code dung 1 lan
        if ($event['EventCode']['type_code'] == 2) {
            $check = $this->GiftCode->query("select * from `gift_codes` inner join `user_codes` on `gift_codes`.`id` = `user_codes`.`codeid` 
        where `gift_codes`.`eventid` = " . intval($event['EventCode']['id']) . " and `user_codes`.`userid` = " . intval($uID));
            if (count($check) > 0) {
                $result[0] = $this->USER_USED_CODE_IN_SAME_EVENT;
                $result[1] = (object)array('mess' => 'error');
                echo json_encode($result);
                die;
            }
        }

        //Neu type_code = 3 - la code dung 1 lan trong đời
        if ($event['EventCode']['type_code'] == 3) {
            $check = $this->GiftCode->query("
                                        select userid, code 
                                        from `user_codes`, `gift_codes`, `event_codes` 
                                        where `user_codes`.`codeid` = `gift_codes`.`id` 
                                        and `gift_codes`.`eventid` = `event_codes`.id 
                                        and  `event_codes`.`type_code` = 3 and `user_codes`.`userid` = " . intval($uID));
            if (count($check) > 0) {
                $result[0] = $this->USER_USED_CODE_IN_SAME_EVENT;
                $result[1] = (object)array('mess' => 'error');
                echo json_encode($result);
                die;
            }
        }

        $user = $this->UserCode->save(array('userid' => $uID, 'codeid' => $gift_codes['GiftCode']['id'], 'status' => $this->STATUS_NOT_USED));
        if ($user) {
            //get gold and vpoint
            $rsEvent = $this->EventCode->find('first', [
                'recursive' => -1,
                'joins' => [
                    [
                        'table' => 'gift_codes',
                        'alias' => 'GiftCodes',
                        'type' => 'inner',
                        'conditions' => [
                            'EventCode.id = GiftCodes.eventid'
                        ]
                    ]
                ],
                'conditions' => [
                    'GiftCodes.code' => $code,
//                    'GiftCodes.secure_code' => $secure_code,
                ]
            ]);

            $result = [];

            $result[0] = $this->SUCCESS;
            $result[1] = (object)array('gold' => $rsEvent['EventCode']['gold'], 'vpoint' => $rsEvent['EventCode']['vpoint']);

            header('Content-type: application/json');
            echo json_encode($result);
        }
        die;

    }

    public function usecode(){
        $param = $this->request->query;
        CakeLog::write('GiftcodeController', 'usecode'.json_encode($param));
        $secure_code =  $param["secure_code"];
        $gameID = $param["gameID"];
        $uID = $param["uID"];
        $code = $param["code"];

        $rs = $this->UserCode->find('first',[
            'recursive' => -1,
            'joins' =>[
                [
                    'table' => 'gift_codes',
                    'alias' => 'GiftCodes',
                    'type' => 'inner',
                    'conditions' => [
                        'UserCode.codeid = GiftCodes.id'
                    ]
                ]
            ],
            'conditions' => [
                'UserCode.userid' => $uID,
                'GiftCodes.code' => $code,
                'UserCode.status' => $this->STATUS_NOT_USED,
                'GiftCodes.secure_code' => $secure_code,
            ]
        ]);
        if(count($rs) <= 0){
            $result[0] = $this->GIFT_CODE_NOT_EXIST;
            $result[1] = (object)array('mess'=>'error');
            echo json_encode($result);
            die;
        }
        $this->UserCode->save([
            'id' => $rs['UserCode']['id'],
            'status' => $this->STATUS_USED,
        ]);
        //get gold and vpoint
        $rsEvent = $this->EventCode->find('first',[
            'recursive' => -1,
            'joins' =>[
                [
                    'table' => 'gift_codes',
                    'alias' => 'GiftCodes',
                    'type' => 'inner',
                    'conditions' => [
                        'EventCode.id = GiftCodes.eventid'
                    ]
                ]
            ],
            'conditions' => [
                'GiftCodes.code' => $code,
                'GiftCodes.secure_code' => $secure_code,
            ]
        ]);

        $result = [];

        $result[0] = $this->SUCCESS;
        $result[1] = (object)array('gold' => $rsEvent['EventCode']['gold'], 'vpoint' => $rsEvent['EventCode']['vpoint']);

        header('Content-type: application/json');
        echo json_encode($result);
        die;
    }


    public function genDaily(){
//        $st = "INSERT INTO `gift_codes` (`id`, `secure_code`, `code`, `eventid`, `agencyId`) VALUES (NULL, '123456', '123456', '1', '123')";
        for($i = 0; $i < 10000; $i++) {
            $rdString = Util::random_string(10);
            $rdMD5 = substr(md5($rdString), 0, 6);
            $rdKey = md5($rdMD5 . '' . $this->GIFT_CODE_SECRET_KEY);
            $code = substr($rdKey, 0, 4) . '' . $rdMD5;

            echo "(NULL, '123456', '".$code."', '877', '101163'),";
            echo '</br>';

        }

        die;
    }


    public function getDirContents($dir, &$results = array()){
        $files = scandir($dir);

        foreach($files as $key => $value){
            $path = realpath($dir.DIRECTORY_SEPARATOR.$value);
            if(!is_dir($path)) {
                $results[] = $path;
            } else if($value != "." && $value != "..") {
                $this->getDirContents($path, $results);
                //$results[] = $path;
            }
        }

        return $results;
    }

}