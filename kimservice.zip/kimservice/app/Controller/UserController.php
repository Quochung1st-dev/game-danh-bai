<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */
date_default_timezone_set('Asia/Ho_Chi_Minh');
App::uses('OutPacket', 'Model');
App::uses('CouchbaseCluster', 'CouchbaseCluster');
App::uses('CakeEmail', 'Network/Email');
App::import("Controller", "Captcha");

class UserController extends AppController
{
    public $uses = ['User', 'GiftCode', 'UserCode', 'EventCode', 'UserVerifiled', 'Agency', 'BotGame', 'UserBot', 'UserVpPresenting', 'Club', 'KpiUserChat', 'TaixiuUser', 'UserVpRanking', 'EventXs', 'FeeGame', 'Captchas', 'UserTransaction', 'ListCard', 'TaixiuRankingByDay', 'TaixiuUser'];


    private $ZINGME_ERROR_SUCCESS = 0;
    private $ZINGME_ERROR_ACCOUNT_INVALID = 1;
    private $ZINGME_ERROR_ERROR_WHEN_PROCESSING_2 = 2;
    private $ZINGME_ERROR_USERNAME_DOES_NOT_EXISTED = 3;
    private $ZINGME_ERROR_WRONG_PASSWORD = 4;
    private $ZINGME_ERROR_ACCOUNT_LOCKED = 5;
    private $ZINGME_ERROR_ERROR_WHEN_PROCESSING_6 = 6;
    private $ZINGME_ERROR_ERROR_WHEN_PROCESSING_7 = 7;
    private $ZINGME_ERROR_ERROR_WHEN_PROCESSING_8 = 8;
    private $ZINGME_ERROR_ERROR_WHEN_PROCESSING_9 = 9;
    private $ZINGME_ERROR_ERROR_WHEN_PROCESSING_10 = 10;
    private $ZINGME_ERROR_ERROR_WHEN_PROCESSING_11 = 11;

    private $ZING_PORTAL_ERROR_SUCCESS = 0;
    private $ZING_PORTAL_ERROR_FATAL_ERROR = -1;
    private $ZING_PORTAL_ERROR_REQUEST_BODY_INVALID = -2;
    private $ZING_PORTAL_ERROR_USERNAME_INVALID = 10;
    private $ZING_PORTAL_ERROR_PASSWORD_INVALID = 11;
    private $ZING_PORTAL_ERROR_USERNAME_ALREADY_EXISTED = 12;
    private $ZING_PORTAL_ERROR_SESSION_VALID = 14;
    private $ZING_PORTAL_ERROR_SESSION_INVALID = 15;
    private $ZING_PORTAL_ERROR_USERNAME_DOES_NOT_EXIST = 16;
    private $ZING_PORTAL_ERROR_DEVICE_ID_INVALID = 17;
    private $ZING_PORTAL_ERROR_PARTNER_ID_INVALID = 18;
    private $ZING_PORTAL_ERROR_USERNAME_PASSWORD_NOT_MATCH = 30;
    private $ZING_PORTAL_ERROR_WRONG_PASSWORD = 6;
    private $ZING_PORTAL_ERROR_IP_MAX_REGISTER = 24;
    private $ZING_PORTAL_ERROR_CAPTCHA = 25;

    private $zingmeCodeSuccess = 3;

    private $TYPE_LOGIN_PORTAL = 1;
    private $TYPE_LOGIN_FACEBOOK = 2;
    private $TYPE_LOGIN_PORTAL_AUTO = 3;
    private $TYPE_LOGIN_PORTAL_NEW = 4;

    private $STATUS_VERIFY_OK = 1;
    private $STATUS_VERIFY_NOT_OK = 2;

    private $TYPE_VERIFY_PHONE = 0;
    private $TYPE_ONE_TIME_PASS = 1;

    private $socket;


    public function invitefriend()
    {

        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));
        if (isset($param["accessToken"]) && isset($param["userID"])) {
            $user_details = "https://graph.facebook.com/me?fields=id,name,picture{url}&access_token=" . $param["accessToken"];
            $response = file_get_contents($user_details);
            $response = json_decode($response);

            //add User
            $user = $this->User->find("first", [
                'conditions' => [
                    'User.id' => $param["userID"]
                ]
            ]);
            if (count($user) > 0) {
                $this->User->save(array(
                    'id' => $user['User']['id'],
                    'invite_friend' => $response->id));
                echo $response->id;
            }
        }
        die;
    }

    public function getToken()
    {
    }

    private function checkToken($userID, $token)
    {
        $rs = $this->User->find("first", [
            'conditions' => [
                'User.id' => $userID,
                'User.sid' => $token,
            ]
        ]);
        if (count($rs) > 0)
            return 1;
        return 0;
    }

    public function testgold()
    {
        $param = $this->request->query;
        $gold = $this->getGoldByID($param['userid']);
        echo $gold;
        die;
    }

    public function test()
    {
            die;
//        $cluster1 = new CouchbaseCluster('couchbase://3.0.173.227');
//        $manager = $cluster1->manager("Administrator","PkCb#1268*");
//        $info = $manager->info();
//        printf("cluster has %d nodes, %d buckets and %d megabytes used\n",
//            count($info['nodes']), count($info['buckets']),
//            $info['storageTotals']['ram']['usedByData'] / 1024 / 1024);
//        die;
//        try {
            $bucketName = "casino";

// Establish username and password for bucket-access
//            $authenticator = new \Couchbase\PasswordAuthenticator();
//
//            $authenticator->bucket('')->password('');

// Connect to Couchbase Server
            $cluster = new CouchbaseCluster('couchbase://127.0.0.1');
//        $cluster->authenticate("Administrator","PkCb#1268*");
//        $cluster1->manager($manager);
// Authenticate, then open bucket
//$cluster->authenticate($authenticator);
            $bucket = $cluster->openBucket($bucketName);
        $rs = $this->User->query('select id from `user_vics` WHERE `displayname` = "" and agency = 0 and `password` <> "1111111"');

        for($i = 0; $i < count($rs); $i++){

            $this->User->query('UPDATE `user_vics` SET `password` = "1111111" WHERE `user_vics`.`id` = '. $rs[$i]['user_vics']['id']);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_UFishingModel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_UHandModel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_ULuckyWheel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_UMailModel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_UProfileModel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_URutThuongModel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_USlotHistoryModel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_USlotModel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_UTaiXiuModel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_UTrackingModel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_UUngTienModel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_UUserGameCDHistoryModel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_UUserHistoryMiniCaoThapModel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_UUserHistoryMiniDiamondNewModel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_UUserHistoryMiniPokerModel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);

            $qr = 'DELETE FROM casino where META().id = "casino_data4_s_1_UUserHistoryModel.'.$rs[$i]['user_vics']['id'].'"';
            $query = CouchbaseN1qlQuery::fromString($qr);
            $rows = $bucket->query($query);
            echo $rs[$i]['user_vics']['id']."<br>";
        }
        die;
// Query with parameters



//            if (isset($rows->rows[0]->casino)) {
//                return $rows->rows[0]->casino->gold;
//            }

//        } catch (Exception $exception) {
//            pr($exception);
//            die;
//        }

    }

    public function getGoldByID($id)
    {
        try {
            $bucketName = "casino";

// Establish username and password for bucket-access
            $authenticator = new \Couchbase\PasswordAuthenticator();

            $authenticator->username('')->password('');

// Connect to Couchbase Server
            $cluster = new CouchbaseCluster("couchbase://127.0.0.1");

// Authenticate, then open bucket
//$cluster->authenticate($authenticator);
            $bucket = $cluster->openBucket($bucketName);

// Query with parameters
            $query = CouchbaseN1qlQuery::fromString('SELECT * FROM casino USE KEYS ["casino_data4_s_1_UProfileModel.' . $id . '"];');

            $rows = $bucket->query($query);
//            pr($rows);
            if (isset($rows->rows[0]->casino)) {
                return $rows->rows[0]->casino->gold;
            }

            return 0;
        } catch (Exception $exception) {
            return 0;
        }
    }

    public function preverifyphone()
    {
        

        $param = $this->request->query;
        $ip = $this->requestAction(['controller' => 'GameManager', 'action' => 'getRealIpAddr']);
        CakeLog::write('UserController', "preverifyphone " . $ip . ' --' . json_encode($param));
        if (isset($param["token"]) && isset($param["userID"]) && isset($param["phone"])) {
            $captcha = strtolower($param["captcha"]);
            $verify = $param["verify"];
            $requestid = $param["requestid"];

//                pr($param);
            $ck = CaptchaController::checkCaptcha($this,$captcha, $verify, $requestid);
//                echo $ck;
            if ($ck != 0) {
                $result = array($this->ZING_PORTAL_ERROR_CAPTCHA);
                echo json_encode($result);
                die;
            }

            if (isset($param["id"])){
                $result = array(101);
                echo json_encode($result);
                die;
            }
            $check = $this->checkToken($param["userID"], $param["token"]);
            if ($check == 0) {
                $result = array(101);
                echo json_encode($result);
                die;
            }
//            $gold = $this->getGoldByID($param['userID']);
//            if($gold < 1000){
//                $result = array(5);
//                echo json_encode($result);
//                die;
//            }

            $rs2 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.phone' => $param["phone"],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_OK,

                ]
            ]);

            $rs1 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $param["userID"],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_OK,

                ]
            ]);

            if (count($rs2) > 0 || count($rs1) > 0) {
                $result = array(2);
                echo json_encode($result);
                die;
            }

            $rs = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $param["userID"],
                    'UserVerifiled.phone' => $param["phone"],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_NOT_OK,
                ]
            ]);

            if (1 == 1) {
                $code = $sid = Util::random_num(6);
                $Content = "Ma OTP cua ban la: " . $code . ", thoi han su dung 5 phut";

                $SendContent = urlencode($Content);
                $data = "http://rest.esms.vn/MainService.svc/json/SendMultipleMessage_V4_get?Phone=" . $param["phone"] . "&ApiKey=" . APIKey . "&SecretKey=" . SecretKey . "&Content=" . $SendContent . "&SmsType=2&Brandname=QCAO_ONLINE";

                $curl = curl_init($data);
                curl_setopt($curl, CURLOPT_FAILONERROR, true);
                curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
                curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                $result = curl_exec($curl);
                CakeLog::write('UserController', "preverifyphone result " . $result);
                $obj = json_decode($result, true);
                if ($obj['CodeResult'] == 100) {
                    $curDate = date("Y-m-d H:i:s");
                    if (count($rs) == 0) {

                        $this->UserVerifiled->save(array(
                            'user_id' => $param["userID"],
                            'phone' => $param["phone"],
                            'status' => $this->STATUS_VERIFY_NOT_OK,
                            'type' => $this->TYPE_VERIFY_PHONE,
                            'created' => $curDate,
                            'code' => $code));
                    } else {
                        $this->UserVerifiled->save(array(
                            'id' => $rs['UserVerifiled']['id'],
                            'created' => $curDate,
                            'code' => $code));
                    }
                    $result = array(0);
                    echo json_encode($result);
                } else {
                    $result = array(1);
                    echo json_encode($result);
                }
            } else {
                $result = array(2);
                echo json_encode($result);
            }

        } else {
            $result = array(3);
            echo json_encode($result);
        }
        die;

    }

    public function preverifyEmail()
    {
        $param = $this->request->query;
        $ip = $this->requestAction(['controller' => 'GameManager', 'action' => 'getRealIpAddr']);
        CakeLog::write('UserController', "preverifyEmail " . $ip . ' --' . json_encode($param));
        if (isset($param["token"]) && isset($param["userID"]) && isset($param["phone"])) {
            $captcha = strtolower($param["captcha"]);
            $verify = $param["verify"];
            $requestid = $param["requestid"];

//                pr($param);
            $ck = CaptchaController::checkCaptcha($this,$captcha, $verify, $requestid);
//                echo $ck;
            if ($ck != 0) {
                $result = array($this->ZING_PORTAL_ERROR_CAPTCHA);
                echo json_encode($result);
                die;
            }

            if (isset($param["id"])){
                $result = array(101);
                echo json_encode($result);
                die;
            }
            $check = $this->checkToken($param["userID"], $param["token"]);
            if ($check == 0) {
                $result = array(101);
                echo json_encode($result);
                die;
            }

            $rs2 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.phone' => $param["phone"],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_OK,

                ]
            ]);

            $rs1 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $param["userID"],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_OK,

                ]
            ]);

            if (count($rs2) > 0 || count($rs1) > 0) {
                $result = array(2);
                echo json_encode($result);
                die;
            }

            $rs = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $param["userID"],
                    'UserVerifiled.phone' => $param["phone"],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_NOT_OK,
                ]
            ]);

            if (1 == 1) {
                $code = $sid = Util::random_num(6);
                $Content = "Ma OTP cua ban la: " . $code . ", thoi han su dung 5 phut";

                //send mail to user
                $result = $this->sendMail($param["phone"], $Content, 'Đăng ký email'); //TODO: change param 'phone' -> 'email'
                
                CakeLog::write('UserController', "preverifyphone result " . $result);
                $obj = json_decode($result, true);
                if ($result == 1) { //send mail success
                    $curDate = date("Y-m-d H:i:s");
                    if (count($rs) == 0) {
                        // insert new verify code for user id
                        $this->UserVerifiled->save(array(
                            'user_id' => $param["userID"],
                            'phone' => $param["phone"],
                            'status' => $this->STATUS_VERIFY_NOT_OK,
                            'type' => $this->TYPE_VERIFY_PHONE,
                            'created' => $curDate,
                            'code' => $code));
                    } else {
                        // update new verify code for existing user_id
                        $this->UserVerifiled->save(array(
                            'id' => $rs['UserVerifiled']['id'],
                            'created' => $curDate,
                            'code' => $code));
                    }
                    $result = array(0);
                    echo json_encode($result);
                } else {
                    $result = array(1);
                    echo json_encode($result);
                }
            } else {
                $result = array(2);
                echo json_encode($result);
            }

        } else {
            $result = array(3);
            echo json_encode($result);
        }
        die;

    }

    public function getDLotp()
    {

        $param = $this->request->query;
        CakeLog::write('UserController', "getDLotp " . json_encode($param));
        if (isset($param["id"])) {
            $code = Util::random_num(6);
            $Content = "Ma OTP cua ban la: " . $code . ", thoi han su dung 5 phut";

            $dl = $this->Agency->find("first", [
                'conditions' => [
                    'Agency.id' => $param["id"]]

            ]);

            if (count($dl) == 0) {
                echo "Không tìm thấy đại lý";
            }
            $rs1 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $dl['Agency']['userid'],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_OK,
                ]
            ]);

            if (count($rs1) > 0) {
                $USE_MAIL = true;

                $result_code = -1;

                if ($USE_MAIL == false) {

                    $SendContent = urlencode($Content);
                    $data = "http://rest.esms.vn/MainService.svc/json/SendMultipleMessage_V4_get?Phone=" . $rs1['UserVerifiled']['phone'] . "&ApiKey=" . APIKey . "&SecretKey=" . SecretKey . "&Content=" . $SendContent . "&SmsType=2&Brandname=QCAO_ONLINE";
                    
                    $curl = curl_init($data);
                    curl_setopt($curl, CURLOPT_FAILONERROR, true);
                    curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
                    curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
                    $result = curl_exec($curl);
                    CakeLog::write('UserController', "getDLotp result " . $result);
                    $obj = json_decode($result, true);

                    $result_code = $obj['CodeResult'];
                }
                else {
                    //send mail to user
                    $result = $this->sendMail($rs1['UserVerifiled']['phone'], $Content, 'Đăng nhập Đại lý Sillvip'); //TODO: change param 'phone' -> 'email'
                    
                    CakeLog::write('UserController', "getDLotpMail result " . $result);
                    $result_code = $result;
                }
                // if ($result_code == 100) { // Used for sms
                if ($result_code == 1) {
                    $curDate = date("Y-m-d H:i:s");
                    $this->UserVerifiled->save(array(
                        'id' => $rs1['UserVerifiled']['id'],
                        'created' => $curDate,
                        'code' => $code));
                    echo "Lấy mã otp thành công";
                } else {
                    echo "Lấy mã otp không thành công " . $obj['CodeResult'];
                }

            } else {
                echo "Tài khoản chưa xác thực";
            }
        }
        die;
    }
    
    public function verifyDLcode()
    {


        $param = $this->request->query;
        CakeLog::write('UserController', "verifyDLcode " . json_encode($param));
        if (isset($param["id"]) && isset($param["code"])) {

            $dl = $this->Agency->find("first", [
                'conditions' => [
                    'Agency.id' => $param["id"]]

            ]);
            if (count($dl) == 0) {
                $result = array(1);
                echo json_encode($result);
                die;
            }
            $rs1 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $dl['Agency']['userid'],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_OK,
                ]
            ]);
            if (count($rs1) > 0) {
                $curDate = date("Y-m-d H:i:s");
                $t1 = strtotime($curDate);
                $t2 = strtotime($dl['Agency']['created']);
                if ($t1 - $t2 > 5 * 60) {//Code qua han su dung
                    $result = array(2);
                    echo json_encode($result);
                    die;
                }
                if (count($dl) != null && $dl['Agency']['code'] == $param["code"]) {

                    $result = array(0);
                    echo json_encode($result);
                } else {
                    $result = array(1);
                    echo json_encode($result);
                }
            } else {
                $result = array(2);
                echo json_encode($result);
            }

        }
        die;

    }

    public function resetphone()
    {
        

        $param = $this->request->query;
        CakeLog::write('UserController', "preverifyphone " . json_encode($param));
        if (isset($param["token"]) && isset($param["userID"]) && isset($param["phone"])) {

            $check = $this->checkToken($param["userID"], $param["token"]);
            if ($check == 0) {
                $result = array(101);
                echo json_encode($result);
                die;
            }

            $rs1 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.phone' => $param["phone"]
                ]
            ]);


            if (count($rs1) > 0) {
                $result = array(2);
                echo json_encode($result);
                die;
            }
            $rs = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $param["userID"]
                ]
            ]);
            if (count($rs) > 0) {

                $this->UserVerifiled->save(array(
                    'id' => $rs['UserVerifiled']["id"],
                    'phone' => $param["phone"]));
                $this->User->save(array(
                    'id' => $rs['UserVerifiled']['user_id'],
                    'phone' => $param["phone"]));
                $result = array(0);
                echo json_encode($result);
            } else {
                $result = array(2);
                echo json_encode($result);
            }

        } else {
            $result = array(3);
            echo json_encode($result);
        }
        die;

    }

    public function unverifyphone()
    {
        

        $param = $this->request->query;
        CakeLog::write('UserController', "verifyphone " . json_encode($param));
        if (isset($param["token"]) && isset($param["userID"]) && isset($param["phone"])) {

//            $captcha = strtolower($param["captcha"]);
//            $verify = $param["verify"];
//            $requestid = $param["requestid"];
//
//    //                pr($param);
//            $ck = CaptchaController::checkCaptcha($this,$captcha, $verify, $requestid);
//    //                echo $ck;
//            if ($ck != 0) {
//                $result = array($this->ZING_PORTAL_ERROR_CAPTCHA);
//                echo json_encode($result);
//                die;
//            }
            $check = $this->checkToken($param["userID"], $param["token"]);
            if ($check == 0) {
                $result = array(101);
                echo json_encode($result);
                die;
            }

            $rs = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $param["userID"],
                    'UserVerifiled.phone' => $param["phone"],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_OK,
                ]
            ]);
            if (count($rs) == 0) {
                $result = array(1);
                echo json_encode($result);
                die;
            }


            $this->UserVerifiled->save(array(
                'id' => $rs['UserVerifiled']['id'],
                'phone' => "",
                'status' => $this->STATUS_VERIFY_NOT_OK));
            $this->User->save(array(
                'id' => $rs['UserVerifiled']['user_id'],
                'phone' => ""));


            $checkSokcet = false;
            //Open socket to server
            if ($this->socket == null) {
                $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
            }
            if ($this->socket === false) {
                $checkSokcet = false;
            } else {
                $checkSokcet = true;
            }

            $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
            if ($result === false) {
                $checkSokcet = false;
            } else {
                $checkSokcet = true;
            }

            $p = new OutPacket(1, PAYMENT_1_PAY_SMS);
            $p->putInt(SMS);
            $p->putInt(-1);
            $p->putString("sms");
            $p->putString("sms");
            $p->putLong(0);
            $p->putLong($param["userID"]);
            $p->putString(php_secret_key);
            $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
            $pckLen = strlen($packet);
            socket_write($this->socket, $packet, $pckLen);
            socket_close($this->socket);

            $result = array(0);
            echo json_encode($result);


        }
        die;

    }


    public function verifyphone()
    {


        $param = $this->request->query;
        CakeLog::write('UserController', "verifyphone " . json_encode($param));
        if (isset($param["token"]) && isset($param["userID"]) && isset($param["phone"]) && isset($param["code"])) {

            $check = $this->checkToken($param["userID"], $param["token"]);
            if ($check == 0) {
                $result = array(101);
                echo json_encode($result);
                die;
            }

            $rs1 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $param["userID"],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_OK,
                ]
            ]);
            if (count($rs1) > 0) {
                $result = array(1);
                echo json_encode($result);
                die;
            }

            $rs = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $param["userID"],
                    'UserVerifiled.phone' => $param["phone"],
                    'UserVerifiled.code' => $param["code"],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_NOT_OK,
                    'UserVerifiled.type' => $this->TYPE_VERIFY_PHONE,
                ]
            ]);
            if (count($rs) == 0) {
                $result = array(1);
                echo json_encode($result);
                die;
            }
            $curDate = date("Y-m-d H:i:s");
            $t1 = strtotime($curDate);
            $t2 = strtotime($rs['UserVerifiled']['created']);
            if ($t1 - $t2 > 5 * 60) {//Code qua han su dung
                $result = array(2);
                echo json_encode($result);
                die;
            }

            $user = $this->User->find("first", [
                'conditions' => [
                    'id' => $param["userID"],
                ]
            ]);
            $gold = 0;
            $checkTK = $this->User->find("count", [
                'conditions' => [
                    'deviceToken' => $user['User']['deviceToken'],
                ]
            ]);
            if ($checkTK > 4) {
                $gold = 0;
                CakeLog::write('UserController', "verifyphone User Token " . json_encode($user));
            }
            if (count($rs) != null && $rs['UserVerifiled']['code'] == $param["code"]) {

                $this->UserVerifiled->save(array(
                    'id' => $rs['UserVerifiled']['id'],
                    'type' => $this->TYPE_VERIFY_PHONE,
                    'status' => $this->STATUS_VERIFY_OK));
                $this->User->save(array(
                    'id' => $rs['UserVerifiled']['user_id'],
                    'phone' => $rs['UserVerifiled']['phone']));


                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }

                $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }

                $p = new OutPacket(1, PAYMENT_1_PAY_SMS);
                $p->putInt(SMS);
                $p->putInt(0);
                $p->putString("sms");
                $p->putString("sms");
                $p->putLong($gold);
                $p->putLong($param["userID"]);
                $p->putString(php_secret_key);
                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);

                $result = array(0);
                echo json_encode($result);
            } else {
                $result = array(1);
                echo json_encode($result);
            }

        }
        die;

    }
    public function verifyEmail()
    {
        $param = $this->request->query;
        CakeLog::write('UserController', "verifyEmail " . json_encode($param));
        if (isset($param["token"]) && isset($param["userID"]) && isset($param["phone"]) && isset($param["code"])) {

            $check = $this->checkToken($param["userID"], $param["token"]);
            if ($check == 0) {
                $result = array(101);
                echo json_encode($result);
                die;
            }

            $rs1 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $param["userID"],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_OK,
                ]
            ]);
            if (count($rs1) > 0) {
                $result = array(1);
                echo json_encode($result);
                die;
            }

            $rs = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $param["userID"],
                    'UserVerifiled.phone' => $param["phone"],
                    'UserVerifiled.code' => $param["code"],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_NOT_OK,
                    'UserVerifiled.type' => $this->TYPE_VERIFY_PHONE,
                ]
            ]);
            if (count($rs) == 0) {
                $result = array(1);
                echo json_encode($result);
                die;
            }
            $curDate = date("Y-m-d H:i:s");
            $t1 = strtotime($curDate);
            $t2 = strtotime($rs['UserVerifiled']['created']);
            if ($t1 - $t2 > 5 * 60) {//Code qua han su dung
                $result = array(2);
                echo json_encode($result);
                die;
            }

            $user = $this->User->find("first", [
                'conditions' => [
                    'id' => $param["userID"],
                ]
            ]);
            $gold = 0;
            $checkTK = $this->User->find("count", [
                'conditions' => [
                    'deviceToken' => $user['User']['deviceToken'],
                ]
            ]);
            if ($checkTK > 4) {
                $gold = 0;
                CakeLog::write('UserController', "verifyEmail User Token " . json_encode($user));
            }
            if (count($rs) != null && $rs['UserVerifiled']['code'] == $param["code"]) {

                $this->UserVerifiled->save(array(
                    'id' => $rs['UserVerifiled']['id'],
                    'type' => $this->TYPE_VERIFY_PHONE,
                    'status' => $this->STATUS_VERIFY_OK));
                $this->User->save(array(
                    'id' => $rs['UserVerifiled']['user_id'],
                    'email' => $rs['UserVerifiled']['phone'])); //add verified email to user


                $checkSokcet = false;
                //Open socket to server
                if ($this->socket == null) {
                    $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
                }
                if ($this->socket === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }

                $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
                if ($result === false) {
                    $checkSokcet = false;
                } else {
                    $checkSokcet = true;
                }

                // cai nay lam gi day
                $p = new OutPacket(1, PAYMENT_1_PAY_SMS);
                $p->putInt(SMS);
                $p->putInt(0);
                $p->putString("sms");
                $p->putString("sms");
                $p->putLong($gold);
                $p->putLong($param["userID"]);
                $p->putString(php_secret_key);
                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);

                $result = array(0);
                echo json_encode($result);
            } else {
                $result = array(1);
                echo json_encode($result);
            }

        }
        die;

    }
    
    public function registerToken()
    {
        

        $param = $this->request->query;
        CakeLog::write('UserController registerToken', json_encode($param));

        if (isset($param["deviceToken"])
            && isset($param["userID"])
            && isset($param["typeOS"])
        ) {
            $userID = $param["userID"];
            $typeOS = $param["typeOS"];
            $deviceToken = $param["deviceToken"];

            $rs = $this->User->find("all", [
                'conditions' => [
                    'User.id' => $userID
                ]
            ]);
            if (count($rs) > 0) {
                $this->User->save(array(
                    'id' => $userID,
                    'typeOS' => $typeOS,
                    'deviceToken' => $deviceToken));
                $result = array('error' => 0);
                echo json_encode($result);
            } else {
                $result = array('error' => 1);
                echo json_encode($result);
            }
        } else {
            $result = array('error' => 1);
            echo json_encode($result);
        }
        die;
    }

    public function getphone()
    {

        

        $param = $this->request->query;
        CakeLog::write('UserController', "getphone " . json_encode($param));
        if (isset($param["userID"]) && isset($param["token"])) {

            $check = $this->checkToken($param["userID"], $param["token"]);
            if ($check == 0) {
                $result = array(101);
                echo json_encode($result);
                die;
            }

            $rs = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $param["userID"],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_OK,
                ]
            ]);
            if (count($rs) > 0) {
                echo json_encode($rs);
            } else {
                echo "{}";
            }
        } else {
            echo "{}";
        }
        die;
    }

    public function misspassSMS($pass, $phone)
    {

        $Content = "Ma OTP cua ban la: " . $pass . ", thoi han su dung 5 phut";

        $SendContent = urlencode($Content);
        $data = "http://rest.esms.vn/MainService.svc/json/SendMultipleMessage_V4_get?Phone=" . $phone . "&ApiKey=" . APIKey . "&SecretKey=" . SecretKey . "&Content=" . $SendContent . "&SmsType=2&Brandname=QCAO_ONLINE";

        $curl = curl_init($data);
        curl_setopt($curl, CURLOPT_FAILONERROR, true);
        curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
        $result = curl_exec($curl);
        CakeLog::write('UserController', "misspassSMS result " . $result);
        $obj = json_decode($result, true);
        if ($obj['CodeResult'] == 100) {
            return 1;
        } else {
            return 0;
        }

    }

    public function misspassword()
    {

        

        $param = $this->request->query;
        CakeLog::write('UserController', "misspassword " . json_encode($param));
        if (isset($param["userName"]) && isset($param["phone"])) {

            $captcha = strtolower($param["captcha"]);
            $verify = $param["verify"];
            $requestid = $param["requestid"];

//                pr($param);
            $ck = CaptchaController::checkCaptcha($this,$captcha, $verify, $requestid);
//                echo $ck;
            if ($ck != 0) {
                $result = array('status' => $this->ZING_PORTAL_ERROR_CAPTCHA, 'data' => "");
                echo json_encode($result);
                die;
            }


            $rs = $this->User->find("first", [
                'conditions' => [
                    'username' => $param["userName"]
                ]
            ]);
            if (count($rs) > 0) {

                $rs1 = $this->UserVerifiled->find("first", [
                    'conditions' => [
                        'UserVerifiled.user_id' => $rs['User']['id'],
                        'UserVerifiled.phone' => $param["phone"],
                    ]
                ]);
                $pass = Util::random_string(7);

                if (count($rs1) > 0) {
                    $this->User->save([
                        'id' => $rs['User']['id'],
                        'password' => md5(md5($pass) . KEY_ENCODE)
                    ]);

                    $rs2 = $this->misspassSMS($pass, $rs1['UserVerifiled']['phone']);
                    if ($rs2 == 1) {
                        $result = array(0);
                        echo json_encode($result);
                        die;
                    } else {
                        $result = array(5);
                        echo json_encode($result);
                        die;
                    }
                } else {
                    $result = array(3);//OTP Sai
                    echo json_encode($result);
                    die;
                }
            } else {
                $result = array(2);//Username khong ton tai
                echo json_encode($result);
                die;
            }
        } else {
            $result = array(1);
            echo json_encode($result);
            die;
        }
        die;
    }

    public function misspasswordmail()
    {
        $param = $this->request->query;
        CakeLog::write('UserController', "misspasswordMail " . json_encode($param));

        //TODO: change param 'phone' -> 'email', but client send param 'phone' atm
        if (isset($param["userName"]) && isset($param["phone"])) {

            // verify captcha first
            $captcha = strtolower($param["captcha"]);
            $verify = $param["verify"];
            $requestid = $param["requestid"];

            $ck = CaptchaController::checkCaptcha($this,$captcha, $verify, $requestid);

            if ($ck != 0) {
                $result = array('status' => $this->ZING_PORTAL_ERROR_CAPTCHA, 'data' => "");
                echo json_encode($result);
                die;
            }

            $rs = $this->User->find("first", [
                'conditions' => [
                    'username' => $param["userName"],
                    'email' => $param['phone']
                ]
            ]);
            if (count($rs) > 0) {

                $pass = Util::random_string(7);
                $this->User->save([
                    'id' => $rs['User']['id'],
                    'password' => md5($pass)
                ]);

                $content = "Mật khẩu mới của bạn là : ".$pass;

                $rs2 = $this->sendMail($rs['User']['email'], $content, "Quên mật khẩu");

                if ($rs2 == 1) {
                    $result = array(0);
                    CakeLog::write('UserController', "misspasswordMail result " . json_encode($result));
                    echo json_encode($result);
                    die;
                } else {
                    $result = array(5);
                    CakeLog::write('UserController', "misspasswordMail result " . json_encode($result));
                    echo json_encode($result);
                    die;
                }
            } else {
                $result = array(2);//Username khong ton tai
                CakeLog::write('UserController', "misspasswordMail result " . json_encode($result));
                echo json_encode($result);
                die;
            }
        } else {
            $result = array(1);
            CakeLog::write('UserController', "misspasswordMail result " . json_encode($result));
            echo json_encode($result);
            die;
        }
        die;
    }

    public function misspasswordrv()
    {

        

        $param = $this->request->query;
        CakeLog::write('UserController', "misspasswordrv " . json_encode($param));
        if (isset($param["username"]) && isset($param["mail"])) {

            $rs = $this->User->find("first", [
                'conditions' => [
                    'username' => $param["username"],
                    'email' => $param["mail"]
                ]
            ]);
            if (count($rs) > 0) {

                $pass = Util::random_string(7);
                $this->User->save([
                    'id' => $rs['User']['id'],
                    'password' => md5($pass)
                ]);

                $content = "Mật khẩu mới của bạn là : ".$pass;

                $rs2 = $this->sendMail($rs['User']['email'], $content, "Quên mật khẩu");
                if ($rs2 == 1) {
                    $result = array(0);
                    echo json_encode($result);
                    die;
                } else {
                    $result = array(5);
                    echo json_encode($result);
                    die;
                }
            } else {
                $result = array(2);//Username khong ton tai
                echo json_encode($result);
                die;
            }
        } else {
            $result = array(1);
            echo json_encode($result);
            die;
        }
        die;
    }

    public function testsendMail(){
//        echo $this->sendMail("diep.ln68@gmail.com","tao thich tao gui");
        echo CaptchaController::checkCaptcha($this,"StW6V","043ee99bb4f3e1ee575c1c3ae64901f5","3cj9leqsqo17o76mrvfy1jriqi7rdp9a");
        die;
    }
    private function sendMail($to, $content, $subject){
        $Email = new CakeEmail();
        $Email->config('gmail') // gmail, smtp or any config you have created in email config
            ->emailFormat('text')
            ->from('piano.bestgame@gmail.com', 'Sill.Vip')
            ->to($to)
            ->subject($subject);

        CakeLog::write('UserController', "sendMail to " . ($to));
        if($Email->send($content)){
            CakeLog::write('UserController', "sendMail true " . ($to));
            return true;
        }else {
            CakeLog::write('UserController', "sendMail false " . ($to));
            return false;
        }
        die;
    }

    public function resetpassword()
    {

        

        $param = $this->request->query;
        CakeLog::write('UserController', "resetpassword " . json_encode($param));
        if (isset($param["userID"]) && isset($param["oldpass"]) && isset($param["newpass"]) && isset($param["token"])) {

            $check = $this->checkToken($param["userID"], $param["token"]);
            if ($check == 0) {
                $result = array(101);
                echo json_encode($result);
                die;
            }


            $oldPass = $param["oldpass"];

            $rs = $this->User->find("first", [
                'conditions' => [
                    'id' => $param["userID"],
                    'password' => md5($oldPass . KEY_ENCODE),
                ]
            ]);
            if (count($rs) > 0) {
                $this->User->save([
                    'id' => $param["userID"],
                    'password' => md5($param["newpass"] . KEY_ENCODE)
                ]);
                $result = array(0);
                echo json_encode($result);
                die;
            } else {
                $result = array(2);
                echo json_encode($result);
                die;
            }
        } else {
            $result = array(1);
            echo json_encode($result);
            die;
        }
        die;
    }


    public function displayname()
    {
        

        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (isset($param["displayname"]) && isset($param["userID"]) && isset($param["token"])) {

            $check = $this->checkToken($param["userID"], $param["token"]);
            if ($check == 0) {
                $result = array(101);
                echo json_encode($result);
                die;
            }

            $displayname = $param["displayname"];
            $userID = $param["userID"];

            if (preg_match('/^[a-zA-Z0-9]{6,}$/', $displayname)) { // for english chars + numbers only
                // valid username, alphanumeric & longer than or equals 7 chars
                $rs = $this->User->find("first", [
                    'conditions' => [
                        'User.id' => $param["userID"]
                    ]
                ]);
                $rs1 = $this->User->find("first", [
                    'conditions' => [
                        'User.displayname' => $param["displayname"]
                    ]
                ]);
                $rs2 = $this->User->find("first", [
                    'conditions' => [
                        'User.username' => $param["displayname"]
                    ]
                ]);
                if (count($rs1) > 0 || count($rs2)) {
                    $result = array(4);
                    echo json_encode($result);
                    die;
                }
                if (count($rs) > 0 && strlen($rs['User']['displayname']) <= 0) {

                    $this->User->save([
                        'id' => $param["userID"],
                        'displayname' => $param["displayname"],
                    ]);

                    $result = array(0);
                    echo json_encode($result);
                } else {
                    $result = array(3);
                    echo json_encode($result);
                }
            } else {
                $result = array(2);
                echo json_encode($result);
            }


        } else {
            $result = array(1);
            echo json_encode($result);
        }
        die;
    }


    public function idbydisplayname()
    {
        

        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));

        if (isset($param["userid"])) {

            $rs1 = $this->User->find("first", [
                'conditions' => [
                    'User.id' => $param["userid"]
                ]
            ]);
            if (count($rs1) > 0) {

                $result = array('code' => 0, 'displayname' => $rs1['User']['displayname']);
                echo json_encode($result);
            } else {
                $result = array('code' => 3, 'displayname' => "");
                echo json_encode($result);
            }

        } else {
            $result = array('code' => 1, 'displayname' => "");
            echo json_encode($result);
        }
        die;
    }

    public function getVPPreseting()
    {
        

        $param = $this->request->query;
        if (isset($param["userid"]) && isset($param["token"])) {
            $check = $this->checkToken($param["userid"], $param["token"]);
//            if($check == 0){
//                $result = array('code' => 101, 'data' => []);
//                echo json_encode($result);
//                die;
//            }

            $rs = $this->UserVpPresenting->find('all', [
                'conditions' => [
                    'presenter_id' => $param["userid"]
                ]
            ]);
            $result = array('code' => 0, 'data' => $rs);
            echo json_encode($result);

        } else {
            $result = array('code' => 1, 'data' => []);
            echo json_encode($result);
        }
        die;
    }

    public function register_new()
    {
        

        $param = $this->request->query;
        CakeLog::write('UserController', "register_new" . json_encode($param));
        $username = $param["username"];
        $password = $param["password"];
        $captcha = strtolower($param["captcha"]);
        $verify = $param["verify"];
        $type = $param["type"];

        //check captcha
        if (md5($captcha . KEY_ENCODE) != $verify) {
            $result = array('status' => $this->ZING_PORTAL_ERROR_SESSION_VALID, 'data' => "");
            echo json_encode($result);
            die;
        }

        //check ip

        $ip = $this->requestAction(['controller' => 'GameManager', 'action' => 'getRealIpAddr']);
        $ipTotal = $this->User->find("count", [
            'conditions' => [
                'User.ipaddress' => $ip,
                'DATE(User.created)' => date("Y-m-d"),
            ]
        ]);

//                echo $ipTotal;

        if ($ipTotal > MAX_IP_REGISTER) {
            $result = array('status' => $this->ZING_PORTAL_ERROR_IP_MAX_REGISTER, 'data' => "");
            echo json_encode($result);
            die;
        }

        $user = $this->User->find("first", [
            'conditions' => [
                'User.username' => $username,
            ]
        ]);

        if (count($user) > 0) {
            $result = array('status' => $this->ZING_PORTAL_ERROR_USERNAME_ALREADY_EXISTED, 'data' => "");
            echo json_encode($result);
            die;
        }
        $curDate = date("Y-m-d H:i:s");
        $sid = Util::random_string(32);
        $rs = $this->User->save(array('username' => $username, 'password' => md5($password), 'first_login' => $curDate, 'total_login' => 0, 'ipaddress' => $ip, 'type' => $type, 'avatar' => '', 'sid' => $sid));
        if (count($rs) > 0) {
            $result = array('status' => $this->zingmeCodeSuccess, 'data' => array('username' => $rs['User']['username'], 'zpid' => $rs['User']['id'],
                'avatar' => "", 'acs' => 0, 'sid' => $sid));
            echo json_encode($result);
            die;
        } else {
            $result = array('status' => -1, 'data' => "2");
            echo json_encode($result);
            die;
        }
    }

    private function initData($user, $curDate)
    {
        $rUser = $this->TaixiuUser->find("first", [
            'conditions' => [
                'id' => $user['User']['id'],
            ]
        ]);
        if (count($rUser) == 0) {
            $this->TaixiuUser->save(array(
                'id' => $user['User']['id'],
                'displayname' => $user['User']['displayname'],
                'totalWon' => 0,
                'totalLost' => 0,
                'dailyWon' => 0,
                'dailyLost' => 0,
                'dailyTop' => 0,
                'highestWon' => 0,
                'highestLost' => 0,
                'betTai' => 0,
                'betXiu' => 0,
                'betWon' => 0,
                'betLost' => 0,
                'dailyWon_1' => 0,
                'dailyLost_1' => 0,
                'weeklyWon' => 0,
                'weeklyLost' => 0,
                'weeklyTop' => 0,
                'weeklyWon_1' => 0,
                'weeklyLost_1' => 0,
                'last_update' => $curDate
            ));
        }

        $rUser = $this->UserVpRanking->find("first", [
            'conditions' => [
                'id' => $user['User']['id'],
            ]
        ]);

        if (count($rUser) == 0) {
            $this->UserVpRanking->save(array(
                'id' => $user['User']['id'],
                'username' => $user['User']['username'],
                'displayname' => $user['User']['displayname'],
                'level' => 0,
                'vip_level' => 0,
                'playing_vp' => 0,
                'presenting_vp' => 0,
                'total_vp' => 0,
                'gold' => 0,
                'coin' => 0,
                'serverid' => 0,
                'last_update' => $curDate
            ));
        }
    }

    public function registerrv()
    {

        

        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));
        $api = $param["api"];
        $gameId = $param["gameId"];

        $curDate = date("Y-m-d H:i:s");
        if (isset($param["accessToken"])) {//flow xác thực đăng ký và trả về sessionKey
            $distribution = $param["distribution"];
            $clientInfo = $param["clientInfo"];
            $social = $param["social"];
            $accessToken = $param["accessToken"];
            $partnerId = $param["partnerId"];

            $sessionKey = "";
            $ip = $this->requestAction(['controller' => 'GameManager', 'action' => 'getRealIpAddr']);
            if(empty($ip))
                $ip = "0.0.0.0";
            if ($social == "zacc" || $social == "zaccauto") {
                $user = $this->User->find("first", [
                    'conditions' => [
                        'User.sessionkey' => $accessToken,
                    ]
                ]);
                if (count($user) > 0) {
                    $infoEnCode = "ipaddress=".$ip."&id=" . urlencode($user["User"]["id"]) . "&" . "username=" . urlencode($user["User"]["username"]) . "&" . "social=zacc&socialname=" . urlencode($user["User"]["username"]) . "&avatar=default&time=" . urlencode(time());

                    $this->initData($user, $curDate);
                    $this->User->save([
                        'id' => $user['User']['id'],
                        'sessionkey' => "",
                    ]);

                } else {
                    $result = array('error' => -1, 'sessionKey' => "", 'openId' => "");
                    echo json_encode($result);
                    die;
                }
            } else {
                $user_details = "https://graph.facebook.com/me?fields=id,name,picture.type(large){url}&access_token=" . $accessToken;
                $response = file_get_contents($user_details);
                $response = json_decode($response);


                //add User
                $user = $this->User->find("first", [
                    'conditions' => [
                        'User.username' => $response->id,
                    ]
                ]);
                $userID = "";
                if (count($user) <= 0) {
                    $rs = $this->User->save(array(
                        'username' => $response->id,
                        'first_login' => $curDate,
                        'total_login' => 1,
                        'type' => $this->TYPE_LOGIN_FACEBOOK,
                        'displayname' => "",
                        'avatar' => $response->picture->data->url));
                    $userID = $rs['User']['id'];
                    $user = $rs;
                } else {
                    $userID = $user['User']['id'];
                    $this->User->save([
                        'id' => $user['User']['id'],
                        'total_login' => ($user['User']['total_login'] + 1),
                    ]);
                }

                $info = "id=" . $userID . "&" . "username=fb." . $response->id . "&" . "social=facebook&socialname=" . $response->name . "&avatar=" . $response->picture->data->url . "&time=" . time();
                $infoEnCode = "ipaddress=".$ip."&id=" . $userID . "&" . "username=fb." . urlencode($response->id) . "&" . "social=facebook&socialname=" . urlencode($response->name) . "&avatar=" . urlencode($response->picture->data->url) . "&time=" . urlencode(time());


                $this->initData($user, $curDate);
            }

            //gen token key
            $gameKey = md5($gameId . '' . portal_secret_key);
            $validKey = md5($infoEnCode . '' . $gameKey);
            $sessionKey = $infoEnCode . "&other=sea&tokenKey=" . $validKey;
            $sessionKey = base64_encode($sessionKey);
            $result = array('error' => $this->ZINGME_ERROR_SUCCESS, 'sessionKey' => $sessionKey, 'openId' => $clientInfo);
            echo json_encode($result);
            die;

        } else {
            $service_name = $param["service_name"];
            if ($service_name == "zacc_register") {//flow đăng ký
                $username = $param["username"];
                $password = $param["password"];
                $email = $param["email"];
                //check ip

                $ip = $this->requestAction(['controller' => 'GameManager', 'action' => 'getRealIpAddr']);
                $ipTotal = $this->User->find("count", [
                    'conditions' => [
                        'User.ipaddress' => $ip,
                        'User.created' => date("Y-m-d"),
                    ]
                ]);

//                echo $ipTotal;

                if ($ipTotal > MAX_IP_REGISTER) {
                    $result = array('status' => $this->ZING_PORTAL_ERROR_IP_MAX_REGISTER, 'data' => "");
                    echo json_encode($result);
                    die;
                }

                $user = $this->User->find("first", [
                    'conditions' => [
                        'User.username' => $username,
                    ]
                ]);

                if (count($user) > 0) {
                    $result = array('status' => $this->ZING_PORTAL_ERROR_USERNAME_ALREADY_EXISTED, 'data' => "");
                    echo json_encode($result);
                    die;
                }

                $sid = Util::random_string(32);
                $rs = $this->User->save(array('username' => $username, 'password' => $password, 'email' => $email,'first_login' => $curDate, 'total_login' => 1, 'ipaddress' => $ip, 'type' => $this->TYPE_LOGIN_PORTAL, 'avatar' => '', 'sessionkey' => $sid));
                if (count($rs) > 0) {
                    $result = array('status' => $this->zingmeCodeSuccess, 'data' => array('username' => $rs['User']['username'], 'zpid' => $rs['User']['id'],
                        'avatar' => "", 'acs' => 0, 'sid' => $sid));
                    echo json_encode($result);
                    die;
                } else {
                    $result = array('status' => -1, 'data' => "2");
                    echo json_encode($result);
                    die;
                }
            } else if ($service_name == "zacc_login") {//flow đăng nhập
                $username = $param["username"];
                $password = $param["password"];
                $user = $this->User->find("first", [
                    'conditions' => [
                        'User.username' => $username,
                        'User.password' => $password,

                    ]
                ]);

                if (count($user) == 0) {
                    $result = array('status' => $this->ZING_PORTAL_ERROR_USERNAME_PASSWORD_NOT_MATCH, 'data' => "");
                    echo json_encode($result);
                    die;
                } else {
                    if (($user['User']['id'] < 1003496 && $user['User']['id'] > 1003299) || ($user['User']['id'] < 1038317 && $user['User']['id'] > 1038215)) {
                        $result = array('status' => $this->ZING_PORTAL_ERROR_USERNAME_PASSWORD_NOT_MATCH, 'data' => "");
                        echo json_encode($result);
                        die;
                    }
                    //Update số lần đăng nhập
                    $sid = Util::random_string(32);
                    $this->User->save([
                        'id' => $user['User']['id'],
                        'total_login' => ($user['User']['total_login'] + 1),
                        'sessionkey' => $sid,
                    ]);

                    $result = array('status' => $this->zingmeCodeSuccess, 'data' => array('username' => $username, 'zpid' => $password,
                        'avatar' => "", 'acs' => 0, 'sid' => $sid));
                    CakeLog::write('UserController', 'infoEnCode'. json_encode($result));
                    echo json_encode($result);
                }
            }
        }
        die;
    }


    public function register()
    {

        

        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));
        $api = $param["api"];
        $gameId = $param["gameId"];

        $curDate = date("Y-m-d H:i:s");
        if (isset($param["accessToken"])) {//flow xác thực đăng ký và trả về sessionKey
            $distribution = $param["distribution"];
            $clientInfo = $param["clientInfo"];
            $social = $param["social"];
            $accessToken = $param["accessToken"];
            $partnerId = $param["partnerId"];

            $sessionKey = "";
            $ip = $this->requestAction(['controller' => 'GameManager', 'action' => 'getRealIpAddr']);
            if(empty($ip))
                $ip = "0.0.0.0";
            if ($social == "zacc" || $social == "zaccauto") {
                $user = $this->User->find("first", [
                    'conditions' => [
                        'User.sessionkey' => $accessToken,
                    ]
                ]);
                if (count($user) > 0) {
                    $infoEnCode = "ipaddress=".$ip."&id=" . urlencode($user["User"]["id"]) . "&" . "username=" . urlencode($user["User"]["username"]) . "&" . "social=zacc&socialname=" . urlencode($user["User"]["username"]) . "&avatar=default&time=" . urlencode(time());

                    $this->initData($user, $curDate);
                    $this->User->save([
                        'id' => $user['User']['id'],
                        'sessionkey' => "",
                    ]);
                } else {
                    $result = array('error' => -1, 'sessionKey' => "", 'openId' => "");
                    echo json_encode($result);
                    die;
                }
            } else {
                $user_details = "https://graph.facebook.com/me?fields=id,name,picture.type(large){url}&access_token=" . $accessToken;
                $response = file_get_contents($user_details);
                $response = json_decode($response);


                //add User
                $user = $this->User->find("first", [
                    'conditions' => [
                        'User.username' => $response->id,
                    ]
                ]);
                $userID = "";
                if (count($user) <= 0) {
                    $rs = $this->User->save(array(
                        'username' => $response->id,
                        'first_login' => $curDate,
                        'created' => $curDate,
                        'total_login' => 1,
                        'ipaddress' => $ip,
                        'type' => $this->TYPE_LOGIN_FACEBOOK,
                        'displayname' => "",
                        'avatar' => $response->picture->data->url));
                    $userID = $rs['User']['id'];
                    $user = $rs;
                } else {
                    $userID = $user['User']['id'];
                    $this->User->save([
                        'id' => $user['User']['id'],
                        'total_login' => ($user['User']['total_login'] + 1),
                    ]);
                }

                $info = "id=" . $userID . "&" . "username=fb." . $response->id . "&" . "social=facebook&socialname=" . $response->name . "&avatar=" . $response->picture->data->url . "&time=" . time();
                $infoEnCode = "ipaddress=".$ip."&id=" . $userID . "&" . "username=fb." . urlencode($response->id) . "&" . "social=facebook&socialname=" . urlencode($response->name) . "&avatar=" . urlencode($response->picture->data->url) . "&time=" . urlencode(time());


                $this->initData($user, $curDate);
            }


            //gen token key
            $gameKey = md5($gameId . '' . portal_secret_key);
            $validKey = md5($infoEnCode . '' . $gameKey);
            $sessionKey = $infoEnCode . "&other=sea&tokenKey=" . $validKey;
            $sessionKey = base64_encode($sessionKey);
            $result = array('error' => $this->ZINGME_ERROR_SUCCESS, 'sessionKey' => $sessionKey, 'openId' => $clientInfo);
            echo json_encode($result);
            die;

        } else {
            $service_name = $param["service_name"];
            if ($service_name == "zacc_register") {//flow đăng ký
                $username = $param["username"];
                $password = $param["password"];
                $captcha = strtolower($param["captcha"]);
                $verify = $param["verify"];
                $requestid = $param["requestid"];

                //                pr($param);
                $ck = CaptchaController::checkCaptcha($this,$captcha, $verify, $requestid);
                //                echo $ck;
                if ($ck != 0) {
                    $result = array('status' => $this->ZING_PORTAL_ERROR_CAPTCHA, 'data' => "");
                    echo json_encode($result);
                    die;
                }
                //check ip
                $ip = $this->requestAction(['controller' => 'GameManager', 'action' => 'getRealIpAddr']);
                $ipTotal = $this->User->find("count", [
                    'conditions' => [
                        'User.ipaddress' => $ip,
                        'DATE(User.created)' => date("Y-m-d"),
                    ]
                ]);
                CakeLog::write('UserController', 'getRealIpAddr ok: ' . $ip);

//                echo $ipTotal;

                if ($ipTotal > MAX_IP_REGISTER) {
                    $result = array('status' => $this->ZING_PORTAL_ERROR_IP_MAX_REGISTER, 'data' => "");
                    echo json_encode($result);
                    die;
                }

                $user = $this->User->find("first", [
                    'conditions' => [
                        'User.username' => $username,
                    ]
                ]);

                if (count($user) > 0) {
                    $result = array('status' => $this->ZING_PORTAL_ERROR_USERNAME_ALREADY_EXISTED, 'data' => "");
                    echo json_encode($result);
                    die;
                }

                $sid = Util::random_string(32);
                $rs = $this->User->save(array(
                        'username' => $username,
                        'password' => md5($password . KEY_ENCODE),
                        'created' => $curDate,
                        'agency' => 0,
                        'first_login' => $curDate,
                        'total_login' => 1,
                        'ipaddress' => $ip,
                        'type' => $this->TYPE_LOGIN_PORTAL,
                        'avatar' => '',
                        'sessionkey' => $sid,
                        'displayname' => '',
                        'invite_friend' => '',
                        'invite_friend' => '',
                        'email' => '',
                        'phone' => '',
                        'userid' => 0,
                        'deviceid' => '',
                        'deviceToken' => '',
                        'typeOS' => 0,
                        'sid' => $sid,
                        'acs' => 0,
                        )
                    );
                if (count($rs) > 0) {
                    $result = array('status' => $this->zingmeCodeSuccess, 'data' => array('username' => $rs['User']['username'], 'zpid' => $rs['User']['id'],
                    'avatar' => "", 'acs' => 0, 'sid' => $sid));
                    echo json_encode($result);
                    die;
                } else {
                    $result = array('status' => -1, 'data' => "2");
                    echo json_encode($result);
                    die;
                }
            } else if ($service_name == "zacc_login") {//flow đăng nhập
                $username = $param["username"];
                $password = $param["password"];
                $user = $this->User->find("first", [
                    'conditions' => [
                        'User.username' => $username,
                        'User.password' => md5($password . KEY_ENCODE),

                    ]
                ]);

                if (count($user) == 0) {
                    $passmd5 = md5($password . KEY_ENCODE);
                    $result = array('status' => $this->ZING_PORTAL_ERROR_USERNAME_PASSWORD_NOT_MATCH, 'data' => $passmd5);
                    echo json_encode($result);
                    die;
                } else {
                    if (($user['User']['id'] < 1003496 && $user['User']['id'] > 1003299) || ($user['User']['id'] < 1038317 && $user['User']['id'] > 1038215)) {
                        $result = array('status' => $this->ZING_PORTAL_ERROR_USERNAME_PASSWORD_NOT_MATCH, 'data' => "");
                        echo json_encode($result);
                        die;
                    }
                    //Update số lần đăng nhập
                    $sid = Util::random_string(32);
                    $this->User->save([
                        'id' => $user['User']['id'],
                        'total_login' => ($user['User']['total_login'] + 1),
                        'sessionkey' => $sid,
                    ]);

                    $result = array('status' => $this->zingmeCodeSuccess, 'data' => array('username' => $username, 'zpid' => $password,
                        'avatar' => "", 'acs' => 0, 'sid' => $sid));
                    CakeLog::write('UserController', 'infoEnCode'. json_encode($result));
                    echo json_encode($result);
                }
            }
        }
        die;
    }

    public function addClub()
    {
        
        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (isset($param["userid"]) && isset($param["useridTarget"]) && isset($param["token"])) {

            $check = $this->checkToken($param["userid"], $param["token"]);
            if ($check == 0) {
                $result = array(101);
                echo json_encode($result);
                die;
            }

            $rs = $this->Club->find("first", [
                'conditions' => [
                    'userid' => $param["userid"],
                ]
            ]);
            if (count($rs) > 0) {
                $result = array(1);
                echo json_encode($result);
                die;
            }

            $rs = $this->Agency->find("first", [
                'conditions' => [
                    'userid' => $param["useridTarget"],
                ]
            ]);
            if (count($rs) == 0) {
                $result = array(2);
                echo json_encode($result);
                die;
            }

            $this->Club->save(array(
                'userid' => $param["userid"],
                'useridTarget' => $param["useridTarget"],
                'created' => $curDate
            ));
            $result = array(0);
            echo json_encode($result);
            die;
        }
        die;
    }

    //Event TOP VP
    public function getTopVP()
    {
        

//        header('Access-Control-Allow-Origin: *');
        $rs = $this->KpiUserChat->query("
        select `zp_play_vip_changes`.`userid`, `zp_play_vip_changes`.`displayname` ,sum(`zp_play_vip_changes`.`vip_change`) as vpoint
        from `zp_play_vip_changes`
        WHERE DATE(`create_date`) >= '2018-12-23' and DATE(`create_date`) <= '2018-12-30'
        GROUP BY `zp_play_vip_changes`.`userid`
        ORDER BY vpoint DESC
        LIMIT 20
        ");
        $list = [];
        for ($i = 0; $i < count($rs); $i++) {
            $list[$i] = $rs[$i]['zp_play_vip_changes'];
            $list[$i]['vpoint'] = $rs[$i][0]['vpoint'];
        }
        echo json_encode($list);
        die;
    }

    public function getPresentingVP()
    {
        
//        header('Access-Control-Allow-Origin: *');
        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (isset($param["userid"]) && isset($param["token"])) {

            $check = $this->checkToken($param["userid"], $param["token"]);
            if ($check == 0) {
                echo json_encode(array("code" => 101, "vpoint" => 0));
                die;
            }
            $rs = $this->KpiUserChat->query("
              select sum(`vip_point_add`) as vip from `zp_presenting_vip_changes` where `userid` = " . intval($param["userid"]) . "
            ");
//            pr($rs);
            if ($rs[0][0]['vip'])
                echo json_encode(array("code" => 0, "vpoint" => $rs[0][0]['vip']));
            else
                echo json_encode(array("code" => 0, "vpoint" => 0));
            die;
        }
        echo json_encode(array("code" => 2, "vpoint" => 0));
        die;
    }
    //--------------------


    //Event XO SO
    public function getUserInfoEventXS()
    {
        

//        header('Access-Control-Allow-Origin: *');
        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (isset($param["userid"]) && isset($param["token"])) {

            $check = $this->checkToken($param["userid"], $param["token"]);
            if ($check == 0) {
                $rs = array("code" => 101, "mess" => "Lỗi bảo mật", "vpoin" => 0, "data" => []);
                echo json_encode($rs);
                die;
            }
            $dateStart = "2019-01-16";
            $dateEnd = "2019-01-24 18:00:00";
            $rs = $this->KpiUserChat->query("
              select sum(`vip_change`) as vip from `zp_play_vip_changes` where `userid` = ".intval($param["userid"])." 
              and DATE(create_date) > '".mysql_real_escape_string($dateStart)."' and create_date <= '".mysql_real_escape_string($dateEnd)."'");
//            pr($rs);
            $vp = 0;
            if ($rs[0][0]['vip'])
                $vp = $rs[0][0]['vip'];

            $ve = $this->Agency->query("select * from event_xs where userid = " . intval($param["userid"]));
//            $vp = 100000;

            $vpUser = $vp - count($ve) * 10;
            $rs = array("code" => 0, "mess" => "Thành công", "vpoin" => $vpUser, "data" => $ve);

        } else {
            $rs = array("code" => 1, "mess" => "Thiếu dữ liệu", "vpoin" => 0, "data" => []);
        }
        echo json_encode($rs);
        die;
    }

    public function getInfoEventXS()
    {
        

//        header('Access-Control-Allow-Origin: *');
        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (isset($param["userid"]) && isset($param["token"])) {

            $check = $this->checkToken($param["userid"], $param["token"]);
            if ($check == 0) {
                $rs = array("code" => 101, "mess" => "Lỗi bảo mật", "data" => []);
                echo json_encode($rs);
                die;
            }
            $rs = [];
            for ($i = 0; $i < 100; $i++) {
                $total = $this->EventXs->find('all', [
                    'fields' => [
                        'COUNT(num) as total',
                    ],
                    'conditions' => array(
                        'num' => $i
                    )
                ]);
                $t = 0;
                if ($total[0][0]['total'])
                    $t = $total[0][0]['total'];
                $rs[$i] = array("num" => $i, "total" => $t);

            }

            $rs = array("code" => 0, "mess" => "Thành công", "data" => $rs);

        } else {
            $rs = array("code" => 1, "mess" => "Thiếu dữ liệu", "data" => []);
        }
        echo json_encode($rs);
        die;
    }

    public function getDetailEventXS()
    {
        

//        header('Access-Control-Allow-Origin: *');
        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (isset($param["userid"]) && isset($param["token"]) && isset($param["num"])) {

            $check = $this->checkToken($param["userid"], $param["token"]);
            if ($check == 0) {
                $rs = array("code" => 101, "mess" => "Lỗi bảo mật", "data" => []);
                echo json_encode($rs);
                die;
            }
            $detail = $this->EventXs->find('all', [
                'fields' => [
                    'COUNT(num) as total',
                    'userid',
                    'displayname'
                ],
                'conditions' => array(
                    'num' => $param["num"]
                ),
                'group' => [
                    'userid'
                ]
            ]);
//            pr($detail);
            $kq = [];
            for ($i = 0; $i < count($detail); $i++) {
                $detail[$i]["EventXs"]["total"] = $detail[$i][0]["total"];
                $kq[$i] = $detail[$i]["EventXs"];
            }


            $rs = array("code" => 0, "mess" => "Thành công", "data" => $kq);

        } else {
            $rs = array("code" => 1, "mess" => "Thiếu dữ liệu", "data" => []);
        }
        echo json_encode($rs);
        die;
    }

    public function buyTicketEventXS()
    {
        

//        header('Access-Control-Allow-Origin: *');
        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (isset($param["userid"]) && isset($param["token"]) && isset($param["num"]) && isset($param["displayname"])) {

            $check = $this->checkToken($param["userid"], $param["token"]);
            if ($check == 0) {
                $rs = array("code" => 101, "mess" => "Đã có lỗi.", "vpoin" => 0, "data" => []);
                echo json_encode($rs);
                die;
            }

            $dateStart = "2019-01-16";
            $dateEnd = "2019-01-24 18:00:00";
            if ($curDate <= $dateStart || $curDate > $dateEnd) {
                $rs = array("code" => 6, "mess" => "Sự kiện chưa diễn ra", "vpoin" => 0, "data" => []);
                echo json_encode($rs);
                die;
            }

            $rs = $this->KpiUserChat->query("
              select sum(`vip_change`) as vip from `zp_play_vip_changes` where `userid` = " . intval($param["userid"]) . " 
              and DATE(create_date) > '" . mysql_real_escape_string($dateStart) . "' and create_date <= '" . mysql_real_escape_string($dateEnd) . "'");
//            pr($rs);
            $vp = 0;
            if ($rs[0][0]['vip'])
                $vp = $rs[0][0]['vip'];

            $ve = $this->EventXs->query("select * from event_xs where userid = " . intval($param["userid"]));
//            $vp = 100000;
            $vpUser = $vp - count($ve) * 10;

            if ($vpUser >= 10) {
                $vpUser = $vpUser - 10;
                $this->EventXs->save(array(
                    "userid" => $param["userid"],
                    "displayname" => $param["displayname"],
                    "num" => $param["num"],
                    "created" => $curDate,
                ));
                $ve = $this->EventXs->query("select * from event_xs where userid = " . intval($param["userid"]));
                $rs = array("code" => 0, "mess" => "Chúc mừng bạn mua vé thành công", "vpoin" => $vpUser, "data" => $ve);
            } else {
                $rs = array("code" => 2, "mess" => "Không đủ VPoint để mua vé", "vpoin" => $vpUser, "data" => $ve);
            }

        } else {
            $rs = array("code" => 1, "mess" => "Thiếu dữ liệu", "vpoin" => 0, "data" => []);
        }
        echo json_encode($rs);
        die;
    }

    public function lich_su_giao_dich(){
        

        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (isset($param["userid"]) && isset($param["token"]) && isset($param["type"])) {

            $check = $this->checkToken($param["userid"], $param["token"]);
            if ($check == 0) {
                $rs = array("code" => 101, "mess" => "Lỗi không xác định ", "data" => []);
                echo json_encode($rs);
                die;
            }
//            echo "1";
            $list = $this->UserTransaction->find("all",[
                'conditions' => [
                    'userID' => $param["userid"],
                    'transType' => $param["type"],
                ],
                'order' => 'id desc',
                'limit' => 100
            ]);
//            echo "2";
            $rs = array("code" => 0, "mess" => "Thành công", "data" => $list);
        }else {
            $rs = array("code" => 1, "mess" => "Thiếu dữ liệu", "data" => []);
        }

        echo json_encode($rs);
        die;
    }

    public function lich_su_nap(){
        

        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (isset($param["userid"]) && isset($param["token"])) {

            $check = $this->checkToken($param["userid"], $param["token"]);
            if ($check == 0) {
                $rs = array("code" => 101, "mess" => "Lỗi không xác định ", "data" => []);
                echo json_encode($rs);
                die;
            }
            $list = $this->ListCard->find("all",[
                'conditions' => [
                    'userID' => $param["userid"]
                ],
                'order' => 'id desc',
            ]);

            $rs = array("code" => 0, "mess" => "Thành công", "data" => $list);
        }else {
            $rs = array("code" => 1, "mess" => "Thiếu dữ liệu", "data" => []);
        }
        echo json_encode($rs);
        die;
    }

    public function get_tai_xiu_du_day(){
        

        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        $curDay = date("Y-m-d");

        if (isset($param["data"])) {
            if($curDay == ($param["data"])){
                $daythang = $this->TaixiuUser->find("all",[
                    'fields' => [
                        'displayname',
                        'highestWon as result',
                    ],
                    'limit' => 10,
                    'order' => ['highestWon desc', 'last_update asc']
                ]);

                $daythua = $this->TaixiuUser->find("all",[
                    'fields' => [
                        'displayname',
                        'highestLost as result',
                    ],
                    'limit' => 10,
                    'order' => ['highestLost desc', 'last_update asc']
                ]);
                foreach($daythang as $k => $v) {
                    if ($k == 0) {
                        $daythang[0]['TaixiuUser']['gold'] = 2000000;        
                    } else if ($k == 1) {
                        $daythang[1]['TaixiuUser']['gold'] = 1000000;        
                    } else if ($k == 2) {
                        $daythang[2]['TaixiuUser']['gold'] = 500000;     
                    } else if ($k == 3) {
                        $daythang[3]['TaixiuUser']['gold'] = 200000;       
                    } else if ($k == 4) {
                        $daythang[4]['TaixiuUser']['gold'] = 200000;   
                    } else if ($k == 5) {
                        $daythang[5]['TaixiuUser']['gold'] = 100000;
                    } else if ($k == 6) {
                        $daythang[6]['TaixiuUser']['gold'] = 100000;
                    } else if ($k == 7) {
                        $daythang[7]['TaixiuUser']['gold'] = 100000;
                    } else if ($k == 8) {
                        $daythang[8]['TaixiuUser']['gold'] = 50000;
                    } else if ($k == 9) {
                        $daythang[9]['TaixiuUser']['gold'] = 50000;
                    }
                }

                foreach($daythua as $k => $v) {
                    if ($k == 0) {
                        $daythua[0]['TaixiuUser']['gold'] = 2000000;        
                    } else if ($k == 1) {
                        $daythua[1]['TaixiuUser']['gold'] = 1000000;        
                    } else if ($k == 2) {
                        $daythua[2]['TaixiuUser']['gold'] = 500000;     
                    } else if ($k == 3) {
                        $daythua[3]['TaixiuUser']['gold'] = 200000;       
                    } else if ($k == 4) {
                        $daythua[4]['TaixiuUser']['gold'] = 200000;   
                    } else if ($k == 5) {
                        $daythua[5]['TaixiuUser']['gold'] = 100000;
                    } else if ($k == 6) {
                        $daythua[6]['TaixiuUser']['gold'] = 100000;
                    } else if ($k == 7) {
                        $daythua[7]['TaixiuUser']['gold'] = 100000;
                    } else if ($k == 8) {
                        $daythua[8]['TaixiuUser']['gold'] = 50000;
                    } else if ($k == 9) {
                        $daythua[9]['TaixiuUser']['gold'] = 50000;
                    }
                }

            }else{
                $daythang = $this->TaixiuRankingByDay->find("all",[
                    'fields' => [
                        'displayname',
                        'value as result',
                    ],
                    "conditions" => [
                        "type_rank" => 1,
                        "day" => $param["data"],
                    ],
                    'limit' => 10,
                    'order' => ['type_rank desc']
                ]);

                $daythua = $this->TaixiuRankingByDay->find("all",[
                    'fields' => [
                        'displayname',
                        'value as result',
                    ],
                    "conditions" => [
                        "type_rank" => 2,
                        "day" => $param["data"],
                    ],
                    'limit' => 10,
                    'order' => ['type_rank desc']
                ]);
                foreach($daythang as $k => $v) {
                    if ($k == 0) {
                        $daythang[0]['TaixiuRankingByDay']['gold'] = 2000000;        
                    } else if ($k == 1) {
                        $daythang[1]['TaixiuRankingByDay']['gold'] = 1000000;        
                    } else if ($k == 2) {
                        $daythang[2]['TaixiuRankingByDay']['gold'] = 500000;     
                    } else if ($k == 3) {
                        $daythang[3]['TaixiuRankingByDay']['gold'] = 200000;       
                    } else if ($k == 4) {
                        $daythang[4]['TaixiuRankingByDay']['gold'] = 200000;   
                    } else if ($k == 5) {
                        $daythang[5]['TaixiuRankingByDay']['gold'] = 100000;
                    } else if ($k == 6) {
                        $daythang[6]['TaixiuRankingByDay']['gold'] = 100000;
                    } else if ($k == 7) {
                        $daythang[7]['TaixiuRankingByDay']['gold'] = 100000;
                    } else if ($k == 8) {
                        $daythang[8]['TaixiuRankingByDay']['gold'] = 50000;
                    } else if ($k == 9) {
                        $daythang[9]['TaixiuRankingByDay']['gold'] = 50000;
                    }
                }

                foreach($daythua as $k => $v) {
                    if ($k == 0) {
                        $daythua[0]['TaixiuRankingByDay']['gold'] = 2000000;        
                    } else if ($k == 1) {
                        $daythua[1]['TaixiuRankingByDay']['gold'] = 1000000;        
                    } else if ($k == 2) {
                        $daythua[2]['TaixiuRankingByDay']['gold'] = 500000;     
                    } else if ($k == 3) {
                        $daythua[3]['TaixiuRankingByDay']['gold'] = 200000;       
                    } else if ($k == 4) {
                        $daythua[4]['TaixiuRankingByDay']['gold'] = 200000;   
                    } else if ($k == 5) {
                        $daythua[5]['TaixiuRankingByDay']['gold'] = 100000;
                    } else if ($k == 6) {
                        $daythua[6]['TaixiuRankingByDay']['gold'] = 100000;
                    } else if ($k == 7) {
                        $daythua[7]['TaixiuRankingByDay']['gold'] = 100000;
                    } else if ($k == 8) {
                        $daythua[8]['TaixiuRankingByDay']['gold'] = 50000;
                    } else if ($k == 9) {
                        $daythua[9]['TaixiuRankingByDay']['gold'] = 50000;
                    }
                }
            }
//            $daythang[1][]


            $rs = array("code" => 0, "mess" => "Thành công", "day" => $param["data"], "daythang" => $daythang, "daythua" => $daythua );
        }else {
            $rs = array("code" => 1, "mess" => "Thiếu dữ liệu", "day" => $param["data"],"daythang" => [], "daythua" => []);
        }
        $result =  json_encode($rs);
        $result = str_replace("TaixiuRankingByDay", "TaixiuUser", $result);
        echo $result;
        die;
    }

    public function getAwards()
    {
        

//        header('Access-Control-Allow-Origin: *');
        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (isset($param["userid"]) && isset($param["token"])) {

            $check = $this->checkToken($param["userid"], $param["token"]);
            if ($check == 0) {
                $rs = array("code" => 101, "vpoin" => 0, "data" => []);
                echo json_encode($rs);
                die;
            }

            $dateStart = "2019-01-16";
            $dateEnd = "2019-01-24 18:00:00";
            $fee_game = $this->FeeGame->find("first", [
                "fields" => [
                    "SUM(fee_tx) as fee_tx",
                    "SUM(fee_sl_tt) as fee_sl_tt",
                    "SUM(fee_sl_nc) as fee_sl_nc",
                    "SUM(fee_sl_LS) as fee_sl_LS",
                    "SUM(fee_mn_pk) as fee_mn_pk",
                    "SUM(fee_mn_kc) as fee_mn_kc",
                    "SUM(fee_mn_th) as fee_mn_th",
                    "SUM(fee_banca) as fee_banca",
                    "SUM(fee_game_bai) as fee_game_bai",
                    "(SUM(fee_tx) +  SUM(fee_sl_tt) + SUM(fee_sl_nc) + SUM(fee_sl_LS) + SUM(fee_mn_pk) + SUM(fee_mn_pk) + SUM(fee_mn_kc) + SUM(fee_mn_th) + SUM(fee_banca) + SUM(fee_game_bai)) as total"
                ],
                "conditions" => [
                    "DATE(created) > " => $dateStart,
                    "created <= " => $dateEnd
                ]
            ]);

//            pr($fee_game);

            $rs = array("code" => 0, "mess" => "Thành công", "award" => ceil($fee_game[0]['total'] * 0.1 + 20000000));
        } else {
            $rs = array("code" => 1, "mess" => "Thiếu dữ liệu", "award" => 0);
        }
        echo json_encode($rs);
        die;
    }

    //------------------------------

    public function getSlotInfo()
    {
        

//        header('Access-Control-Allow-Origin: *');
        $param = $this->request->query;
        CakeLog::write('UserController', json_encode($param));

            $rs = [];
            $id = 0;
            $miniSlot = $this->FeeGame->query("select gameid, spinfee, jackpot from minigames");

        $dt = [];
        $dt1 = [];
        $dt2 = [];
        $dt3 = [];
        for($i = 0; $i< count($miniSlot); $i++){
            if($miniSlot[$i]['minigames']['gameid'] == 2){
                $dt[] = $miniSlot[$i]['minigames']['jackpot'];
            }
            if($miniSlot[$i]['minigames']['gameid'] == 3){
                $dt1[] = $miniSlot[$i]['minigames']['jackpot'];
            }
            if($miniSlot[$i]['minigames']['gameid'] == 4){
                $dt2[] = $miniSlot[$i]['minigames']['jackpot'];
            }
            if($miniSlot[$i]['minigames']['gameid'] == 5){
                $dt3[] = $miniSlot[$i]['minigames']['jackpot'];
            }
        }

        $data = array("slotID" => 2,
            "listJackPot" => $dt);
        $rs[] = $data;
        $data = array("slotID" => 3,
            "listJackPot" => $dt1);
        $rs[] = $data;
        $data = array("slotID" => 4,
            "listJackPot" => $dt2);
        $rs[] = $data;
        $data = array("slotID" => 5,
            "listJackPot" => $dt3);
        $rs[] = $data;
//        $id++;

        $dt = [];
        $dt1 = [];
        $dt2 = [];
        $slot = $this->FeeGame->query("select id, name, jackpot from slot_games");
        for($i = 0; $i< count($slot); $i++){
            if($slot[$i]['slot_games']['id'] == 9){
                $dt[] = $slot[$i]['slot_games']['jackpot'];
            }
            if($slot[$i]['slot_games']['id'] == 7){
                $dt1[] = $slot[$i]['slot_games']['jackpot'];
            }
            if($slot[$i]['slot_games']['id'] == 6){
                $dt2[] = $slot[$i]['slot_games']['jackpot'];
            }
        }
        $data = array("slotID" => 9,
            "listJackPot" => $dt);
        $rs[] = $data;
        $data = array("slotID" => 7,
            "listJackPot" => $dt1);
        $rs[] = $data;
        $data = array("slotID" => 6,
            "listJackPot" => $dt2);
        $rs[] = $data;

        $banca1 = $this->FeeGame->query("select id, jackpotValue from fishing_jackpot where jackpotType = 1 order by id desc limit 1");
        $banca2 = $this->FeeGame->query("select id, jackpotValue from fishing_jackpot where jackpotType = 2 order by id desc limit 1");

        $dt = [$banca2[0]['fishing_jackpot']['jackpotValue'], $banca1[0]['fishing_jackpot']['jackpotValue']];
        $data = array("slotID" => 20,
            "listJackPot" => $dt);
        $rs[] = $data;

        echo json_encode($rs);

        die;
    }

    //EVENT TOP CHOI THANG GAME TAI XIU
    public function getTopWinTaiXiu()
    {
        
        $param = $this->request->query;
        CakeLog::write('UserController', 'getTopWinTaiXiu '. json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if (isset($param["userid"]) && isset($param["token"]) && isset($param["dateStart"]) && isset($param["dateEnd"])) {
            $check = $this->checkToken($param["userid"], $param["token"]);
            if ($check == 0) {
                $rs = array("code" => 101, "mess" => "Đã có lỗi.", "data" => []);
                echo json_encode($rs);
                die;
            }
            $dateStart = addslashes($param["dateStart"]);
            $dateEnd = addslashes($param["dateEnd"]);

            $rs = $this->TaixiuUser->query("
        select `taixiu_results`.`userid`, `taixiu_results`.`displayname` ,sum(`taixiu_results`.`gold`) as gold
        from `taixiu_results`
        WHERE DATE(`last_update`) >= '" . mysql_real_escape_string($dateStart) . "' and DATE(`last_update`) <= '" . mysql_real_escape_string($dateEnd) . "' and `taixiu_results`.`gold` > 0
        GROUP BY `taixiu_results`.`userid`
        ORDER BY gold DESC
        LIMIT 20
        ");
            $list = [];
            for ($i = 0; $i < count($rs); $i++) {
                $list[$i] = $rs[$i]['taixiu_results'];
                $list[$i]['gold'] = $rs[$i][0]['gold'];
            }
            $rs = array("code" => 0, "mess" => "Thành công", "data" => $list);
            echo json_encode($rs);
            die;
        }else{
            $check = $this->checkToken($param["userid"], $param["token"]);
            if ($check == 0) {
                $rs = array("code" => 1, "mess" => "Thiếu dữ liệu", "data" => []);
                echo json_encode($rs);
                die;
            }
        }
    }
}
