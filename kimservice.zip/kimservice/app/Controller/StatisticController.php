<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/16/2017
 * Time: 9:13 AM
 */
date_default_timezone_set('Asia/Ho_Chi_Minh');
class StatisticController
{
    public $uses = ['GiftCode', 'UserCode', 'EventCode'];
    public $dir = 'D:\DiepLN\Project\Game\server\ServerGame\server-zpsea-poker\trunk\logs';

    public function statisticUser(){

        $results = $this->getDirContents($this->dir);

        // Output one line until end-of-file
        $myfile = fopen($results[0], "r") or die("Unable to open file!");
        while(!feof($myfile)) {
            echo fgets($myfile) . "<br>";
        }
        fclose($myfile);
        die;
    }
    public function getDirAllContents($dir, &$results = array()){
        $files = scandir($dir);

        foreach($files as $key => $value){
            $path = realpath($dir.DIRECTORY_SEPARATOR.$value);
            if(!is_dir($path)) {
                $results[] = $path;
            } else if($value != "." && $value != "..") {
                $this->getDirContents($path, $results);
                //$results[] = $path;
            }
        }

        return $results;
    }
    public function getDirContents($dir, &$results = array()){
        $files = scandir($dir);

        foreach($files as $key => $value){
            $path = realpath($dir.DIRECTORY_SEPARATOR.$value);
            if(!is_dir($path)) {
                $results[] = $path;
            }
        }

        return $results;
    }
}