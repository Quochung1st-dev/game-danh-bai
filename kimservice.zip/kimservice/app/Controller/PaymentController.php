<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */date_default_timezone_set('Asia/Ho_Chi_Minh');
App::uses('PaymentPack', 'Model');
App::uses('OutPacket', 'Model');
class PaymentController extends AppController
{
    public $uses = ['User', 'Payment', 'PaymentManager', 'PaymentMethod', 'UserVerifiled'];

    private $SMS_1PAY = 1;
    private $SMS_EPAY = 2;
    private $SMS_VERIFILED_1PAY = 3;
    private $SMS_VERIFILED_EPAY = 4;
    private $socket;

    function check_mo_smsplus(){
//        http://13.229.51.203/casinoService/web/index.php/payment/check_mo_smsplus?access_key=e5bbvnlpzurbviwr2wns&amount=5000&command_code=HEY&mo_message=HEY NAP5 2017121910007&msisdn=841646037635&signature=4870e82f4b073a4128c207eb4e7598ddb4564c84f26d8781260d061b7b315d36&telco=vtm
        $param = $this->request->query;
        CakeLog::write('PaymentController',"check_mo_smsplus ".json_encode( $param));
        if (
            !isset($param['access_key']) ||
            !isset($param['amount']) ||
            !isset($param['command_code']) ||
            !isset($param['mo_message']) ||
            !isset($param['msisdn']) ||
            !isset($param['telco']) ||
            !isset($param['signature'])
        ){


            $arResponse['status'] = 0;
            $arResponse['sms'] = 'Khong hop le param';
        }else{
            $arParams['access_key'] = PAYMENT_1_access_key;//$param['access_key'] ? $param['access_key'] : '';
            $arParams['amount'] = $param['amount'] ? $param['amount'] : '';
            $arParams['command_code'] = $param['command_code'] ? $param['command_code'] : '';
            $arParams['mo_message'] = $param['mo_message'] ? $param['mo_message'] : '';
            $arParams['msisdn'] = $param['msisdn'] ? $param['msisdn'] : '';
            $arParams['telco'] = $param['telco'] ? $param['telco'] : '';
            $arParams['signature'] = $param['signature'] ? $param['signature'] : '';
            $data = "access_key=" . $arParams['access_key'] . "&amount=" . $arParams['amount'] . "&command_code=" . $arParams['command_code'] . "&mo_message=" . $arParams['mo_message'] . "&msisdn=" . $arParams['msisdn'] . "&telco=" . $arParams['telco'];
            $secret = PAYMENT_1_secret; //product's secret key (get value from 1Pay product detail)
            $signature = hash_hmac("sha256", $data, $secret); // create signature to check
            $arResponse['type'] = 'text';
            // kiem tra signature neu can
            if ($arParams['signature'] == $signature) {
                //if sms content and amount and ... are ok. return success case
                $arResponse['status'] = 1;
                $arResponse['sms'] = 'Hop le';
            }
            else {
                //if not. return fail case
                $arResponse['status'] = 0;
                $arResponse['sms'] = 'Khong hop le';
            }
        }
        // return json for 1pay system
        header('Content-type: application/json');
        echo json_encode($arResponse);
        die;
    }


    function testCard(){

        $checkSokcet = false;
        //Open socket to server
        if($this->socket == null) {
            $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        }
        if ($this->socket === false) {
            $checkSokcet = false;
        } else {
            $checkSokcet = true;
        }

        $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
        if ($result === false) {
            $checkSokcet = false;
        } else {
            $checkSokcet = true;
        }

        $p = new OutPacket(1, PAYMENT_MAX_PAY);
        $p->putInt(CARD);
        $p->putInt(1);
        $p->putString("mcard");
        $p->putString("mcard");
        $p->putLong(50000);
        $p->putLong(10085);
        $p->putString(php_secret_key);
        $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
        $pckLen = strlen($packet);
        socket_write($this->socket, $packet, $pckLen);
        socket_close($this->socket);
    }


    function testSMS(){

        $checkSokcet = false;
        //Open socket to server
        if($this->socket == null) {
            $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        }
        if ($this->socket === false) {
            $checkSokcet = false;
        } else {
            $checkSokcet = true;
        }

        $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
        if ($result === false) {
            $checkSokcet = false;
        } else {
            $checkSokcet = true;
        }

        $p = new OutPacket(1, PAYMENT_1_PAY_SMS);
        $p->putInt(SMS);
        $p->putInt(-1);
        $p->putString("sms");
        $p->putString("sms");
        $p->putLong(10000);
        $p->putLong(0);
        $p->putString(php_secret_key);
        $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
        $pckLen = strlen($packet);
        socket_write($this->socket, $packet, $pckLen);
        socket_cwlose($this->socket);
    }

    function smsplus1payverifiled(){
        header('Content-type: application/json');
        $param = $this->request->query;
        CakeLog::write('PaymentController', "smsplus1payverifiled " . json_encode($param));
        if (!isset($param['access_key']) ||
            !isset($param['command']) ||
            !isset($param['mo_message']) ||
            !isset($param['msisdn']) ||
            !isset($param['request_id']) ||
            !isset($param['request_time']) ||
            !isset($param['short_code']) ||
            !isset($param['signature'])
        ){
            $arResponse['type'] = 'text';
            $arResponse['status'] = 0;
            $arResponse['sms'] = 'Ban xac thuc tai khoan khong thanh cong. CSKH: 0967582955. Chuc ban choi game vui ve!!!';
        }else {
            $arParams['access_key'] = PAYMENT_1_access_key;//$param['access_key'] ? $param['access_key'] : '';
            $arParams['command'] = $param['command'] ? $param['command'] : '';
            $arParams['mo_message'] = $param['mo_message'] ? $param['mo_message'] : '';
            $arParams['msisdn'] = $param['msisdn'] ? $param['msisdn'] : '';
            $arParams['request_id'] = $param['request_id'] ? $param['request_id'] : '';
            $arParams['request_time'] = $param['request_time'] ? $param['request_time'] : '';
            $arParams['short_code'] = $param['short_code'] ? $param['short_code'] : '';
            $arParams['signature'] = $param['signature'] ? $param['signature'] : '';
            $data = "access_key=" . $arParams['access_key'] . "&command=" . $arParams['command'] . "&mo_message=" . $arParams['mo_message'] .
                "&msisdn=" . $arParams['msisdn'] . "&request_id=" . $arParams['request_id'] . "&request_time=" . $arParams['request_time'] .
                "&short_code=" . $arParams['short_code'];

            $secret = PAYMENT_1_secret; //product's secret key (get value from 1Pay product detail)
            $signature = hash_hmac("sha256", $data, $secret); // create signature to check
            $arResponse['type'] = 'text';

            //                MW QX NAPxx YYYYMMDDUSERID
            $arrSMS = explode(" ", $arParams['mo_message']);
            $userID = substr($arrSMS[count($arrSMS) - 1], 8, strlen($arrSMS[count($arrSMS) - 1]) - 8);
            $checkPhone = false;
            $phoneData = $this->UserVerifiled->find("count", [
                'conditions' => [
                    'UserVerifiled.phone' => $param['msisdn'],
                ]
            ]);
            if($phoneData >= NUMBER_PHONE_VERIFILED){
                $checkPhone = true;
            }

            $checkSokcet = false;
            //Open socket to server
            if($this->socket == null) {
                $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
            }
            if ($this->socket === false) {
                $checkSokcet = false;
            } else {
                $checkSokcet = true;
            }

            $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
            if ($result === false) {
                $checkSokcet = false;
            } else {
                $checkSokcet = true;
            }

            //                check request ID
            $pay = $this->Payment->find("first", [
                'conditions' => [
                    'Payment.requestid' => $arParams['request_id'],
                ]
            ]);

            $isTest = false;

            // kiem tra signature
            //Kiem tra request bi trung lap
            //Kiem tra connect socket
            if($checkPhone == true){
                $arResponse['status'] = 0;
                $arResponse['sms'] = 'So dien thoai de xac thuc da duoc su dung qua so lan quy dinh. CSKH: 0967582955. Chuc ban choi game vui ve!';
            }
            else if (count($pay) == 0 && $arParams['signature'] == $signature && $checkSokcet || $isTest ) {
                //if sms content and amount and ... are ok. return success case

                //Save data to database
                $this->UserVerifiled->save(array(
                    'user_id' => $userID,
                    'phone' => $param['msisdn'],
                    'created' => date("Y-m-d"),
                ));
                $this->Payment->save(array(
                    'userid' => $userID,
                    'command' => $arParams['command'],
                    'mo_message' => $arParams['mo_message'],
                    'msisdn' => $arParams['msisdn'],
                    'requestid' => $arParams['request_id'],
                    'request_time' => $arParams['request_time'],
                ));
                //Send pack to Server
                //hearder - size - size - controlerID - CMDID - type(VT - VN - MB) - price - UID
//                http://localhost/zpService/web/index.php/payment/smsplus1pay?access_key=access_key&amount=5000&command_code=command_code&error_code=error_code&error_message=error_message&mo_message=MW%20QX%20NAPxx%2020170615100002&msisdn=msisdn&request_id=request_id&request_time=2013-07-06T22:54:50Z&signature=signature

                $amount = 0;

                $arResponse['status'] = 1;
                $arResponse['sms'] = 'Ban xac thuc tai khoan co UID ' . $userID . '. Ma giao dich ' . $arrSMS[count($arrSMS) - 1] . '. CSKH: 0967582955. Chuc ban choi game vui ve!';

                $p = new OutPacket(1, PAYMENT_1_PAY_SMS);
                $p->putInt(SMS);
                $p->putInt(0);
                $p->putString("sms");
                $p->putString("sms");
                $p->putLong($amount);
                $p->putLong($userID);
                $p->putString(php_secret_key);
                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
            } else {
                //if not. return fail case
                $arResponse['status'] = 0;
                $arResponse['sms'] = 'Ban xac thuc tai khoan khong thanh cong!. CSKH: 0967582955. Chuc ban choi game vui ve!';
            }
        }
        // return json for 1pay system
        echo json_encode($arResponse);
        die;
    }

    function smsplus1pay(){
        //http://13.229.51.203/casinoService/web/index.php/payment/smsplus1pay?access_key=e5bbvnlpzurbviwr2wns&amount=5000&command_code=VIC&mo_message=VIC NAP5 2017121910007&msisdn=841646037635&signature=1c7e066b37b7674c7ccdfe7f46b6f6792ea9dc0d24f1a7cdaaed567fdfd65342&telco=vtm&error_code=WCG-0000&error_message=Giao dich thuc hien thanh cong&request_id=1pay_9029|mw_9029|84ef7dd8155f4d73955a4da64dc3f62b|841646037635|841646037635&request_time=2017-12-19T15:18:30Z
        header('Content-type: application/json');
        $param = $this->request->query;
        CakeLog::write('PaymentController', "smsplus1pay " . json_encode($param));
        if (!isset($param['access_key']) ||
            !isset($param['command_code']) ||
            !isset($param['mo_message']) ||
            !isset($param['msisdn']) ||
            !isset($param['request_id']) ||
            !isset($param['request_time']) ||
            !isset($param['amount']) ||
            !isset($param['signature']) ||
            !isset($param['error_code']) ||
            !isset($param['error_message'])
        ){
            $arResponse['type'] = 'text';
            $arResponse['status'] = 0;
            $arResponse['sms'] = 'Ban giao dich khong thanh cong. CSKH: 0967582955. Chuc ban choi game vui ve!!!';
        }else {
            $arParams['access_key'] = PAYMENT_1_access_key;//$param['access_key'] ? $param['access_key'] : '';
            $arParams['command_code'] = $param['command_code'] ? $param['command_code'] : '';
            $arParams['mo_message'] = $param['mo_message'] ? $param['mo_message'] : '';
            $arParams['msisdn'] = $param['msisdn'] ? $param['msisdn'] : '';
            $arParams['request_id'] = $param['request_id'] ? $param['request_id'] : '';
            $arParams['request_time'] = $param['request_time'] ? $param['request_time'] : '';
            $arParams['amount'] = $param['amount'] ? $param['amount'] : '';
            $arParams['signature'] = $param['signature'] ? $param['signature'] : '';
            $arParams['error_code'] = $param['error_code'] ? $param['error_code'] : '';
            $arParams['error_message'] = $param['error_message'] ? $param['error_message'] : '';
            $data = "access_key=" . $arParams['access_key'] . "&amount=" . $arParams['amount'] . "&command_code=" . $arParams['command_code'] . "&error_code=" . $arParams['error_code'] . "&error_message=" . $arParams['error_message'] . "&mo_message=" . $arParams['mo_message'] . "&msisdn=" . $arParams['msisdn'] . "&request_id=" . $arParams['request_id'] . "&request_time=" . $arParams['request_time'];
            $secret = PAYMENT_1_secret; //product's secret key (get value from 1Pay product detail)
            $signature = hash_hmac("sha256", $data, $secret); // create signature to check
            $arResponse['type'] = 'text';

            $checkSokcet = false;
            //Open socket to server
            if($this->socket == null) {
                $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
            }
            if ($this->socket === false) {
                $checkSokcet = false;
            } else {
                $checkSokcet = true;
            }

            $result = socket_connect($this->socket, HOST_SERVER, PORT_SERVER);
            if ($result === false) {
                $checkSokcet = false;
            } else {
                $checkSokcet = true;
            }

            //                check request ID
            $pay = $this->Payment->find("first", [
                'conditions' => [
                    'Payment.requestid' => $arParams['request_id'],
                ]
            ]);

            $isTest = false;

            // kiem tra signature
            //Kiem tra request bi trung lap
            //Kiem tra connect socket
            if (count($pay) == 0 && $arParams['signature'] == $signature && $checkSokcet || $isTest) {
                //if sms content and amount and ... are ok. return success case

                //Save data to database
//                MW QX NAPxx YYYYMMDDUSERID
                $arrSMS = explode(" ", $arParams['mo_message']);
                $userID = substr($arrSMS[count($arrSMS) - 1], 8, strlen($arrSMS[count($arrSMS) - 1]) - 8);
                $this->Payment->save(array(
                    'userid' => $userID,
                    'command_code' => $arParams['command_code'],
                    'mo_message' => $arParams['mo_message'],
                    'msisdn' => $arParams['msisdn'],
                    'requestid' => $arParams['request_id'],
                    'request_time' => $arParams['request_time'],
                    'amount' => $arParams['amount'],
                    'error_code' => $arParams['error_code'],
                    'error_message' => $arParams['error_message'],
                ));
                //Send pack to Server
                //hearder - size - size - controlerID - CMDID - type(VT - VN - MB) - price - UID
//                http://localhost/zpService/web/index.php/payment/smsplus1pay?access_key=access_key&amount=5000&command_code=command_code&error_code=error_code&error_message=error_message&mo_message=MW%20QX%20NAPxx%2020170615100002&msisdn=msisdn&request_id=request_id&request_time=2013-07-06T22:54:50Z&signature=signature
                $amount = $arParams['amount'];

                $arResponse['status'] = 1;
                $arResponse['sms'] = 'Ban da nap ' . $arParams['amount'] . 'VND vao TK ' . $userID . ' . Ma giao dich ' . $arrSMS[count($arrSMS) - 1] . '. CSKH: 0967582955. Chuc ban choi game vui ve!';

                $p = new OutPacket(1, PAYMENT_1_PAY_SMS);
                $p->putInt(SMS);
                $p->putInt(-1);
                $p->putString("sms");
                $p->putString("sms");
                $p->putLong($amount);
                $p->putLong($userID);
                $p->putString(php_secret_key);
                $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);
                $pckLen = strlen($packet);
                socket_write($this->socket, $packet, $pckLen);
                socket_close($this->socket);
            } else {
                //if not. return fail case
                $arResponse['status'] = 0;
                $arResponse['sms'] = 'Ban giao dich khong thanh cong!. CSKH: 0967582955. Chuc ban choi game vui ve!';
            }
        }
        // return json for 1pay system
        echo json_encode($arResponse);
        die;
    }

    //function POST
    function execPostRequest($url, $data)
    {

        // open connection
        $ch = curl_init();

        // set the url, number of POST vars, POST data
        curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,0);
        curl_setopt($ch, CURLOPT_TIMEOUT, 30);
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $data);
        curl_setopt($ch, CURLOPT_USERAGENT, $_SERVER['HTTP_USER_AGENT']);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, 2);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);

        // execute post
        $result = curl_exec($ch);

        // close connection
        curl_close($ch);
        return $result;
    }

    public function getsmssyntax(){
        header('Content-type: application/json');
        $param = $this->request->query;
        CakeLog::write('PaymentController','getsmssyntax '.json_encode( $param));
        if (!isset($param['userID'])){
            $result = array('status' => 1, "data" => "");
        }else {
            $userID = $param["userID"];
            $curDate = date("Ymd");
            $method = $this->PaymentMethod->find("first");
            if ($method['PaymentMethod']['method_sms'] == "epay") {
                $pay = $this->PaymentManager->find("all", [
                    'conditions' => [
                        'PaymentManager.type' => $this->SMS_EPAY
                    ]
                ]);
            }else{
                $pay = $this->PaymentManager->find("all", [
                    'conditions' => [
                        'PaymentManager.type' => $this->SMS_1PAY
                    ]
                ]);
            }

            $data =  array();
            for ($i = 0; $i < count($pay); $i++){
                $data[$i] = str_replace( "REF", $curDate . $userID, $pay[$i]["PaymentManager"]["sms_syntax"]).','.$pay[$i]["PaymentManager"]["phone_no"];
            }
            $result = array('status' => 0, "data" => $data);
        }
        echo json_encode($result);
        die;
    }

    public function getsmsverifiled(){
        header('Content-type: application/json');
        $param = $this->request->query;
        CakeLog::write('PaymentController', 'getsmsverifiled'.json_encode( $param));
        if (!isset($param['userID'])){
            $result = array('status' => 1, "data" => "");
        }else {
            $userID = $param["userID"];
            $curDate = date("Ymd");
            $method = $this->PaymentMethod->find("first");
            if ($method['PaymentMethod']['method_sms'] == "epay") {
                $pay = $this->PaymentManager->find("first", [
                    'conditions' => [
                        'PaymentManager.type' => $this->SMS_VERIFILED_EPAY
                    ]
                ]);
            }else{
                $pay = $this->PaymentManager->find("first", [
                    'conditions' => [
                        'PaymentManager.type' => $this->SMS_VERIFILED_1PAY
                    ]
                ]);
            }
            $rs = str_replace( "REF", $curDate . $userID, $pay["PaymentManager"]["sms_syntax"]).','.$pay["PaymentManager"]["phone_no"];
            $result = array('status' => 0, "data" => $rs);
        }
        echo json_encode($result);
        die;
    }

    public function card1pay(){
        header('Content-type: application/json');
        $param = $this->request->query;
        CakeLog::write('PaymentController', 'card1pay' . json_encode($param));
        $transRef = Util::random_string(32); //merchant's transaction reference

        if (!isset($param['lstTelco']) ||
            !isset($param['txtCode']) ||
            !isset($param['txtSeri']) ||
            !isset($param['userID'])
        ){
            $result = array('status' => 1, 'data' => "Thieu param");

        }else{
            $type = $param["lstTelco"];
            $pin = $param["txtCode"];
            $serial = $param["txtSeri"];
            $userID = $param["userID"];

            //get info
            $pay = $this->PaymentManager->find("first", [
                'conditions' => [
                    'PaymentManager.name' => $type
                ]
            ]);

            $access_key = $pay['PaymentManager']['access_key']; //require your access key from 1pay
            $secret = $pay['PaymentManager']['secret']; //require your secret key from 1pay

            $data = "access_key=" . $access_key . "&pin=" . $pin . "&serial=" . $serial . "&transRef=" . $transRef . "&type=" . $type;
            $signature = hash_hmac("sha256", $data, $secret);
            $data.= "&signature=" . $signature;


//do some thing
            $json_cardCharging = $this->execPostRequest('https://api.1pay.vn/card-charging/v5/topup', $data);
            $decode_cardCharging=json_decode($json_cardCharging,true);  // decode json
            if (isset($decode_cardCharging)) {
                $description = $decode_cardCharging["description"];   // transaction description
                $status = $decode_cardCharging["status"];
                $amount = $decode_cardCharging["amount"];       // card's amount
                $transId = $decode_cardCharging["transId"];
                // xử lý dữ liệu của merchant
                $result = array('status' => 0, 'data' => "Thanh cong");
            }
            else {
                // run query API's endpoint
                $data_ep = "access_key=" . $access_key . "&pin=" . $pin . "&serial=" . $serial . "&transId=&transRef=" . $transRef . "&type=" . $type;
                $signature_ep = hash_hmac("sha256", $data_ep, $secret);
                $data_ep.= "&signature=" . $signature_ep;
                $query_api_ep = $this->execPostRequest('https://api.1pay.vn/card-charging/v5/query', $data_ep);
                $decode_cardCharging=json_decode($json_cardCharging,true);  // decode json
                $description_ep = $decode_cardCharging["description"];   // transaction description
                $status_ep = $decode_cardCharging["status"];
                $amount_ep = $decode_cardCharging["amount"];       // card's amount
                $result = array('status' => 1, 'data' => "That bai");
// Merchant handle SQL
            }
        }

        echo json_encode($result);
        die;

    }


    public function soketdemo(){

//a	NUL-padded string
//A	SPACE-padded string
//h	Hex string, low nibble first
//H	Hex string, high nibble first
//c	signed char
//C	unsigned char
//s	signed short (always 16 bit, machine byte order)
//S	unsigned short (always 16 bit, machine byte order)
//n	unsigned short (always 16 bit, big endian byte order)
//v	unsigned short (always 16 bit, little endian byte order)
//i	signed integer (machine dependent size and byte order)
//I	unsigned integer (machine dependent size and byte order)
//l	signed long (always 32 bit, machine byte order)
//L	unsigned long (always 32 bit, machine byte order)
//N	unsigned long (always 32 bit, big endian byte order)
//V	unsigned long (always 32 bit, little endian byte order)
//q	signed long long (always 64 bit, machine byte order)
//Q	unsigned long long (always 64 bit, machine byte order)
//J	unsigned long long (always 64 bit, big endian byte order)
//P	unsigned long long (always 64 bit, little endian byte order)
//f	float (machine dependent size and representation)
//g	float (machine dependent size, little endian byte order)
//G	float (machine dependent size, big endian byte order)
//d	double (machine dependent size and representation)
//e	double (machine dependent size, little endian byte order)
//E	double (machine dependent size, big endian byte order)
//x	NUL byte
//X	Back up one byte
//Z	NUL-padded string (new in PHP 5.5)
//@	NUL-fill to absolute position


//        $st = "qx NAP MW QX NAP10 20170615100004";
//        $arrSMS = explode(" ",$st);
//        $userID = substr($arrSMS[count($arrSMS) - 1], 8, strlen($arrSMS[count($arrSMS) - 1]) - 8);
//        echo $userID;
//        die;

        if($this->socket == null) {
            $this->socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        }
        if ($this->socket === false) {
            echo "socket_create() failed: reason: " . socket_strerror(socket_last_error()) . "\n";
        } else {
            echo "OK.\n";
        }

        $result = socket_connect($this->socket, $this->host, $this->port);
        if ($result === false) {
            echo "socket_connect() failed.\nReason: ($result) " . socket_strerror(socket_last_error($this->socket)) . "\n";
        } else {
            echo "socket_connect OK.\n";
        }

        $p = new OutPacket(1, 8205);
        $p->putByte(1);
        $p->putLong(10000);
        $p->putLong(100002);

        pr($p);

        //hearder - size - size - controlerID - CMDID - type(VT - VN - MB) - price - UID
        $packet = pack("c*", -112, $p->_size / 256, $p->_size % 256, ...$p->_pack);

        $pckLen = strlen($packet);
        echo "send new data <br />";
        socket_write($this->socket, $packet, $pckLen);


//        socket_close($socket);

        die;
    }
}
