<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:11 PM
 */
date_default_timezone_set('Asia/Ho_Chi_Minh');
App::uses('OutPacket', 'Model');
App::uses('CakeEmail', 'Network/Email');
App::import("Controller", "Captcha");

class UseroptController extends AppController
{
    public $uses = ['User', 'UserVerifiled', 'Captchas'];


    private $STATUS_VERIFY_OK = 1;
    private $STATUS_VERIFY_NOT_OK = 2;

    private $TYPE_VERIFY_PHONE = 0;
    private $TYPE_ONE_TIME_PASS = 1;

    private $socket;

    private $SS = 0;
    private $LOI_NHA_CC = 1;
    private $LOI_CHUA_XAC_THUC = 2;
    private $LOI_SAI_PARAM = 3;

    public function requestsmsopt(){

        $param = $this->request->query;
        CakeLog::write('UserController', "requestopt ".json_encode($param));
        if(isset($param["userID"])){

            $captcha = strtolower($param["captcha"]);
            $verify = $param["verify"];
            $requestid = $param["requestid"];

//                pr($param);
            $ck = CaptchaController::checkCaptcha($this,$captcha, $verify, $requestid);
//                echo $ck;
            if ($ck != 0) {
                $result = array(25);
                echo json_encode($result);
                die;
            }
            $rs1 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $param["userID"],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_OK
                ]
            ]);

            if (count($rs1) != 0) {
                if($rs1['UserVerifiled']['status'] == 0){
                    $result = array($this->LOI_CHUA_XAC_THUC);//Chua xac thu so dien thoai
                    echo json_encode($result);
                    die;
                }
            }else{
                $result = array($this->LOI_CHUA_XAC_THUC);//Chua xac thu so dien thoai
                echo json_encode($result);
                die;
            }

            $code = $sid = Util::random_num(6);
            $Content="Ma OTP cua ban la: ".$code.", thoi han su dung 5 phut";

            $SendContent=urlencode($Content);
            $data="http://rest.esms.vn/MainService.svc/json/SendMultipleMessage_V4_get?Phone=".$rs1['UserVerifiled']["phone"]."&ApiKey=".APIKey."&SecretKey=".SecretKey."&Content=".$SendContent."&SmsType=2&Brandname=QCAO_ONLINE";

            $curl = curl_init($data);
            curl_setopt($curl, CURLOPT_FAILONERROR, true);
            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($curl);
            CakeLog::write('UserController', "requestopt result ". json_encode($result));
            $obj = json_decode($result,true);
            $curDate = date("Y-m-d H:i:s");
            if($obj['CodeResult']==100)
            {
                $this->UserVerifiled->save(array(
                    'id' => $rs1['UserVerifiled']['id'],

                    'created' => $curDate,
                    'code' => $code));
                $result = array($this->SS);//Sai ben dich vu
                echo json_encode($result);
            }else{
                $result = array($this->LOI_NHA_CC);//Sai ben dich vu
                echo json_encode($result);
            }

        }else{
            $result = array($this->LOI_SAI_PARAM);//Sai Param
            echo json_encode($result);
        }
        die;

    }
    public function requestemailotp(){

        $param = $this->request->query;
        CakeLog::write('UserController', "requestemailotp ".json_encode($param));
        if(isset($param["userID"])){

            $captcha = strtolower($param["captcha"]);
            $verify = $param["verify"];
            $requestid = $param["requestid"];

//                pr($param);
            $ck = CaptchaController::checkCaptcha($this,$captcha, $verify, $requestid);
//                echo $ck;
            if ($ck != 0) {
                $result = array(25);
                echo json_encode($result);
                die;
            }
            $rs1 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $param["userID"],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_OK
                ]
            ]);

            if (count($rs1) != 0) {
                if($rs1['UserVerifiled']['status'] == 0){
                    $result = array($this->LOI_CHUA_XAC_THUC);//Chua xac thu so dien thoai
                    echo json_encode($result);
                    die;
                }
            }else{
                $result = array($this->LOI_CHUA_XAC_THUC);//Chua xac thu so dien thoai
                echo json_encode($result);
                die;
            }

            $code = $sid = Util::random_num(6);
            $Content="Ma OTP cua ban la: ".$code.", thoi han su dung 5 phut";

            //send mail to user
            $result = $this->sendMail($rs1['UserVerifiled']['phone'], $Content, 'OTP Request'); //TODO: change param 'phone' -> 'email'
                    
            $result_code = $result;

            $curDate = date("Y-m-d H:i:s");
            if($result_code == 1)
            {
                $this->UserVerifiled->save(array(
                    'id' => $rs1['UserVerifiled']['id'],
                    'created' => $curDate,
                    'code' => $code));

                $result = array($this->SS); //success
                echo json_encode($result);
            }else{
                $result = array($this->LOI_NHA_CC);//Sai ben dich vu
                echo json_encode($result);
            }

        }else{
            $result = array($this->LOI_SAI_PARAM);//Sai Param
            echo json_encode($result);
        }
        die;

    }

    private function sendMail($to, $content, $subject){
        $Email = new CakeEmail();
        $Email->config('gmail') // gmail, smtp or any config you have created in email config
            ->emailFormat('text')
            ->from('piano.bestgame@gmail.com', 'Sill.Vip')
            ->to($to)
            ->subject($subject);

        if($Email->send($content)){
            return true;
        }else {
            return false;
        }
        die;
    }

    public function verifysmsotp(){
        header('Content-type: application/json');
        header('Access-Control-Allow-Origin: *');
        $param = $this->request->query;
        CakeLog::write('UserController', "verifyphone ".json_encode($param));
        if(isset($param["userID"]) && isset($param["code"])){

            $rs = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $param["userID"],
                    'UserVerifiled.code' => $param["code"]
                ]
            ]);
            if(count($rs) == 0){
                $result = array(3);
                echo json_encode($result);
                die;
            }
            $curDate = date("Y-m-d H:i:s");
            $t1 = strtotime($curDate);
            $t2 = strtotime($rs['UserVerifiled']['created']);
            if($t1 - $t2 > 5 * 60){//Code qua han su dung
                $result = array(2);
                echo json_encode($result);
                die;
            }
            if (count($rs) != null && $rs['UserVerifiled']['code'] == $param["code"]) {
                $result = array(0);
                echo json_encode($result);
            }else{
                $result = array(1);
                echo json_encode($result);
            }

        }
        die;

    }

    public function loginApp(){

        $param = $this->request->query;
        CakeLog::write('UserController', 'loginApp'.json_encode($param));

        $curDate = date("Y-m-d H:i:s");
        if(isset($param["accessToken"])){//flow xác thực đăng ký và trả về sessionKey
            $accessToken = $param["accessToken"];
            $code = $param["code"];
            $user_details = "https://graph.facebook.com/me?fields=id,name,picture.type(large){url}&access_token=" . $accessToken;
//            echo $user_details;
            $response = file_get_contents($user_details);
//            pr($response);
//            die;
            $response = json_decode($response);



            $user = $this->User->find("first", [
                'conditions' => [
                    'User.username' => $response->id,
                ]
            ]);
            if (count($user) > 0) {

                $rs1 = $this->UserVerifiled->find("first", [
                    'conditions' => [
                        'UserVerifiled.user_id' => $user['User']['id'],
                    ]
                ]);
                if(count($rs1) == 0){
                    $result = array('status' => 1, 'data' => "Tài khoản chưa xác thực");
                    echo json_encode($result);
                    die;
                }else if($rs1['UserVerifiled']['code'] != $code){
                    $result = array('status' => 1, 'data' => "Mã xác thực không đúng");
                    echo json_encode($result);
                    die;
                }

                $result = array('status' => 0, 'data' => $rs1['UserVerifiled']['token']);

                echo json_encode($result);
                die;
            }else{
                $result = array('status' => 1, 'data' => "Tài khoản không có trong game");
                echo json_encode($result);
                die;
            }
        }else{

            $username = $param["username"];
            $password = $param["password"];
            $code = $param["code"];
            $user = $this->User->find("first", [
                'conditions' => [
                    'User.username' => $username,
                    'User.password' => $password,
                ]
            ]);
            if (count($user) == 0) {
                $result = array('status' => 1, 'data' => "Tài khoản hoặc mật khẩu không đúng");
                echo json_encode($result);
                die;
            }
            $rs1 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $user['User']['id'],
                ]
            ]);
            if(count($rs1) == 0){
                $result = array('status' => 1, 'data' => "Tài khoản chưa xác thực");
                echo json_encode($result);
                die;
            }else if($rs1['UserVerifiled']['code'] != $code){
                $result = array('status' => 1, 'data' => "Mã xác thực không đúng");
                echo json_encode($result);
                die;
            }

            $result = array('status' => 0, 'data' => $rs1['UserVerifiled']['token']);
            echo json_encode($result);
            die;

        }

        $result = array('status' => 1, 'data' => "Sai dữ liệu");
        echo json_encode($result);

        die;
    }

    public function getAppotp(){
        $param = $this->request->query;
        CakeLog::write('UserController', "preverifyphone ".json_encode($param));
        if(isset($param["username"]) && isset($param["token"])) {
            $code = Util::random_num(6);

            $dl = $this->User->find("first",[
                'conditions' => [
                    'User.username' => $param["username"]
                ]

            ]);

            if(count($dl)  == 0){
                $result = array('status' => 1, 'data' => "Không tìm thấy tài khoản");
                echo json_encode($result);
                die;
            }
            $rs1 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $dl['User']['id'],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_OK,
                ]
            ]);


            if(count($rs1)  > 0){

                if($rs1['UserVerifiled']['token'] != $param["token"]){
                    $result = array('status' => 1, 'data' => "Lỗi bảo mật");
                    echo json_encode($result);
                    die;
                }

                $curDate = date("Y-m-d H:i:s");
                $time = strtotime($curDate) - strtotime($rs1['UserVerifiled']['otpdate']);
                if($time < 60){
                    $result = array('status' => 0, 'data' => ['code' => $rs1['UserVerifiled']['codeotp'], 'time' => 60-$time]);
                    echo json_encode($result);
                    die;
                }else {
                    $this->UserVerifiled->save(array(
                        'id' => $rs1['UserVerifiled']['id'],
                        'otpdate' => $curDate,
                        'codeotp' => $code));
                    $result = array('status' => 0, 'data' => ['code' => $code, 'time' => 60]);
                    echo json_encode($result);
                    die;
                }
            }else{
                $result = array('status' =>1, 'data' => "Tài khoản chưa xác thực");
                echo json_encode($result);
                die;
            }
        }else{
            $result = array('status' => 1, 'data' => "Sai dữ liệu");
            echo json_encode($result);
        }
        die;
    }
//http://localhost/casinoService/Useropt/requestappopt?username=mmm5556
//http://localhost/casinoService/Useropt/loginApp?username=conMeoMeoMeo1&password=e10adc3949ba59abbe56e057f20f883e&code=588183
//http://localhost/casinoService/Useropt/getAppotp?username=conMeoMeoMeo
    public function requestappopt(){
        header('Content-type: application/json');
        header('Access-Control-Allow-Origin: *');
        $param = $this->request->query;
        CakeLog::write('UserController', "requestopt ".json_encode($param));
        if(isset($param["username"]) && isset($param["password"]) || isset($param["accessToken"])){

            if(isset($param["accessToken"])){
                $accessToken = $param["accessToken"];
                $user_details = "https://graph.facebook.com/me?fields=id,name,picture.type(large){url}&access_token=" . $accessToken;
    //            echo $user_details;
                $response = file_get_contents($user_details);
    //            pr($response);
    //            die;
                $response = json_decode($response);



                $dl = $this->User->find("first", [
                    'conditions' => [
                        'User.username' => $response->id,
                    ]
                ]);
            }else{
                $dl = $this->User->find("first",[
                    'conditions' => [
                        'User.username' => $param["username"],
                        'User.password' => $param["password"]]

                ]);

            }

            if(count($dl)  == 0){
                $result = array('status' => 1, 'data' => "Không tìm thấy tài khoản");
                echo json_encode($result);
                die;
            }

            $rs1 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $dl['User']["id"],
                    'UserVerifiled.status' => 1
                ]
            ]);

            if (count($rs1) != 0) {
                if($rs1['UserVerifiled']['status'] == 0){
                    $result = array('status' => 1, 'data' => "Chưa xác thực tài khoản");
                    echo json_encode($result);
                    die;
                }
            }else{
                $result = array('status' => 1, 'data' => "Chưa xác thực số điện thoại");
                echo json_encode($result);
                die;
            }

            $code = $sid = Util::random_num(6);
            $token = $sid = Util::random_string(32);
            $Content="Ma OTP cua ban la: ".$code.", thoi han su dung 5 phut";

            $SendContent=urlencode($Content);
            $data="http://rest.esms.vn/MainService.svc/json/SendMultipleMessage_V4_get?Phone=".$rs1['UserVerifiled']["phone"]."&ApiKey=".APIKey."&SecretKey=".SecretKey."&Content=".$SendContent."&SmsType=2&Brandname=Brandname";

            $curl = curl_init($data);
            curl_setopt($curl, CURLOPT_FAILONERROR, true);
            curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
            $result = curl_exec($curl);
            CakeLog::write('UserController', "requestopt result ".$result);
            $obj = json_decode($result,true);
            $curDate = date("Y-m-d H:i:s");
            if($obj['CodeResult']==100)
            {
                $this->UserVerifiled->save(array(
                    'id' => $rs1['UserVerifiled']['id'],
                    'created' => $curDate,
                    'token' => $token,
                    'code' => $code));
                $result = array('status' => 0, 'data' => "Mã xác thực đã được gửi vào SMS.");
                echo json_encode($result);
            }else{
                $result = array('status' => 1, 'data' => "Dịch vụ đang bảo trì");
                echo json_encode($result);
            }

        }else{
            $result = array('status' => 1, 'data' => "Sai dữ liệu");
            echo json_encode($result);
        }
        die;

    }

    public function verifyAppcode(){

        $param = $this->request->query;
        CakeLog::write('UserController', "verifyphone ".json_encode($param));
        if(isset($param["id"]) &&  isset($param["code"])){

            $dl = $this->Agency->find("first",[
                'conditions' => [
                    'Agency.id' => $param["id"]]

            ]);
            if(count($dl)  == 0){
                $result = array(1);
                echo json_encode($result);
                die;
            }
            $rs1 = $this->UserVerifiled->find("first", [
                'conditions' => [
                    'UserVerifiled.user_id' => $dl['Agency']['userid'],
                    'UserVerifiled.status' => $this->STATUS_VERIFY_OK,
                ]
            ]);
            if(count($rs1)  > 0){
                $curDate = date("Y-m-d H:i:s");
                $t1 = strtotime($curDate);
                $t2 = strtotime($dl['Agency']['created']);
                if($t1 - $t2 > 5 * 60){//Code qua han su dung
                    $result = array(2);
                    echo json_encode($result);
                    die;
                }
                if (count($dl) != null && $dl['Agency']['code'] == $param["code"]) {

                    $result = array(0);
                    echo json_encode($result);
                }else{
                    $result = array(1);
                    echo json_encode($result);
                }
            }else{
                $result = array(2);
                echo json_encode($result);
            }

        }
        die;

    }


}
