<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:41 PM
 */
class TaixiuRankingByDay extends AppModel
{
    public $useTable = 'taixiu_ranking_by_day';
}