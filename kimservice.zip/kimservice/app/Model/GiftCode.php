<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:41 PM
 */
class GiftCode extends AppModel
{
    public $useTable = 'gift_codes';
    public $belongsTo = array(
        'EventCode' => array(
            'className' => 'EventCode',
            'foreignKey' => 'eventid'
        )
    );
}