<?php
App::uses('AppModel', 'Model');
/**
 * BotGame Model
 *
 */
class BotGame extends AppModel {

/**
 * Validation rules
 *
 * @var array
 */

}
