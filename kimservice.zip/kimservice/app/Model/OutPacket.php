<?php

class  OutPacket
{
    public $INDEX_SIZE_PACKET = 1;
    public $_data;
    public $_capacity;
    public $_pos;
    public $_length;
    public $_isPackedHeader;
    public $_cmdId;
    public $_controllerId;

    public $_pack;
    public $_size;


    public function openSocket(&$socket){
        //Open socket to server
        if($socket == null) {
            $socket = socket_create(AF_INET, SOCK_STREAM, SOL_TCP);
        }
        if ($socket === false) {
            return  false;
        } else {
            return true;
        }

        $result = socket_connect($socket, HOST_SERVER, PORT_SERVER);
        if ($result === false) {
            return false;
        } else {
            return true;
        }

    }

    function OutPacket($controllerId, $cmdID){
        $this->_size = 0;
        $this->_pack = array();

        //setData
        $this->_pack[$this->_size++] = $controllerId;
        $this->putShort($cmdID);

    }
    function setcmdID($cmdID){
        $this->_cmdId = $cmdID;
        echo $cmdID;
    }
    function setcontrollerId($controllerId){
        $this->_controllerId = $controllerId;
    }
    function  initData($capacity){
//        $this->_data = ifx_create_char($capacity);
        $this->_capacity = $capacity;
    }

    function reset(){
        $this->_pos = 0;
        $this->_length = 0;
        $this->_isPackedHeader = false;
    }

    function packHeader(){
        if ($this->_isPackedHeader)
        {
            return;
        }
        $this->_isPackedHeader = true;

        $header = $this->setBitgenHeader(false, false);
        putByte(header);
        putUnsignedShort(_length);
        putByte(_controllerId);
        putShort(_cmdId);
    }

    function checkSizeAndExtendsIfNeed($sizeAdded)
    {
        if ($this->_pos + $sizeAdded > $this->_capacity)
        {
            $newSize = $this->_capacity * 1.5;
            $temp = null;
            copy($this->_data, $this->_data + $this->_capacity, $temp);
//            delete[] _data;
            $this->_data = $temp;
            $this->_capacity = $newSize;
        }
    }
    function putByte($b){
        $this->_pack[$this->_size++] = ord($b);
    }
    function putByteArray($bytes, $size)
    {
        $this->putShort($size);
        $this->putBytes($bytes, $size);
    }
    function putBytes($bytes, $size){
        for ($i = 0; $i < $size; $i++) {
            $this->putByte($bytes[$i]);
        }
    }


    function putInt($v) {
        $this->_pack[$this->_size++] = (($v >> 24) & 0xff);
        $this->_pack[$this->_size++] = (($v >> 16) & 0xff);
        $this->_pack[$this->_size++] = (($v >> 8) & 0xff);
        $this->_pack[$this->_size++] = (($v >> 0) & 0xff);
    }

    function putLong($v) {
        $this->_pack[$this->_size++] = (($v >> 56) & 0xff);
        $this->_pack[$this->_size++] = (($v >> 48) & 0xff);
        $this->_pack[$this->_size++] = (($v >> 40) & 0xff);
        $this->_pack[$this->_size++] = (($v >> 32) & 0xff);
        $this->_pack[$this->_size++] = (($v >> 24) & 0xff);
        $this->_pack[$this->_size++] = (($v >> 16) & 0xff);
        $this->_pack[$this->_size++] = (($v >> 8) & 0xff);
        $this->_pack[$this->_size++] = (($v >> 0) & 0xff);

    }

    function putShort($v) {
        $this->_pack[$this->_size++] = (($v >> 8) & 0xFF);
        $this->_pack[$this->_size++] = (($v >> 0) & 0xFF);
    }

    function putString( $str) {
        $size = strlen($str);
        $this->putByteArray($str, $size);
    }
    function genHeader($bigSize, $compress)
    {
        $header = 0;
        //set bit dau la binary hay ko
        $this->setBit($header,7,true);
        //bit 2: ko ma hoa
        $this->setBitsetBit($header,6,false);
        //bit 3: ko nen
        $this->setBitsetBit($header,5,$compress);
        //bit 4: isBlueBoxed?
        $this->setBitsetBit($header,4,true);
        //bit 5: isBigSize?
        $this->setBitsetBit($header,3,$bigSize);
        return $header;
    }



//
//    function setBit(&$input, $index, $hasBit){
//        if($hasBit){
//            $input |= 1 << $index;
//        }else{
//            $input &= ~(1 << $index);
//        }
//    }


//
//

//OutPacket* OutPacket::putDouble(double v)
//{
//    char* byteArray = reinterpret_cast<char*>(&v);
//	int i;
//	for (i = 0; i < 8; i++)
//	{
//        putByte(byteArray[7 - i]);
//    }
//	return this;
//}


    //-----------------------


}
//
//}
//OutPacket::OutPacket():_controllerId(1)
//{
//	retain();
//	reset();
//}
//
//OutPacket::~OutPacket()
//{
//
//}
//
//void OutPacket::packHeader()
//{
//
//}
//
//
//void OutPacket::updateUnsignedShortAtPos(unsigned short v, int pos)
//{
//	_data[pos] = v >> 8;
//	_data[pos + 1] = v >> 0;
//}
//void OutPacket::checkSizeAndExtendsIfNeed(int sizeAdded)
//{
//	if (_pos + sizeAdded > _capacity)
//	{
//		int newSize = _capacity * 1.5f;
//		char* temp = new char[newSize];
//		std::copy(_data, _data + _capacity, temp);
//		delete[] _data;
//		_data = temp;
//		_capacity = newSize;
//	}
//}
//void OutPacket::updateSize()
//{
//	updateUnsignedShortAtPos(_length - 3, INDEX_SIZE_PACKET);
//}
//char* OutPacket::getData(int& size)
//{
//	size = _length;
//	return _data;
//}
//NS_FR_END

?>