<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:41 PM
 */
App::uses('OutPacket', 'Model');
class PaymentPack extends OutPacket {
    function createPack($cmdID, $data){
//        $this->setcmdID($cmdID);
//        parent::initData(1);
//        parent::setcontrollerId(1);
//        parent::putString($data);
//        return parent::$this;
    }
}