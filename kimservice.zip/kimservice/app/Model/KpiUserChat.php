<?php
App::uses('AppModel', 'Model');
/**
 * Agency Model
 *
 */
class KpiUserChat extends AppModel {
    public $useDbConfig = 'casinoLog';
    public $useTable = false;
}
