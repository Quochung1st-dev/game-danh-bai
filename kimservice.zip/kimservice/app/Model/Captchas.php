<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/6/2017
 * Time: 3:24 PM
 */
class Captchas extends AppModel
{
    public $useTable = 'captchas';
}