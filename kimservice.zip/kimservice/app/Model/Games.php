<?php

/**
 * Created by PhpStorm.
 * User: admin
 * Date: 5/4/2017
 * Time: 6:41 PM
 */
class Games {
    //Khởi tạo dữ liệu trả về
    public $newVersion = 1;//chưa biết chức năng
    public $message = "";//chưa biết chức năng
    public $update = 0;
    public $ipServer = "";
    public $portServer = "";
    public $location = "vi";
    public $defaultLogin = 1;//chưa biết chức năng
    public $maintain = 0;
    public $maintainMessage = "";
    public $support = "dungpa";
    public $forumUrl = "";
    public $urlnews = "";
    public $fromTexas = "";//chưa biết chức năng
    public $debug = 0;//chưa biết chức năng
    public $linkStore = "";
    public $hasTournament = 1;
    public $canLikePage = 1;
    public $canRegister = 0;
    public $isReview = 0;
    public $typeOS = "";
    public $login = ["facebook","zalo","zacc"];
    public $payment = ["iap"];
    public $canRateGame = 0;
}