<?php
App::uses('BotGame', 'Model');

/**
 * BotGame Test Case
 */
class BotGameTest extends CakeTestCase {

/**
 * Fixtures
 *
 * @var array
 */
	public $fixtures = array(
		'app.bot_game'
	);

/**
 * setUp method
 *
 * @return void
 */
	public function setUp() {
		parent::setUp();
		$this->BotGame = ClassRegistry::init('BotGame');
	}

/**
 * tearDown method
 *
 * @return void
 */
	public function tearDown() {
		unset($this->BotGame);

		parent::tearDown();
	}

}
