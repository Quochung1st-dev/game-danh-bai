<?php
date_default_timezone_set('Asia/Ho_Chi_Minh');
include 'Util.php';

define("KEY_ENCODE", "baiviphd");
define('portal_secret_key', "dmhack");
define('php_secret_key', "hackdm");
define('HOST_SERVER', "server");
define('PORT_SERVER', 1103);
define('MAX_IP_REGISTER', 500);
define("DEBUG", true);


define("URL_CALLBACK_FCONN", "http://3.0.205.232/casinoService/Listcard/callbackCardService");


define('SMS', 7);
define('CARD', 1);
define('CARD_NEW', 2);

//defined a new constant for firebase api key
define('GOOGLE_GCM_KEY', 'AIzaSyBQcfDX9G5emXlDUDC4xjCSjAgWs6FeL6E');

define('NUMBER_PHONE_VERIFILED', 1);

//CMD_ID
define('PAYMENT_MAX_PAY', 8206);
define('PAYMENT_1_PAY_SMS', 8205);
define('GAME_EXTENSION_RUT_THUONG_KQ', 8506);
define('USER_TRADE_GOLD', 8601);

define('GAME_ADMIN_REQUEST', 9800);


//Maxpay
define('CHARGE_SERVICE_URL', "https://maxpay.vn/apis/card/charge?");
define('RECHECK_SERVICE_URL', "https://maxpay.vn/apis/card/recheck?");
define('MERCHANT_ID', "1000233");//TODO: Thay bằng Merchant ID maxpay.vn cung cấp cho bạn
define('SECRET_KEY', "JB0zFjVISjGDgy7F");//TODO: Thay bằng Secret Key ID maxpay.vn cung cấp cho bạn

//ESMS
define('APIKey', "910F47D6C33D0781F9723C0D0E5C29");
define('SecretKey', "A514580C10CDF1FE98C13D9F13B44F");

//Topup
define('TOPUP_REQUEST_URL', "http://gw.santhecao.com");
define('TOPUP_API_PASS', "62f5e8896eb39984bbaba1ecfcf9e8c1");
define('TOPUP_API_CODE', "1554");

//Epay
define('E_webservice', "http://cttcorp.net/ChargingGW/services/Services?wsdl");
define('E_webservice_uri', "http://113.161.78.134/VNPTEPAY/");
define('E_PartnerID', "CTT_BAIVIP68");
define('E_MPIN', "jjbqhalos");
define('E_UserName', "CTT_BAIVIP68");
define('E_Pass', "wzqopaxsk");
define('E_PartnerCode', "00250");
define('E_Target', "useraccount1");

//1Pay SMS
define('PAYMENT_1_access_key', "e5bbvnlpzurbviwr2wns");
define('PAYMENT_1_secret', "bz3goz5zd0vfawxxvm3hfpozxs11wm6u");

define('SMSP_PARTNER_ID', "10306");
define('SMSP_PARTNER_PASSWORD', "27bab9e08f28e55691a6a289379d8b75");

define('dev', false);
// db
if (dev == false) {
    define('DB_HOST', getenv('DB_HOST'));
    define('DB_PORT', getenv('DB_PORT'));
    define('DB_NAME', getenv('DB_NAME'));
    define('DB_USERNAME', getenv('DB_USERNAME'));
    define('DB_PASSWORD', getenv('DB_PASSWORD'));
} else {
    define('DB_HOST', 'localhost');
    define('DB_PORT', '3306');
    define('DB_NAME', 'casino');
    define('DB_USERNAME', 'root');
    define('DB_PASSWORD', '');
}


/**
 * This file is loaded automatically by the app/webroot/index.php file after core.php
 *
 * This file should load/create any application wide configuration settings, such as
 * Caching, Logging, loading additional configuration files.
 *
 * You should also use this file to include any files that provide global functions/constants
 * that your application uses.
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Config
 * @since         CakePHP(tm) v 0.10.8.2117
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */

// Setup a 'default' cache configuration for use in the application.
Cache::config('default', array('engine' => 'File'));

/**
 * The settings below can be used to set additional paths to models, views and controllers.
 *
 * App::build(array(
 *     'Model'                     => array('/path/to/models/', '/next/path/to/models/'),
 *     'Model/Behavior'            => array('/path/to/behaviors/', '/next/path/to/behaviors/'),
 *     'Model/Datasource'          => array('/path/to/datasources/', '/next/path/to/datasources/'),
 *     'Model/Datasource/Database' => array('/path/to/databases/', '/next/path/to/database/'),
 *     'Model/Datasource/Session'  => array('/path/to/sessions/', '/next/path/to/sessions/'),
 *     'Controller'                => array('/path/to/controllers/', '/next/path/to/controllers/'),
 *     'Controller/Component'      => array('/path/to/components/', '/next/path/to/components/'),
 *     'Controller/Component/Auth' => array('/path/to/auths/', '/next/path/to/auths/'),
 *     'Controller/Component/Acl'  => array('/path/to/acls/', '/next/path/to/acls/'),
 *     'View'                      => array('/path/to/views/', '/next/path/to/views/'),
 *     'View/Helper'               => array('/path/to/helpers/', '/next/path/to/helpers/'),
 *     'Console'                   => array('/path/to/consoles/', '/next/path/to/consoles/'),
 *     'Console/Command'           => array('/path/to/commands/', '/next/path/to/commands/'),
 *     'Console/Command/Task'      => array('/path/to/tasks/', '/next/path/to/tasks/'),
 *     'Lib'                       => array('/path/to/libs/', '/next/path/to/libs/'),
 *     'Locale'                    => array('/path/to/locales/', '/next/path/to/locales/'),
 *     'Vendor'                    => array('/path/to/vendors/', '/next/path/to/vendors/'),
 *     'Plugin'                    => array('/path/to/plugins/', '/next/path/to/plugins/'),
 * ));
 */

/**
 * Custom Inflector rules can be set to correctly pluralize or singularize table, model, controller names or whatever other
 * string is passed to the inflection functions
 *
 * Inflector::rules('singular', array('rules' => array(), 'irregular' => array(), 'uninflected' => array()));
 * Inflector::rules('plural', array('rules' => array(), 'irregular' => array(), 'uninflected' => array()));
 */

/**
 * Plugins need to be loaded manually, you can either load them one by one or all of them in a single call
 * Uncomment one of the lines below, as you need. Make sure you read the documentation on CakePlugin to use more
 * advanced ways of loading plugins
 *
 * CakePlugin::loadAll(); // Loads all plugins at once
 * CakePlugin::load('DebugKit'); // Loads a single plugin named DebugKit
 */

/**
 * To prefer app translation over plugin translation, you can set
 *
 * Configure::write('I18n.preferApp', true);
 */

/**
 * You can attach event listeners to the request lifecycle as Dispatcher Filter. By default CakePHP bundles two filters:
 *
 * - AssetDispatcher filter will serve your asset files (css, images, js, etc) from your themes and plugins
 * - CacheDispatcher filter will read the Cache.check configure variable and try to serve cached content generated from controllers
 *
 * Feel free to remove or add filters as you see fit for your application. A few examples:
 *
 * Configure::write('Dispatcher.filters', array(
 *		'MyCacheFilter', //  will use MyCacheFilter class from the Routing/Filter package in your app.
 *		'MyCacheFilter' => array('prefix' => 'my_cache_'), //  will use MyCacheFilter class from the Routing/Filter package in your app with settings array.
 *		'MyPlugin.MyFilter', // will use MyFilter class from the Routing/Filter package in MyPlugin plugin.
 *		array('callable' => $aFunction, 'on' => 'before', 'priority' => 9), // A valid PHP callback type to be called on beforeDispatch
 *		array('callable' => $anotherMethod, 'on' => 'after'), // A valid PHP callback type to be called on afterDispatch
 *
 * ));
 */
Configure::write('Dispatcher.filters', array(
	'AssetDispatcher',
	'CacheDispatcher'
));

/**
 * Configures default file logging options
 */
App::uses('CakeLog', 'Log');
CakeLog::config('debug', array(
	'engine' => 'File',
	'types' => array('notice', 'info', 'debug'),
	'file' => 'debug',
));
CakeLog::config('error', array(
	'engine' => 'File',
	'types' => array('warning', 'error', 'critical', 'alert', 'emergency'),
	'file' => 'error',
));
CakeLog::config('GameManagerController_'.date("Y-m-d-h A"), array(
    'engine' => 'File',
    'types' => array('GameManagerController'),
    'file' => 'GameManagerController_'.date("Y-m-d-h A"),
));
CakeLog::config('EPayCardController_'.date("Y-m-d-h A"), array(
    'engine' => 'File',
    'types' => array('EPayCardController'),
    'file' => 'EPayCardController_'.date("Y-m-d-h A"),
));
CakeLog::config('EPaySMSController_'.date("Y-m-d-h A"), array(
    'engine' => 'File',
    'types' => array('EPaySMSController'),
    'file' => 'EPaySMSController_'.date("Y-m-d-h A"),
));
CakeLog::config('GiftcodeController_'.date("Y-m-d-h A"), array(
    'engine' => 'File',
    'types' => array('GiftcodeController'),
    'file' => 'GiftcodeController_'.date("Y-m-d-h A"),
));
CakeLog::config('MaxpayController_'.date("Y-m-d-h A"), array(
    'engine' => 'File',
    'types' => array('MaxpayController'),
    'file' => 'MaxpayController_'.date("Y-m-d-h A"),
));
CakeLog::config('PaymentController_'.date("Y-m-d-h A"), array(
    'engine' => 'File',
    'types' => array('PaymentController'),
    'file' => 'PaymentController_'.date("Y-m-d-h A"),
));
CakeLog::config('TopupController_'.date("Y-m-d-h A"), array(
    'engine' => 'File',
    'types' => array('TopupController'),
    'file' => 'TopupController_'.date("Y-m-d-h A"),
));
CakeLog::config('UserController_'.date("Y-m-d-h A"), array(
    'engine' => 'File',
    'types' => array('UserController'),
    'file' => 'UserController_'.date("Y-m-d-h A"),
));