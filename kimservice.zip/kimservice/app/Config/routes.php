<?php
/**
 * Routes configuration
 *
 * In this file, you set up routes to your controllers and their actions.
 * Routes are very important mechanism that allows you to freely connect
 * different URLs to chosen controllers and their actions (functions).
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Config
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
 
/**
 * Here, we are connecting '/' (base path) to controller called 'Pages',
 * its action called 'display', and we pass a param to select the view file
 * to use (in this case, /app/View/Pages/home.ctp)...
 */
	Router::connect('/', array('controller' => 'pages', 'action' => 'display', 'home'));
/**
 * ...and connect the rest of 'Pages' controller's URLs.
 */
	Router::connect('/pages/*', array('controller' => 'pages', 'action' => 'display'));
	Router::connect('/api/giftcode/getUserCode/*', array('controller' => 'giftcode', 'action' => 'getusercode'));
    Router::connect('/api/giftcode/checkThenAdd/*', array('controller' => 'giftcode', 'action' => 'checkthenadd'));
    Router::connect('/api/giftcode/usecode/*', array('controller' => 'giftcode', 'action' => 'usecode'));
    Router::connect('/api/giftcode/genDaily/*', array('controller' => 'giftcode', 'action' => 'genDaily'));
    Router::connect('/api/user/dang_ky_dang_nhap/*', array('controller' => 'user', 'action' => 'register'));
    Router::connect('/api/user/dang_ky_token/*', array('controller' => 'user', 'action' => 'registerToken'));
    Router::connect('/api/user/vao_cau_lac_bo/*', array('controller' => 'user', 'action' => 'addclub'));
    Router::connect('/api/user/top_vippoint/*', array('controller' => 'user', 'action' => 'getTopVP'));
    Router::connect('/api/user/thong_tin_user_event_xo_so/*', array('controller' => 'user', 'action' => 'getUserInfoEventXS'));
    Router::connect('/api/user/mua_ve_event_xo_so/*', array('controller' => 'user', 'action' => 'buyTicketEventXS'));
    Router::connect('/api/user/thong_tin_event_xo_so/*', array('controller' => 'user', 'action' => 'getInfoEventXS'));
    Router::connect('/api/user/phan_thuong_event_xo_so/*', array('controller' => 'user', 'action' => 'getAwards'));
    Router::connect('/api/user/chi_tiet_event_xo_so/*', array('controller' => 'user', 'action' => 'getDetailEventXS'));
    Router::connect('/api/user/lay_so_dien_thoai/*', array('controller' => 'user', 'action' => 'getphone'));
    Router::connect('/api/user/lich_su_nap/*', array('controller' => 'user', 'action' => 'lich_su_nap'));
    Router::connect('/api/user/lich_su_giao_dich/*', array('controller' => 'user', 'action' => 'lich_su_giao_dich'));

    Router::connect('/api/user/lay_ten_nhan_vat_theo_id/*', array('controller' => 'user', 'action' => 'idbydisplayname'));
    Router::connect('/api/user/thong_tin_vippoint/*', array('controller' => 'user', 'action' => 'getVPPreseting'));
    Router::connect('/api/user/thong_tin_hu_slot/*', array('controller' => 'user', 'action' => 'getSlotInfo'));
    Router::connect('/api/user/thay_doi_mat_khau/*', array('controller' => 'user', 'action' => 'resetpassword'));
    // Router::connect('/api/user/dang_ky_sdt_bao_mat/*', array('controller' => 'user', 'action' => 'preverifyphone'));
    Router::connect('/api/user/dang_ky_sdt_bao_mat/*', array('controller' => 'user', 'action' => 'preverifyEmail'));
    // Router::connect('/api/user/xac_thuc_sdt/*', array('controller' => 'user', 'action' => 'verifyphone'));
    Router::connect('/api/user/xac_thuc_sdt/*', array('controller' => 'user', 'action' => 'verifyEmail'));
    Router::connect('/api/user/huy_xac_thuc_sdt/*', array('controller' => 'user', 'action' => 'unverifyphone'));
    Router::connect('/api/user/dang_ky_ten_hien_thi/*', array('controller' => 'user', 'action' => 'displayname'));
    Router::connect('/api/user/get_tai_xiu_du_day/*', array('controller' => 'user', 'action' => 'get_tai_xiu_du_day'));
    // Router::connect('/api/user/quen_mat_khau/*', array('controller' => 'user', 'action' => 'misspassword'));
    Router::connect('/api/user/quen_mat_khau/*', array('controller' => 'user', 'action' => 'misspasswordmail'));
    Router::connect('/api/user/thay_doi_sdt/*', array('controller' => 'user', 'action' => 'resetphone'));
    Router::connect('/api/user/registerrv/*', array('controller' => 'user', 'action' => 'registerrv'));
    Router::connect('/api/user/dang_ky_tai_khoan/*', array('controller' => 'user', 'action' => 'register_new'));
    Router::connect('/api/user/getDLotp/*', array('controller' => 'user', 'action' => 'getDLotp'));
    Router::connect('/api/user/verifyDLcode/*', array('controller' => 'user', 'action' => 'verifyDLcode'));
    Router::connect('/api/user/invitefriend/*', array('controller' => 'user', 'action' => 'invitefriend'));
    Router::connect('/api/user/login/*', array('controller' => 'user', 'action' => 'login'));

    Router::connect('/api/Captcha/lay_ma_captcha/*', array('controller' => 'Captcha', 'action' => 'genCaptcha'));
    // Router::connect('/api/UserOTP/lay_sms_otp/*', array('controller' => 'Useropt', 'action' => 'requestsmsopt'));
    Router::connect('/api/UserOTP/lay_sms_otp/*', array('controller' => 'Useropt', 'action' => 'requestemailotp'));
    Router::connect('/api/UserOTP/xac_thuc_sms_otp/*', array('controller' => 'Useropt', 'action' => 'verifysmsotp'));


    Router::connect('/api/statistic/statisticUser/*', array('controller' => 'statistic', 'action' => 'statisticUser'));
    Router::connect('/api/gamemanager/gameInfo/*', array('controller' => 'game_manager', 'action' => 'gameInfo'));
    Router::connect('/api/gamemanager/thong_tin_thang_lon/*', array('controller' => 'game_manager', 'action' => 'getbigwin'));
    Router::connect('/api/gamemanager/danh_sach_dai_ly/*', array('controller' => 'game_manager', 'action' => 'getagency'));
    Router::connect('/api/gamemanager/thong_tin_the_cao/*', array('controller' => 'game_manager', 'action' => 'getcard'));
    Router::connect('/api/gamemanager/getchathistory/*', array('controller' => 'game_manager', 'action' => 'getChat'));

    Router::connect('/api/topup/requesttopup/*', array('controller' => 'topup', 'action' => 'requesttopup'));


    Router::connect('/api/usersendgold/returngold/*', array('controller' => 'userSendGold', 'action' => 'returngold'));
    Router::connect('/api/usersendgold/dltrahey/*', array('controller' => 'userSendGold', 'action' => 'dlTraHey'));
    Router::connect('/api/usersendgold/dlnhanhey/*', array('controller' => 'userSendGold', 'action' => 'dlNhanHey'));
    Router::connect('/api/usersendgold/dlthuhoihey/*', array('controller' => 'userSendGold', 'action' => 'dlThuHoiHey'));
    Router::connect('/api/usersendgold/lich_su_giao_dich_nhan/*', array('controller' => 'userSendGold', 'action' => 'gethistoryreceive'));
    Router::connect('/api/usersendgold/lich_su_giao_dich_chuyen/*', array('controller' => 'userSendGold', 'action' => 'gethistorysend'));
    Router::connect('/api/usersendgold/lay_id_theo_ten_nhan_vat/*', array('controller' => 'userSendGold', 'action' => 'getIDbyDisplayname'));

    Router::connect('/api/adminmanager/admin_send_mail/*', array('controller' => 'adminManager', 'action' => 'admin_send_mail'));
    Router::connect('/api/adminmanager/admin_send_gold/*', array('controller' => 'adminManager', 'action' => 'admin_send_gold'));
    Router::connect('/api/adminmanager/admin_jackpot/*', array('controller' => 'adminManager', 'action' => 'admin_jackpot'));
    Router::connect('/api/adminmanager/admin_reload_config/*', array('controller' => 'adminManager', 'action' => 'admin_reload_config'));
    Router::connect('/api/adminmanager/admin_reload_config_taixiu/*', array('controller' => 'adminManager', 'action' => 'admin_reload_config_taixiu'));
    Router::connect('/api/adminmanager/admin_reload_config_slot/*', array('controller' => 'adminManager', 'action' => 'admin_reload_config_slot'));

    Router::connect('/api/adminmanager/admin_maintain/*', array('controller' => 'adminManager', 'action' => 'admin_maintain'));
    Router::connect('/api/adminmanager/admin_kick_all_user/*', array('controller' => 'adminManager', 'action' => 'admin_kick_all_user'));
    Router::connect('/api/adminmanager/admin_kick_user/*', array('controller' => 'adminManager', 'action' => 'admin_kick_user'));
    Router::connect('/api/adminmanager/admin_send_mail_all_user/*', array('controller' => 'adminManager', 'action' => 'admin_send_mail_all_user'));
    Router::connect('/api/adminmanager/admin_ban_user/*', array('controller' => 'adminManager', 'action' => 'admin_ban_user'));
    Router::connect('/api/adminmanager/admin_send_notification/*', array('controller' => 'adminManager', 'action' => 'admin_send_notification'));
    Router::connect('/api/adminmanager/pushNotification/*', array('controller' => 'adminManager', 'action' => 'pushNotification'));
    Router::connect('/api/adminmanager/adminconfig/*', array('controller' => 'adminManager', 'action' => 'adminconfig'));

    Router::connect('/api/listcard/response/*', array('controller' => 'listcard', 'action' => 'response'));

    Router::connect('/api/usersendgold/agencysendgold/*', array('controller' => 'userSendGold', 'action' => 'agencysendgold'));

    // Host updates
    Router::connect('/api/HostUpdates/getHostUpdate/*', array('controller' => 'HostUpdates', 'action' => 'getHostUpdate'));
/**
 * Load all plugin routes. See the CakePlugin documentation on
 * how to customize the loading of plugin routes.
 */
	CakePlugin::routes();

/**
 * Load the CakePHP default routes. Only remove this if you do not want to use
 * the built-in default routes.
 */
	require CAKE . 'Config' . DS . 'routes.php';
